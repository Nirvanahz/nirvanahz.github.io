---
title: Show the limit is zero
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 9 Exercise 9.7
{% endnote %}

<!--more-->



Solution: We have seen that $0\le s_n<\sqrt{\dfrac{2}{n-1}}$. By [Sequeeze-Theorem/Exercise 8.5](/elementary-analysis-08-05.html), it suffices to show that $\lim \sqrt{\dfrac{2}{n-1}}=0$. 

Let $\epsilon>0$. Let $N>\dfrac{2}{\epsilon^2}+1$. If $n>N$, we have
$$
n-1>\frac{2}{\epsilon^2}\Longrightarrow \sqrt{\dfrac{2}{n-1}}<\epsilon.
$$ Therefore, we have
$$
\left|\sqrt{\dfrac{2}{n-1}}-0\right|<\epsilon
$$ for all $n>N$ as desired. Thus $\lim \sqrt{\dfrac{2}{n-1}}=0$ and we are done.

---
A different approach to see that it suffices to show that $\lim \sqrt{\dfrac{2}{n-1}}=0$ is as follows.

{% note success %}
We know that if $\lim s_n$ exists, by [Exercise 8.9](/elementary-analysis-08-09.html), we must have
$$
0\le \lim s_n\le \lim \sqrt{\dfrac{2}{n-1}}.
$$ Hence it suffices to show that $\lim \sqrt{\dfrac{2}{n-1}}=0$.
{% endnote %}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>