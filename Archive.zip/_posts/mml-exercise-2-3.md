---
title: Verify a set with matrices is a group
categories: [Machine Learning,Linear Algebra]
tags: [Group, Matrix]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.3**
{% endnote %}

<!--more-->

Solution:

Let $A\_1 = \\begin{bmatrix} 1 & x\_1 & y\_1 \\\\ 0 & 1 & z\_1 \\\\ 0 & 0 & 1 \\end{bmatrix}$ and $A\_2 = \\begin{bmatrix} 1 & x\_2 & y\_2 \\\\ 0 & 1 & z\_2 \\\\ 0 & 0 & 1 \\end{bmatrix} \\in \\mathcal{G}$.

Then $$A\_1A\_2 = \\begin{bmatrix} 1 & x\_1+x\_2 & y\_1+x\_1z\_2+y\_2 \\\\ 0 & 1 & z\_1+z\_2 \\\\ 0 & 0 & 1 \\end{bmatrix} \\in\\mathcal{G},$$ so we have closure.

Associativity follows from the associativity of standard matrix multiplication.

Letting $x=y=z=0$, observe that the identity is in $\\mathcal{G}$.

Finally, if we take $x\_2 = -x\_1$, $z\_2 = -z\_1$, and $y\_2 = -y\_1-x\_1z\_2$, then observe that $A\_1A\_2 = I\_3$, and thus inverses are of the required form! Therefore, $\\mathcal{G} $ is a group.

The group is not abelian, e.g. take $x\_1=z\_2=1$ and everything else to be $0$. Then multiplying these matrices in the other order (i.e. $x\_2=z\_1=1$) gives a different answer.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>