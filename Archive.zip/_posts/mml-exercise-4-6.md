---
title: Compute eigenspaces of matrices and determine if they are diagonalisable
categories: [Machine Learning,Linear Algebra]
tags: [Diagonalisability,Matrix,Eigenvector,Eigenvalue]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.6**
{% endnote %}

<!--more-->

Solution: 

**Part a**

The characteristic polynomial is $(5-\\lambda)(1-\\lambda)^2$. 

Now, $\mathrm{rank}(A-I) = 2$, so there is only one linearly independent eigenvector for $\\lambda=1$. Hence $A$ is not diagonalisable.

We have $E\_5 = \mathrm{span}\\{(1,1,0)\\}$, and $E\_1=\mathrm{span}\\{(-3,1,0)\\}$.

**Part b**

The characteristic polynomial here is $-\\lambda^3(1-\\lambda)$, so the eigenvalues are 1, and 0 (with multiplicity 3). Observe that $$\mathrm{rank}(A-0I) = rank A = 1,$$ so there are three linearly independent eigenvectors for the eigenvalue 0. With the other eigenvector for $\\lambda=1$, we will have a basis of eigenvectors, and hence $A$ will be diagonalisable.

We have $$E\_1 = \mathrm{span}\\{(1,0,0,0)\\},$$ and $$E\_0 = \mathrm{span}\\{(1,-1,0,0),(0,0,1,0),(0,0,0,1)\\}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>