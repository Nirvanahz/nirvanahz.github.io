---
title: Determine if maps are linear mappings
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Function,Linear Map]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.16**
{% endnote %}

<!--more-->

Solution:

**Part a**

Observe that \\begin{align\*}\\Phi(f+g) = & \\ \\int\_a^b (f+g)(x) dx \\\\=&\\ \\int\_a^b f(x) + g(x) dx\\\\ =&\\ \\int\_a^bf(x) dx +\\int\_a^b g(x) dx = \\Phi(f) + \\Phi(g),\\end{align\*} and similarly $\\Phi(\\alpha f) = \\alpha \\Phi(f)$, for all real $\\alpha$, so $\\Phi$ (that is to say, definite integration) is indeed linear!

**Part b**

Similarly to the previous part, we know that differentiation is indeed linear.

**Part c**

This is not linear -- $\\Phi$ doesn't even map 0 to 0, indeed!

**Part d**

We know from 2.7.1 that any matrix transformation like this is indeed linear. This comes from distributive properties of matrix multiplication.

**Part e**

As before, this mapping is also linear. Indeed, this represents a clockwise rotation by $\\theta$ about the origin. (See 3.9.1)

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>