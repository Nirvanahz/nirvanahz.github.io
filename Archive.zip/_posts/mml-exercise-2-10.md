---
title: Determine if vectors are linearly independent
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Linearly Independent]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.10**
{% endnote %}

<!--more-->

Solution:

**Part a**

If we form a matrix out of these three vectors and compute its determinant, we get zero. Thus, the vectors are not linearly independent.

**Part b**

Let's form the equation $\\alpha\_1 x\_1 + \\alpha\_2 x\_2 + \\alpha\_3 x\_3 = 0$. These three vectors are linearly independent if and only if the $only$ solution to this equation is $\\alpha\_1=\\alpha\_2=\\alpha\_3=0$.

Looking at the third component, we have that $\\alpha\_1\\cdot 1 + \\alpha\_2 \\cdot 0 + \\alpha\_3 \\cdot 0 = 0$, that is to say, $\\alpha\_1 = 0$.

Next, look at the second component. We already know $\\alpha\_1 = 0$, so we have $\\alpha\_2 \\cdot 1 + \\alpha\_3 \\cdot 0 = 0$, that is to say $\\alpha\_2=0$ also.

Finally, look at the first component. We have that $\\alpha\_3 \\cdot 1 = 0$, so all of the $\\alpha\_i$'s are zero. Therefore, our three vectors are linearly independent.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>