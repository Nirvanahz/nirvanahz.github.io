---
title: Proof of Squeeze Lemma/Theorem
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit,Proof,Sequeeze Theorem]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 8 Exercise 8.5
{% endnote %}

<!--more-->

Solution: 

### Part a

Let $\epsilon>0$. Since $\lim a_n=s$, there exists $N_1>0$ such that
$$
|a_n-s|<\epsilon\Longrightarrow -\epsilon < a_n-s
$$ for all $n>N_1$. Similarly, since $\lim b_n=s$, there exists $N_2>0$ such that
$$
|b_n-s|<\epsilon\Longrightarrow b_n -s< \epsilon
$$ for all $n>N_2$. 

Let $N=\max\\{N_1,N_2\\}$. Then we have
$$
s_n-s\le b_n-s<\epsilon
$$ and
$$
-\epsilon < a_n-s\le s_n-s
$$ for all $n>N$. Therefore, we have $|s_n-s|<\epsilon$ for all $n>N$. Hence $\lim s_n=s$ as desired.  

### Part b

Let $\epsilon>0$. Since $\lim t_n=0$, there exists $N>0$ such that
$$
|t_n-0|<\epsilon\Longrightarrow t_n<\epsilon
$$ for all $n>N$. Therefore, $n>N$ implies that
$$
|s_n-0|=|s_n|\le t_n<\epsilon
$$ as desired. Thus $\lim s_n=0$.



<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>