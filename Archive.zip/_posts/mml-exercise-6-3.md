---
title: Compute the posterior distribution of a Bernoulli distribution
categories: [Machine Learning,Statistics]
tags: [Distribution,Random Variables,Bernoulli Distribution]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.3**
{% endnote %}

<!--more-->

Solution: 

The conjugate prior to the Bernoulli distribution is the Beta distribution

$$ p(\\mu | \\alpha, \\beta) =\\frac{1}{\\mathcal{B}(\\alpha, \\beta)} \\mu^{\\alpha -1}(1-\\mu)^{\\beta-1} \\propto \\mu^{\\alpha -1}(1-\\mu)^{\\beta-1}, $$

where $\\alpha,\\beta$ are not necessarily integers and the normalization coefficient si the Beta function defined as

$$ \\mathcal{B}(\\alpha, \\beta) = \\int\_0^1 t^{\\alpha -1}(1-t)^{\\beta-1}dt $$

The likelihood of observing data $\\{x\_1, x\_2, ..., x\_N\\}$ is

$$p(x\_1, ..., x\_N|\\mu) = \\prod\_{i=1}^Np(x\_i|\\mu) = \\prod\_{i=1}^N \\mu^{x\_i}(1-\\mu)^{1-x\_i} = \\mu^{\\sum\_{i=1}^N x\_i}(1-\\mu)^{N-\\sum\_{i=1}^N x\_i} $$

The posterior distribution is proportional to teh rpoduct of this likelihood with teh prior distribution (Bayes theorem):

$$ p(\\mu |x\_1, ..., x\_N) \\propto p(x\_1, ..., x\_N|\\mu)p(\\mu | \\alpha, \\beta) \\propto \\mu^{\\sum\_{i=1}^N x\_i + \\alpha -1}(1-\\mu)^{N-\\sum\_{i=1}^N x\_i +\\beta -1} $$

This is also a Beta distribution, i.e. our choice of the gonjugate prior was correct. The normalization constant is readily determined:

$$ p(\\mu |x\_1, ..., x\_N) = \\frac{1}{\\mathcal{B}(\\sum\_{i=1}^N x\_i + \\alpha -1, N-\\sum\_{i=1}^N x\_i +\\beta -1)} \\mu^{\\sum\_{i=1}^N x\_i + \\alpha -1}(1-\\mu)^{N-\\sum\_{i=1}^N x\_i +\\beta -1} $$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>