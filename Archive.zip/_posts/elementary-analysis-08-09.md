---
title: If the sequence is greater than a number, so is the limit
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 8 Exercise 8.9
{% endnote %}

<!--more-->

Solution: 

### Part a

We argue it by contradiction. Suppose $\lim s_n=s < a$. Then $a-s >0$. Since $s_n\ge a$ for all but finitely many $n$, there exist $N_1>0$ such that $s_n\ge a$ for all $n > N_1$.

Let $\epsilon =\dfrac{a-s}{2}$. Then there exists $N_2>0$ such that if $n > N_2$ then
$$
s_n-s<\epsilon.
$$ Take $N=\max\\{N_1,N_2\\}$. If $n>N$, then we have
$$
s_n-s<\epsilon,\quad s_n\ge a.
$$ Therefore, we have
$$
a \le s_n < s+\epsilon=s+\frac{a-s}{2}=\frac{a+s}{2}.
$$ Thus, we obtain
$$
a < \frac{a+s}{2}
$$ which implies that $a < s$. This contradicts with the assumption $ s < a$ at the beginning. Hence such an assumption is impossible. We argued that $s\ge a$.

---

### Part b

We argue it by contradiction. Suppose $\lim s_n=s > a$. Then $s -a >0$. Since $s_n\le a$ for all but finitely many $n$, there exist $N_1>0$ such that $s_n\le a$ for all $n>N_1$.

Let $\epsilon =\dfrac{s-a}{2}$. Then there exists $N_2>0$ such that if $n> N_2$ then
$$
|s_n-s|<\epsilon\Longrightarrow s_n - s>-\epsilon.
$$ Take $N=\max\\{N_1,N_2\\}$. If $n>N$, then we have
$$
s_n-s>-\epsilon,\quad s_n\le a.
$$ Therefore, we have
$$
a \ge s_n > s-\epsilon=s-\frac{s-a}{2}=\frac{a+s}{2}.
$$ Thus, we obtain
$$
a > \frac{a+s}{2}
$$ which implies that $a > s$. This contradicts with the assumption $ s > a$ at the beginning. Hence such an assumption is impossible. We argued that $s\le a$.

---

### Part c

By assumption, we have $s_n\le b$ and $s_n\ge a$ for all but finitely many $n$. Using Part (a) and Part (b), we have $a\le \lim s_n\le b$. Therefore $\lim s_n$ belongs to $[a,b]$ as well.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>