---
title: Compute the eigenspaces of two by two matrices
categories: [Machine Learning,Linear Algebra]
tags: [Determinant,Matrix,Eigenvector,Eigenvalue]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.3**
{% endnote %}

<!--more-->

Solution: 

**Part a**

If we solve the equation $\\det(A-\\lambda I) = 0$ for $\\lambda$, we obtain $\\lambda = 1$ only. (Or, indeed, we can observe that $A$ is in lower triangular form, so the eigenvalues are the entries on the main diagonal.)

The eigenspace is $$E\_1 = \\{x\\in \\mathbb{R}^2 : (A-I)(x)=0\\} = \\mathrm{span}\\{(0,1)\\}.$$

**Part b**

Again, solving $\\det(B-\\lambda I ) = 0$, we find that $\\lambda=2$ or $\\lambda = -3$. We then have the eigenspaces $$E\_2 = \\mathrm{span}\\{(1,2)\\}$$ and $$E\_{-3} = \\mathrm{span}\\{ (-2,1) \\}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>