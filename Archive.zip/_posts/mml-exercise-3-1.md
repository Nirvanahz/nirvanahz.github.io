---
title: Verify Inner Product by Direct Computation
categories: [Machine Learning,Linear Algebra]
tags: [Inner Product]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.1**
{% endnote %}

<!--more-->

Solution: We check it by definition.

Firstly, we check it is symmetric. Note that $$\\langle \\mathbf x,\\mathbf y\\rangle = x\_1y\_1-(x\_1y\_2+x\_2y\_1)+2(x\_2y\_2)$$ and $$\\langle \\mathbf y,\\mathbf x\\rangle = y\_1x\_1-(y\_1x\_2+y\_2x\_1)+2(y\_2x\_2),$$it is clear that $\\langle \\mathbf x,\\mathbf y\\rangle=\\langle \\mathbf y,\\mathbf x\\rangle$.

Secondly, we check it is bilinear. Let $\\mathbf z=\[z\_1,z\_2\]^\\top$, then for any real numbers $a,b$ we have\\begin{align\*}\\langle a\\mathbf x+b\\mathbf y,\\mathbf z\\rangle=&\\ \\langle \[ax\_1+by\_1,ax\_2+by\_2\]^\\top,\[z\_1,z\_2\]^\\top\\rangle \\\\ =&\\ (ax\_1+by\_1)z\_1-(ax\_1+by\_1)z\_2-(ax\_2+by\_2)z\_1+2(ax\_2+by\_2)z\_2\\\\=&\\ (ax\_1z\_1-ax\_1z\_2-ax\_2z\_1+2ax\_2z\_2)+(by\_1z\_1-by\_1z\_2-by\_2z\_1+2by\_2z\_2)\\\\=&\\ a(x\_1z\_1-x\_1z\_2-x\_2z\_1+2x\_2z\_2)+b(y\_1z\_1-y\_1z\_2-y\_2z\_1+2y\_2z\_2)\\\\=&\\ a\\langle \\mathbf x,\\mathbf z\\rangle+b\\langle \\mathbf y,\\mathbf z\\rangle.\\end{align\*} Use the symmetry shown above, we have\\begin{align\*}\\langle \\mathbf x,a\\mathbf y+b\\mathbf z\\rangle=&\\ \\langle a\\mathbf y+b\\mathbf z,\\mathbf x\\rangle \\\\ = &\\ a\\langle \\mathbf y,\\mathbf x\\rangle + b\\langle \\mathbf z,\\mathbf x\\rangle \\\\ = &\\ a\\langle \\mathbf x,\\mathbf y\\rangle + b\\langle \\mathbf x,\\mathbf z\\rangle.\\end{align\*}In the second equality, we used the linearity shown above on the first component. The last equality comes from the symmetry of $\\langle ,\\rangle$.

Finally, we prove it is positive-definite. We have \\begin{align\*}\\langle \\mathbf x,\\mathbf x\\rangle=&\\ x\_1x\_1-(x\_1x\_2+x\_2x\_1)+2x\_2x\_2\\\\ = &\\ x\_1^2-2x\_1x\_2+2x\_2^2=(x\_1-x\_2)^2+x\_2^2,\\end{align\*}which is always non-negative and can only be zero if $x\_2=0$ and $x\_1=x\_2$. This confirms it is positive-definite.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>