---
title:  Rational numbers are closed under algebraic operations
categories: [Solution,Elementary Analysis]
tags: [Rational Number]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 2 Exercises 2.6
{% endnote %}

<!--more-->

{% note default %}
Our main tool is Corollary 2.3.
{% endnote %}

Solution: Since $b$ is rational, there exist integers $m$ and $n$ such that $b=\dfrac{n}{m}$ and $m\ne 0$. Then
$$
4-7b^2=4-7\frac{n^2}{m^2}=\frac{4m^2}{m^2}-\frac{7n^2}{m^2}=\frac{4m^2-7n^2}{m^2}.
$$ Note that $4m^2-7n^2$ and $m^2$ are integers as well. Moreover, $m^2\ne 0$. Therefore $4-7b^2$ is also rational.

{% note success %}
In general, rational numbers are closed under addition, subtraction, multiplication and division. More precisely, performing such operations for rational numbers, the answer remains rational. 
{% endnote %}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>