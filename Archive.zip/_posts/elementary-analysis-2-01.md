---
title:  Determine if these real numbers are rational I
categories: [Solution,Elementary Analysis]
tags: [Rational Number,Polynomial]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 2 Exercises 2.1 & 2.2
{% endnote %}

<!--more-->

{% note default %}
Our main tool is Corollary 2.3.
{% endnote %}

### Exercise 2.1

Solution: 

$\sqrt{3}$: It is clear that $\sqrt 3$ is a root of the polynomial $x^2-3=0$. By Corollary 2.3, if $\sqrt 3$ is rational, then it must be a divisor of $3$. That is, it must be $\pm 1$ or $\pm 3$. But this is impossible because $\sqrt 3\ne 1$ and $\sqrt 3\ne 3$. Hence $\sqrt 3$ cannot be rational.

---

$\sqrt{5}, \sqrt 7, \sqrt{31}$ are the same as that of (a) because 5, 7, 31 are prime numbers.

---

$\sqrt{24}$: It is clear that $\sqrt{24}$ is a root of the polynomial $x^2-24=0$. By Corollary 2.3, if $\sqrt{24}$ is rational, then it must be a divisor of $24$. That is, it must be $\pm 1$, $\pm 2$, $\pm 3$, $\pm 4$, $\pm 6$, $\pm 8$, $\pm 12$, $\pm 24$. But this is impossible because $4<\sqrt{24}<5$. Hence $\sqrt{24}$ cannot be rational.

---

### Exercise 2.2

Solution: We only show that $\sqrt[5]{7}$ is irrational.

Clearly, $\sqrt[5]{7}$ is a solution of $x^5-7=0$. Hence by Corollary 2.3, the rational solution to this equation can only be $\pm 1$ and $\pm 7$. It is straightforward to check that none of them are solutions of $x^5-7=0$. Hence $x^5-7=0$ does not have rational solutions and $\sqrt[5]{7}$ is irrational.

The rests are similar.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>