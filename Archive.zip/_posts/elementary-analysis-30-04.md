---
title:  Interchange limits at zero and infinity
categories: [Solution,Elementary Analysis]
tags: [Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 30 Exercises 30.4
{% endnote %}

<!--more-->

Solution: 

First, we show that $\lim_{x\to 0^+}f(x)$ exists if $\lim_{y\to \infty}g(y)$ exists. 

Suppose $\lim_{y\to \infty}g(y)=L$. For any $\epsilon>0$, there exists $N>0$ such that 
\\begin{equation}\label{30-4-1}
|g(y)-L|<\epsilon,
\\end{equation} for any $y>N$. 

Let $\delta=\dfrac{1}{N}$. 

Note that for all $0 < x < \delta$, we have $\dfrac{1}{x} > N$. Therefore, by \eqref{30-4-1},
$$
|f(x)-L|=\left|g\Big(\frac{1}{x}\Big)-L\right|<\epsilon
$$ for all $0 < x < \delta$. Therefore, we have $\lim_{x\to 0^+}f(x)=L$.

---

Then, we show the other direction. Namely $\lim_{x\to 0^+}f(x)$ exists only if $\lim_{y\to \infty}g(y)$ exists.

Suppose $\lim_{x\to 0^+}f(x)=L$. For any $\epsilon >0$, there exists $\delta>0$ such that 
\\begin{equation}\label{30-4-2}
|f(x)-L|<\epsilon,
\\end{equation} for all $0< x< \delta$. 

Let $N=\max\\{\dfrac{1}{\delta},a^{-1}\\}$.

Note that for all $y>N$, we have $0<\dfrac{1}{y}<\delta$. Therefore, by \eqref{30-4-2}, we have
$$
|g(y)-L|=\left|f\Big(\frac{1}{y}\Big)-L\right|<\epsilon
$$ for all $y>N$. Therefore, we have $\lim_{y\to \infty}g(y)=L$.


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>