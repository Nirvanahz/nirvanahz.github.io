---
title: Angles between two vectors using difference inner products
categories: [Machine Learning,Linear Algebra]
tags: [Inner Product,Angle]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.4**
{% endnote %}

<!--more-->

Solution: We have to compute $\\cos\\theta =\\dfrac{\\langle \\mathbf x,\\mathbf y\\rangle}{\\sqrt{\\langle \\mathbf x,\\mathbf x\\rangle \\cdot \\langle \\mathbf y,\\mathbf y\\rangle}}$ and then take $\\arccos$ to get the angle $\\theta$. 

a. We have $$\\langle \\mathbf x,\\mathbf y\\rangle = 1\\cdot (-1)+2\\cdot (-1)=-3,$$ $$\\langle \\mathbf x,\\mathbf x\\rangle = 1\\cdot 1+2\\cdot 2=5,$$ $$\\langle \\mathbf y,\\mathbf y\\rangle = (-1)\\cdot (-1)+(-1)\\cdot (-1)=2.$$Hence $$\\cos\\theta =\\dfrac{\\langle \\mathbf x,\\mathbf y\\rangle}{\\sqrt{\\langle \\mathbf x,\\mathbf x\\rangle \\cdot \\langle \\mathbf y,\\mathbf y\\rangle}}=\\frac{-3}{\\sqrt{2\\cdot 5}}=\\frac{-3}{\\sqrt{10}}.$$Take inverse function $\\arccos$, we get $$\\theta =\\arccos \\dfrac{-3}{\\sqrt{10}}\\approx 2.82\\,\\mathrm{rad}.$$ b. We have \\begin{align\*}\\langle \\mathbf x,\\mathbf y\\rangle =&\\ \\begin{bmatrix} 1 & 2\\end{bmatrix}\\begin{bmatrix}2 & 1\\\\ 1 & 3\\end{bmatrix}\\begin{bmatrix} -1\\\\ -1\\end{bmatrix}\\\\=&\\ \\begin{bmatrix} 4 & 7\\end{bmatrix}\\begin{bmatrix} -1\\\\ -1\\end{bmatrix}=-11,\\end{align\*} \\begin{align\*}\\langle \\mathbf x,\\mathbf x\\rangle =&\\ \\begin{bmatrix} 1 & 2\\end{bmatrix}\\begin{bmatrix}2 & 1\\\\ 1 & 3\\end{bmatrix}\\begin{bmatrix} 1\\\\ 2\\end{bmatrix}\\\\=&\\ \\begin{bmatrix} 4 & 7\\end{bmatrix}\\begin{bmatrix} 1\\\\ 2\\end{bmatrix}=18,\\end{align\*} \\begin{align\*}\\langle \\mathbf y,\\mathbf y\\rangle =&\\ \\begin{bmatrix} -1 & -1\\end{bmatrix}\\begin{bmatrix}2 & 1\\\\ 1 & 3\\end{bmatrix}\\begin{bmatrix} -1\\\\ -1\\end{bmatrix}\\\\=&\\ \\begin{bmatrix} -3 & -4\\end{bmatrix}\\begin{bmatrix} -1\\\\ -1\\end{bmatrix}=7,\\end{align\*} Hence $$\\cos\\theta =\\dfrac{\\langle \\mathbf x,\\mathbf y\\rangle}{\\sqrt{\\langle \\mathbf x,\\mathbf x\\rangle \\cdot \\langle \\mathbf y,\\mathbf y\\rangle}}=\\frac{-11}{\\sqrt{18\\cdot 7}}=\\frac{-11}{\\sqrt{126}}.$$Take inverse function $\\arccos$, we get $$\\theta =\\arccos \\dfrac{-11}{\\sqrt{126}}\\approx 2.94\\,\\mathrm{rad}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>