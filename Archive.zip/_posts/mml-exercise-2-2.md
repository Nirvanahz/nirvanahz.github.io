---
title: Verify a set with certain binary operation is an Abelian group II
categories: [Machine Learning,Linear Algebra]
tags: [Abelian Group, Group]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.2**
{% endnote %}

<!--more-->

Solution:

**Part a**

The major thing we need to check here is whether the operation $\\oplus$ is well-defined. That is to say, if we take two different representatives of the same congruence classes, do we definitely get the same answer at the end? Let's take $a\_1, a\_2 \\in \\mathbb{Z} $ such that $\\overline{a\_1} = \\overline{a\_2}$, and similarly let $b\_1, b\_2 \\in \\mathbb{Z} $ such that $\\overline{b\_1} = \\overline{b\_2}$. We need to show that $\\overline{a\_1}\\oplus \\overline{b\_1} = \\overline{a\_2} \\oplus \\overline{b\_2}$. In other words, we need to show that $\\overline{a\_1+b\_1} = \\overline{a\_2+b\_2}$.

By the definition of the congruence class, two classes $\\overline{a\_1}$ and $\\overline{a\_2}$ are equal in $\\mathbb{Z}\_n$ if and only if $a\_1 - a\_2$ is a multiple of $n$. Let's say $a\_1 - a\_2 = k\_1 n$ and ${b\_1 - b\_2 = k\_2 n}$, for some $k\_1, k\_2 \\in \\mathbb{Z}$. Observe then that $(a\_1+b\_1)-(a\_2+b\_2) = (k\_1+k\_2)n$, and so $\\overline{a\_1+b\_1} = \\overline{a\_2+b\_2}$ indeed!

From here, we use properties of addition in the integers to deduce that $(\\mathbb{Z}\_n,\\oplus)$ is an abelian group. 

First, it is closed under the operation, that is $$\\overline{a}\\oplus\\overline{b} = \\overline{a+b}\\in \\mathbb{Z}\_n.$$

Then, we have the associativity, that is $$(\\overline{a}\\oplus \\overline{b}) \\oplus \\overline{c} = \\overline{a+b} \\oplus \\overline{c} = \\overline{(a+b)+c} = \\overline{a+(b+c)} = \\overline{a} \\oplus \\overline{b+c} = \\overline{a}\\oplus (\\overline{b} \\oplus \\overline{c}),$$ where the middle equality follows from the associativity of $\\mathbb{Z}$.

Clearly, $\\overline{0}$ is the neutral element, since $\\overline{0} \\oplus \\overline{a} = \\overline{0+a} = \\overline{a}$, and similarly the other way round.

Given $\\overline{a} \\in \\mathbb{Z}\_n$, we have that $\\overline{-a} = \\overline {n-a}$ is the inverse element, since $\\overline{a} \\oplus \\overline{-a} = \\overline{a-a} = \\overline{0}$, indeed.

Finally, $\\overline{a}\\oplus \\overline{b} = \\overline{a+b} = \\overline{b+a} = \\overline{b} \\oplus \\overline{a}$, so the group is abelian!

**Part b**

Observe that the neutral element is $\\overline{1}$. For the inverses, we have $\\overline{1}^{-1} = \\overline{1}$, $\\overline{2}^{-1} = \\overline{3}$, $\\overline{3}^{-1} = \\overline{2}$, and $\\overline{4}^{-1} = \\overline{4}$. All the axioms are satisfied, so $(\\mathbb{Z}\_5\\setminus\\{\\overline{0}\\} , \\otimes)$ is a group.

**Part c**

Observe that, for example, $\\overline{2}\\otimes \\overline{4} = \\overline{0}\\notin \\mathbb{Z}\_8\\setminus\\{\\overline{0}\\}$, so the operation is not closed.

**Part d**

If $n$ is prime, then every integer from $1$ to $n-1$ will be relatively prime to $n$. Let $a$ be such an integer. Then, by Bezout's theorem, there exist integers $u, v$ such that $au+nv=1$. If we take this identity mod $n$, we have $\\overline{au} \\oplus \\overline{nv} = \\overline{1}$. But $nv$ is a multiple of $n$, so $\\overline{nv} = \\overline{0}$, and this simplifies to $\\overline{a} \\otimes \\overline{u} = \\overline{1}$ -- in other words, $\\overline{u}$ is the inverse of $\\overline{a}$. Also, if we take two integers $a$ and $b$, both of which are relatively prime to $n$, then the product $ab$ also cannot contain a factor of $n$, since $n$ is prime, so the operation is closed. The other properties follow immediately. This shows that we have a group. $\\lozenge$

If $n$ is not prime, then we can say $n=ab$, where $a,b\\in \\mathbb{Z}$, with $1 < a\\leq b < n$. But then $$\\overline{a}\\otimes \\overline{b} = \\overline{ab} = \\overline{n} = \\overline{0}\\notin \\mathbb{Z}\_n\\setminus\\{\\overline{0}\\},$$ and so the operation is not closed.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>