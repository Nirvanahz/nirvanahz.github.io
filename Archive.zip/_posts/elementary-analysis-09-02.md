---
title: Limit of sum is sum of limits
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 9 Exercise 9.2
{% endnote %}

<!--more-->

Solution: 

### Part a

By Theorem 9.3, we have
$$
\lim(x_n+y_n)=\lim x_n+\lim y_n=3+7=10.
$$

---

### Part b

By Theorems 9.2 and 9.3 we have
$$
\lim(3y_n-x_n)=3\lim y_n-\lim x_n=3 \cdot 7-3=18.
$$ By Theorem 9.4 we have
$$
\lim y_n^2=\left(\lim y_n\right)^2=7^2=49.
$$ It follows from Theorem 9.6 that
$$
\lim \frac{3y_n-x_n}{y_n^2}=\frac{\lim(3y_n-x_n)}{\lim y_n^2}=\frac{18}{49}.
$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>