---
title:  Mathematics for Machine learning Solution Manual
categories: [Machine Learning]
tags: [Solution Manual, Solution Content]
mathjax: true
sticky: 999

---

{% note info %}
[Mathematics for Machine Learning](https://amzn.to/3aeqKqE) by Marc Peter Deisenroth, A. Aldo Faisal, Cheng Soon Ong
{% endnote %}

ISBN:9781108569323, 1108569323

<!--more-->

<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=US&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=linearalgeb0e-20&language=en_US&marketplace=amazon&region=US&placement=B083M7DBP6&asins=B083M7DBP6&linkId=937bbc3ea679bccdaf2d9de9b38b7643&show_border=true&link_opens_in_new_window=true"></iframe>

### Chapter 2 Linear Algebra

[#2.1](/mml-exercise-2-1.html), [#2.2](/mml-exercise-2-2.html), [#2.3](/mml-exercise-2-3.html), [#2.4](/mml-exercise-2-4.html), [#2.5](/mml-exercise-2-5.html), [#2.6](/mml-exercise-2-6.html), [#2.7](/mml-exercise-2-7.html), [#2.8](/mml-exercise-2-8.html), [#2.9](/mml-exercise-2-9.html), [#2.10](/mml-exercise-2-10.html), [#2.11](/mml-exercise-2-11.html), [#2.12](/mml-exercise-2-12.html), [#2.13](/mml-exercise-2-13.html), [#2.14](/mml-exercise-2-14.html), [#2.15](/mml-exercise-2-15.html), [#2.16](/mml-exercise-2-16.html), [#2.17](/mml-exercise-2-17.html), [#2.18](/mml-exercise-2-18.html), [#2.19](/mml-exercise-2-19.html), [#2.20](/mml-exercise-2-20.html)

### Chapter 3 Analytic Geometry

[#3.1](/mml-exercise-3-1.html), [#3.2](/mml-exercise-3-2.html), [#3.3](/mml-exercise-3-3.html), [#3.4](/mml-exercise-3-4.html), [#3.5](/mml-exercise-3-5.html), [#3.6](/mml-exercise-3-6.html), [#3.7](/mml-exercise-3-7.html), [#3.8](/mml-exercise-3-8.html), [#3.9](/mml-exercise-3-9.html), [#3.10](/mml-exercise-3-10.html)

### Chapter 4 Matrix Decompositions

[#4.1](/mml-exercise-4-1.html), [#4.2](/mml-exercise-4-2.html), [#4.3](/mml-exercise-4-3.html), [#4.4](/mml-exercise-4-4.html), [#4.5](/mml-exercise-4-5.html), [#4.6](/mml-exercise-4-6.html), [#4.7](/mml-exercise-4-7.html), [#4.8](/mml-exercise-4-8.html), [#4.9](/mml-exercise-4-9.html), [#4.10](/mml-exercise-4-10.html), [#4.11](/mml-exercise-4-11.html), [#4.12](/mml-exercise-4-12.html)

### Chapter 5 Vector Calculus

[#5.1](/mml-exercise-5-1.html), [#5.2](/mml-exercise-5-2.html), [#5.3](/mml-exercise-5-3.html), [#5.4](/mml-exercise-5-4.html), [#5.5](/mml-exercise-5-5.html), [#5.6](/mml-exercise-5-6.html), [#5.7](/mml-exercise-5-7.html), [#5.8](/mml-exercise-5-8.html), [#5.9](/mml-exercise-5-9.html)

### Chapter 6 Probability and Distributions

[#6.1](/mml-exercise-6-1.html), [#6.2](/mml-exercise-6-2.html), [#6.3](/mml-exercise-6-3.html), [#6.4](/mml-exercise-6-4.html), [#6.5](/mml-exercise-6-5.html), [#6.6](/mml-exercise-6-6.html), [#6.7](/mml-exercise-6-7.html), [#6.8](/mml-exercise-6-8.html), [#6.9](/mml-exercise-6-9.html), [#6.10](/mml-exercise-6-10.html), [#6.11](/mml-exercise-6-11.html), [#6.12](/mml-exercise-6-12.html), [#6.13](/mml-exercise-6-13.html)

### Chapter 7 Continuous Optimazation

[#7.1](/mml-exercise-7-1.html), #7.2, [#7.3](/mml-exercise-7-3.html), [#7.4](/mml-exercise-7-4.html), #7.5, [#7.6](/mml-exercise-7-6.html), [#7.7](/mml-exercise-7-7.html), #7.8, #7.9, #7.10, #7.11

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>