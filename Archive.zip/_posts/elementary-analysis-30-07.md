---
title:  An example explains the impotance of assumption in L’Hospital’s Rule
categories: [Solution,Elementary Analysis]
tags: [Limit,L’Hospital’s Rule,Chain Rule,Product Rule]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 30 Exercises 30.6
{% endnote %}

<!--more-->

Solution: 

### Part a

Note that $\cos x\sin x\ge -1$ and $\sin x\ge -1$, we have
$$
\lim_{x\to\infty}f(x)\ge \lim_{x\to\infty}(x-1)=\infty.
$$ Hence $\lim_{x\to\infty}f(x)=\infty$. 

Similarly,
$$
\lim_{x\to\infty}g(x)\ge \lim_{x\to\infty}e^{-1}(x-1)=\infty.
$$ Hence $\lim_{x\to\infty}g(x)=\infty$. 

---

### Part b

By product rule and the identity $\sin^2 x+\cos^2 x=1$, we have
\\begin{align\*}
f'(x)
=&\ 1+(-\sin x)\sin x+\cos x\cos x\\\\
=&\ 1-\sin^2 x+\cos^2 x\\\\
=&\ \cos^2 x+\cos^2 x\\\\
=&\ 2\cos^2 x.
\\end{align\*}

Similarly, by Chain rule and product rule
\\begin{align\*}
g'(x)=&\ (e^{\sin x}f(x))'\\\\
=&\ e^{\sin x}(\cos x) f(x)+e^{\sin x}f'(x)\\\\
=&\ e^{\sin x}(\cos x) f(x)+e^{\sin x} 2\cos^2 x\\\\
=&\ e^{\sin x}\cos x(f(x)+2\cos x).
\\end{align\*}

---

### Part c

Using Part b and by cancellation, we have
$$
\dfrac{f'(x)}{g'(x)}=\frac{2\cos^2 x}{e^{\sin x}\cos x(f(x)+2\cos x)}=\frac{2e^{-\sin x}\cos x}{2\cos x+f(x)}.
$$

---

### Part d

Clearly, we have
$$
|2e^{-\sin x}\cos x|\le 2e,\quad |2\cos x+f(x)|\ge f(x)-2.
$$

Since $\lim_{x\to \infty} f(x)=\infty$, we have
$$
\lim_{x\to\infty}\left|\frac{2e^{-\sin x}\cos x}{2\cos x+f(x)}\right|\le \lim_{x\to\infty}\frac{2e}{f(x)-2}=0.
$$ Hence 
$$
\lim_{x\to\infty}\frac{2e^{-\sin x}\cos x}{2\cos x+f(x)}=0.
$$ However,
$$
\lim_{x\to\infty}\frac{f(x)}{g(x)}=\lim_{x\to\infty} e^{-\sin x}
$$ does not exist since $\lim_{x\to\infty}(-\sin x)$ does not exists.


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>