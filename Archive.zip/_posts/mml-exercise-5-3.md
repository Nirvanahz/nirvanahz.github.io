---
title: Compute derivative of the function defining normal distribution
categories: [Machine Learning,Calculus]
tags: [Derivative,Chain Rule,Normal Distribution]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 5 Exercise 5.3**
{% endnote %}

<!--more-->

Solution: Clearly, we have $$\\left(-\\frac{1}{2\\sigma^2}(x-\\mu)^2\\right)'=-\\frac{1}{2\\sigma^2}2(x-\\mu)=\\frac{-(x-\\mu)}{\\sigma^2}.$$Therefore, by Chain rule (5.32), we have \\begin{align\*}f'(x)=&\\ \\exp\\left(-\\frac{1}{2\\sigma^2}(x-\\mu)^2\\right)\\cdot \\left(-\\frac{1}{2\\sigma^2}(x-\\mu)^2\\right)'\\\\=&\\ \\frac{-(x-\\mu)}{\\sigma^2}\\cdot\\exp\\left(-\\frac{1}{2\\sigma^2}(x-\\mu)^2\\right)\\end{align\*}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Real Analysis";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "402d8b59cc9faa66d8d6b3b1eef9c01e";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "bottom";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>