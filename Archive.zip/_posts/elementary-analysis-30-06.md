---
title:  Application of L’Hospital’s Rule 
categories: [Solution,Elementary Analysis]
tags: [Limit,L’Hospital’s Rule]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 30 Exercises 30.6
{% endnote %}

<!--more-->

Solution: Note that $f(x)=\dfrac{e^xf(x)}{e^x}$, hence we can apply L’Hospital’s Rule
\\begin{align\*}
\lim_{x\to\infty}f(x)
=&\ \lim_{x\to\infty}\frac{e^xf(x)}{e^x}\\\\
\text{Apply L’Hospital’s Rule}\quad
=&\ \lim_{x\to\infty}\frac{e^xf(x)+e^xf'(x)}{e^x}\\\\
=&\ \lim_{x\to\infty}(f(x)+f'(x))\\\\
=&\ L.
\\end{align\*} Therefore, we also have
$$
\lim_{x\to\infty} f'(x)=\lim_{x\to\infty} (f(x)+f'(x))-\lim_{x\to\infty} f(x)=L-L=0.
$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>