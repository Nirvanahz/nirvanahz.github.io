---
title:  Compute limits using L’Hospital’s Rule I
categories: [Solution,Elementary Analysis]
tags: [Limit,L’Hospital’s Rule,Derivative]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 30 Exercises 30.1
{% endnote %}

<!--more-->

Solution: 

### Part a

We have $\lim_{x\to 0}(e^{2x}-\cos x)=1-1=0$ and $\lim_{x\to 0} x=0$. Hence we can apply L’Hospital’s Rule and obtain that
\\begin{align\*}
\lim_{x\to 0}\frac{e^{2x}-\cos x}{x}
=&\ \lim_{x\to 0}\frac{(e^{2x}-\cos x)'}{(x)'}\\\\
=&\ \lim_{x\to 0}\frac{2e^{2x}+\sin x}{1}\\\\
=&\ \lim_{x\to 0}(2e^{2x}+\sin x)=2+0=2.
\\end{align\*}

---

### Part b

We have $\lim_{x\to 0}(1-\cos x)=1-1=0$ and $\lim_{x\to 0} x^2=0$. Hence we can apply L’Hospital’s Rule and obtain that
\\begin{align\*}
\lim_{x\to 0}\frac{1-\cos x}{x^2}
=&\ \lim_{x\to 0}\frac{(1-\cos x)'}{(x^2)'}\\\\
=&\ \lim_{x\to 0}\frac{\sin x}{2x}\\\\
\text{ Apply L’Hospital’s Rule again }\ =&\ \lim_{x\to 0}\frac{\cos x}{2}=\frac{1}{2}.
\\end{align\*} Here we can apply L’Hospital’s Rule again because $\lim_{x\to 0}\sin x=0$ and $\lim_{x\to 0}2x=0$.

---

### Part c

Whenever the denominator tends to infinity, we can apply L’Hospital’s Rule. Therefore, we can repeatedly apply L’Hospital’s Rule as follows
\\begin{align\*}
\lim_{x\to \infty}\frac{x^3}{e^{2x}}
=&\ \lim_{x\to \infty}\frac{3x^2}{2e^{2x}}\\\\
\text{ Apply L’Hospital’s Rule again }\ =&\ \lim_{x\to \infty}\frac{6x}{4e^{2x}}\\\\
\text{ Apply L’Hospital’s Rule again }\ =&\ \lim_{x\to \infty}\frac{6}{8e^{2x}}=0.
\\end{align\*}

---

### Part d

We have $\lim_{x\to 0}(\sqrt{1+x}-\sqrt{1-x})=1-1=0$ and $\lim_{x\to 0} x=0$. Hence we can apply L’Hospital’s Rule and obtain that
\\begin{align\*}
\lim_{x\to 0}\frac{\sqrt{1+x}-\sqrt{1-x}}{x}
=&\ \lim_{x\to 0}\frac{(\sqrt{1+x}-\sqrt{1-x})'}{(x)'}\\\\
=&\ \lim_{x\to 0}\frac{ \frac{1}{2\sqrt{1+x}}+\frac{1}{2\sqrt{1-x}} }{1}\\\\
=&\ \lim_{x\to 0}\Big(\frac{1}{2\sqrt{1+x}}+\frac{1}{2\sqrt{1-x}}\Big)\\\\
=&\ \frac{1}{2}+\frac{1}{2}=1.
\\end{align\*}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>