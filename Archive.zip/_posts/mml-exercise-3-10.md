---
title: Rotations of vectors by 30 degress on a plane
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Rotation]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.10**
{% endnote %}

<!--more-->

Solution: 

We will assume we need to rotate these vectors anticlockwise. A rotation about an angle $\\theta$ is given by the matrix $$\\begin{bmatrix} \\cos\\theta&-\\sin\\theta\\\\ \\sin\\theta&\\cos\\theta \\end{bmatrix}.$$ Thus for $\\theta=30^\\circ$, we have $$R=\\begin{bmatrix} \\frac{\\sqrt{3}}{2}&-\\frac{1}{2}\\\\ \\frac12 & \\frac{\\sqrt3}{2} \\end{bmatrix} = \\frac12 \\begin{bmatrix} \\sqrt3 & -1\\\\ 1&\\sqrt3 \\end{bmatrix}.$$

Therefore, $$Rx\_1 = \\frac12 \\begin{bmatrix} 2\\sqrt3-3\\\\2+3\\sqrt3 \\end{bmatrix}$$ and $$Rx\_2 = \\frac12 \\begin{bmatrix} 1\\\\-\\sqrt3 \\end{bmatrix}.$$


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>