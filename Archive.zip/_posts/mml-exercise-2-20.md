---
title: Computations of a linear mapping using two bases
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Linear Map,Basis]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.20**
{% endnote %}

<!--more-->

Solution:

**Part a**

Each set $B$ and $B'$ has the correct number of (clearly!) linearly independent vectors, so they are both bases of $\\mathbb{R}^2$.

**Part b**

We write the old basis vectors ($B'$) in terms of the new ($B$), and then transpose the matrix of coefficients. We have $$b\_1' = 4 b\_1 + 6 b\_2, \\quad b\_2' = 0b\_1 -b\_2.$$ Thus $P\_1 = \\begin{bmatrix} 4 & 0\\\\ 6 & -1 \\end{bmatrix}$.

**Part c**

Let $M=\[c\_1|c\_2|c\_3\]$, and observe that $\\det M = 4 \\neq 0$, so the vectors are linearly independent. Since $\\mathbb{R}^3$ had dimension 3, and we have three linearly independent vectors, $C$ must indeed be a basis.

Indeed, such an $M$ is the change of basis matrix from $C$ to $C'$ (write the old vectors in terms of the new!) and this is thus the $P\_2$ we require. Thus $$P\_2 = \\begin{bmatrix} 1&0&1\\\\ 2&-1&0\\\\-1&2&-1 \\end{bmatrix}.$$

**Part d**

Observe that by adding the given results, we find that $$\\Phi(b\_1) = c\_1 + 2c\_3;$$ by subtracting, we have $$\\Phi(b\_2) = -c\_1 +c\_2 -c\_3.$$ Then $A\_\\Phi$ is given by the transpose of the matrix of coefficients, so $$A\_\\Phi = \\begin{bmatrix} 1&-1\\\\ 0&1\\\\ 2&-1 \\end{bmatrix}.$$

**Part e**

We first need to apply $P\_1$ to change from basis $B'$ to $B$. Then $A\_\\Phi$ will map us to $(\\mathbb{R}^3, C)$, before $P\_2$ will take us to $C'$. Remember that matrices are acting like functions here, so they are applied to (column) vectors from right to left. Therefore the multiplication we require is $A'=P\_2 A\_\\Phi P\_1$. (This is what part f is asking us to recognise.)

We have $A' = \\begin{bmatrix} 0&2\\\\-10&3\\\\ 12&-4 \\end{bmatrix}$.

**Part f**

$$P\_1 \\begin{bmatrix}2\\\\3\\end{bmatrix}=\\begin{bmatrix}8\\\\9\\end{bmatrix}.$$

$$A\_\\Phi \\begin{bmatrix}8\\\\9\\end{bmatrix}=\\begin{bmatrix}-1\\\\9\\\\7\\end{bmatrix}.$$

$$P\_2 \\begin{bmatrix}-1\\\\9\\\\7\\end{bmatrix}=\\begin{bmatrix}6\\\\-11\\\\12\\end{bmatrix}.$$

And observe that $A' \\begin{bmatrix}2\\\\3\\end{bmatrix}=\\begin{bmatrix}6\\\\-11\\\\12\\end{bmatrix}$, indeed!


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>