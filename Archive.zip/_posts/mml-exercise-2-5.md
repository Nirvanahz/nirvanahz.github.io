---
title: Solve systems of inhomogenous linear equations
categories: [Machine Learning,Linear Algebra]
tags: [Matrix,Linear Equations]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.5**
{% endnote %}

<!--more-->

Solution:

**Part a**

Let's do some Gaussian elimination. We start with $$\\left\[ \\begin{array}{cccc|c} 1&1&-1&-1&1\\\\ 2&5&-7&5&-2\\\\ 2&-1&1&3&4\\\\ 5&2&-4&2&6 \\end{array} \\right\].$$

Taking $r\_2-2r\_1$, $r\_3-2r\_1$ and $r\_4-5r\_1$, we have $$\\left\[ \\begin{array}{cccc|c} 1&1&-1&-1&1\\\\ 0&3&-5&-3&-4\\\\ 0&-3&3&5&2\\\\ 0&-3&1&7&1 \\end{array}\\right\] .$$

Now taking $r\_3+r\_2$ and $r\_4+r\_2$, we have $$\\left\[ \\begin{array}{cccc|c} 1&1&-1&-1&1\\\\ 0&3&-5&-3&-4\\\\ 0&0&-2&2&-2\\\\ 0&0&-4&4&-3 \\end{array} \\right\].$$

Finally, taking $r\_4-2r\_3$, we have $$\\left\[ \\begin{array}{cccc|c} 1&1&-1&-1&1\\\\ 0&3&-5&-3&-4\\\\ 0&0&-2&2&-2\\\\ 0&0&0&0&1 \\end{array} \\right\].$$

Observe that the rank of the augmented matrix is greater than the matrix of coefficients, so the solution set is empty.

**Part b**

We proceed with some more Gaussian elimination. From the start, we do $r\_2-r\_1$, $r\_3-2r\_1$, and $r\_4+r\_1$, to obtain $$\\left\[ \\begin{array}{ccccc|c} 1&-1&0&0&1&3\\\\ 0&2&0&-3&-1&3\\\\ 0&1&0&1&-3&-1\\\\ 0&1&0&-2&0&2 \\end{array} \\right\].$$

From here, do $r\_2-2r\_3$ and $r\_4-r\_3$ to obtain $$\\left\[ \\begin{array}{ccccc|c} 1&-1&0&0&1&3\\\\ 0&0&0&-5&5&5\\\\ 0&1&0&1&-3&-1\\\\ 0&0&0&-3&3&3 \\end{array} \\right\].$$

Next, if we divide $r\_2$ by $-5$, and then do $r\_4+3r\_2$, we have $$\\left\[ \\begin{array}{ccccc|c} 1&-1&0&0&1&3\\\\ 0&0&0&1&-1&-1\\\\ 0&1&0&1&-3&-1\\\\ 0&0&0&0&0&0 \\end{array} \\right\].$$

Now, we do $r\_1+r\_3$, then swap $r\_2$ and $r\_3$, to give $$\\left\[ \\begin{array}{ccccc|c} 1&0&0&1&-2&2\\\\ 0&1&0&1&-3&-1\\\\ 0&0&0&1&-1&-1\\\\ 0&0&0&0&0&0 \\end{array} \\right\].$$

Finally, let's do $r\_1-r\_3$ and $r\_2-r\_3$, to obtain $$\\left\[ \\begin{array}{ccccc|c} 1&0&0&0&-1&3\\\\ 0&1&0&0&-2&0\\\\ 0&0&0&1&-1&-1\\\\ 0&0&0&0&0&0 \\end{array} \\right\].$$

Let's turn these back into equations. We have $x\_1-x\_5=3$, $x\_2-2x\_5=0$ and $x\_4-x\_5=-1$. Thus we can take $x\_3$ and $x\_5$ to be arbitrary, and then the others are determined. This gives a solution set of $$\\{ (\\alpha+3, 2\\alpha, \\beta, \\alpha-1, \\alpha)^{\\mathsf{T}} : \\alpha, \\beta \\in \\mathbb{R} \\}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>