---
title: Compute the Jacobians of functions
categories: [Machine Learning,Calculus]
tags: [Derivative,Jacobian]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 5 Exercise 5.5**
{% endnote %}

<!--more-->

Solution: 

**Part a**

We can see below that $\\dfrac{\\partial f\_1}{\\partial x}$ has dimension $1\\times2$; $\\dfrac{\\partial f\_2}{\\partial x}$ has dimension $1\\times n$; and $\\dfrac{\\partial f\_3}{\\partial x}$ has dimension $n^2\\times n$.

---

**Part b**

We have $$\\frac{\\partial f\_1}{\\partial x} = \\begin{bmatrix} \\cos(x\_1)\\cos(x\_2)&-\\sin(x\_1)\\sin(x\_2) \\end{bmatrix};$$ $$\\frac{\\partial f\_2}{\\partial x} = y^{\\mathsf{T}}.$$ (Remember, $y$ is a column vector!)

---

**Part c**

Note that $xx^{\\mathsf{T}}$ is the matrix $$\\begin{bmatrix} x\_1^2 & x\_1x\_2 & \\cdots & x\_1x\_n \\\\ x\_2x\_1 & x\_2^2 & \\cdots & x\_2x\_n \\\\ \\vdots & \\vdots & \\ddots & \\vdots \\\\ x\_nx\_1 & x\_nx\_2 & \\cdots & x\_n^2 \\end{bmatrix}.$$ Thus its derivative will be a higher-order tensor. However, if we consider the matrix to be an $n^2$-dimensional object in its own right, we can compute the Jacobian. Its first row consists of $$\\begin{bmatrix} 2x\_1 & x\_2 & \\cdots & x\_n | x \_2 & 0 &\\cdots & 0 | \\cdots | x\_n&0&\\cdots&0 \\end{bmatrix} ,$$ where I have inserted a vertical bar every $n$ columns, to aid readability.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Real Analysis";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "402d8b59cc9faa66d8d6b3b1eef9c01e";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "bottom";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>