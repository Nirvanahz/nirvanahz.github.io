---
title: Orthogonal projection and distance in Euclidean space II
categories: [Machine Learning,Linear Algebra]
tags: [Inner Product,Orthogonal Projection,Euclidean Space]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.6**
{% endnote %}

<!--more-->

Solution: 

**Part a**

We require $\\langle e\_1, e\_2-\\pi\_U(e\_2)\\rangle = 0$ and $\\langle e\_3, e\_2-\\pi\_U(e\_2)\\rangle = 0$. That is to say, $$\\left\\langle \\begin{bmatrix} 1\\\\0\\\\0 \\end{bmatrix}, \\begin{bmatrix}-\\lambda\_1\\\\1\\\\ -\\lambda\_2 \\end{bmatrix} \\right\\rangle = 0,$$ and $$\\left\\langle \\begin{bmatrix} 0\\\\0\\\\1 \\end{bmatrix}, \\begin{bmatrix}-\\lambda\_1\\\\1\\\\ -\\lambda\_2 \\end{bmatrix} \\right\\rangle = 0.$$

Computing the first gives us $\\lambda\_1=\\frac12$, while the second gives $\\lambda\_2 = -\\frac12$.

Therefore, $\\pi\_U(e\_2) = \\begin{bmatrix} \\frac12 \\\\ 0\\\\ -\\frac12 \\end{bmatrix}$.

**Part b**

We have $$d(e\_2,U) = \\lVert e\_2-\\pi\_U(e\_2) \\rVert = \\sqrt{\\left\\langle \\begin{bmatrix}-\\frac12 \\\\ 1\\\\ \\frac12\\end{bmatrix},\\begin{bmatrix}-\\frac12 \\\\ 1\\\\ \\frac12\\end{bmatrix}\\right\\rangle} = 1.$$


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>