---
title: Compute the eigenspaces of a 4 by 4 matrices
categories: [Machine Learning,Linear Algebra]
tags: [Determinant,Matrix,Eigenvector,Eigenvalue]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.4**
{% endnote %}

<!--more-->

Solution: 

If we take $\\det(A-\\lambda I)$ and simplify, we have $$(\\lambda-2)(\\lambda-1)(\\lambda+1)^2.$$ So we have three eigenvalues. For $\\lambda=2,1$, our eigenspace will certainly have dimension 1. For $\\lambda = -1$, it could (at this stage!) have dimension 1 or 2.

Observe that $(1,0,1,1)$ is an eigenvector with eigenvalue 2, and $(1,1,1,1)$ is an eigenvector with eigenvalue 1. Thus $$E\_2=\mathrm{span}\\{(1,0,1,1)\\}$$ and $$E\_1 = \mathrm{span}\\{(1,1,1,1)\\}.$$

Now observe that $\mathrm{rank}(A+I)=3$, so there can only be one linearly independent eigenvector with eigenvalue -1. Note that $(0,1,1,0)$ will do. Hence $$E\_{-1} = \mathrm{span}\\{(0,1,1,0)\\}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>