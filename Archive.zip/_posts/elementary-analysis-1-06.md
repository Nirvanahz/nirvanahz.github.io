---
title:  Using the principle of mathematical induction to show divisibility I
categories: [Solution,Elementary Analysis]
tags: [Induction,Number Theory]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 1 Exercise 1.6
{% endnote %}

<!--more-->

Solution: The $n$-th proposition is
$$
P_n: \quad 7 \text{ divides } 11^n-4^n.
$$ Clearly, $P_1$ is true because $11^1-4^1$ is exactly 7. We have the induction basis.

Now we assume $P_n$ is true, that is $7$ divides $11^n-4^n$. We would like to show $P_{n+1}$ is true based on $P_n$. Note that we have
\\begin{align\*}
11^{n+1}-4^{n+1}=&\ 11^{n+1}-4\cdot 11^n+4\cdot 11^n -4^{n+1}\\\\
=&\ (11\cdot 11^n-4\cdot 11^n)+(4\cdot 11^n -4^{n+1})\\\\
=&\ 7\cdot 11^n+4(11^n-4^n).
\\end{align\*} Since $7$ divides $11^n-4^n$ by $P_n$, we have $7\cdot 11^n+4(11^n-4^n)$ is divisible by $7$. By the equation above, we conlude that $11^{n+1}-4^{n+1}$ is divisible by 7. Therefore $P_{n+1}$ is true if $P_n$ is true. By the principle of mathematical induction, we make the conclusion that $P_n$ is true for all positive integers $n$.

{% note default %}
This statement also follows from the following well-known formula,
$$
x^n-y^n=(x-y)(x^{n-1}+x^{n-2}\cdot y+\cdots x\cdot y^{n-2}+y^{n-1}).
$$ Let $x=11$ and $y=4$, we have
$$
11^n-4^n=7(11^{n-1}+4\cdot 11^{n-2}+\cdots + 4^{n-2}\cdot 11+4^{n-1}).
$$
{% endnote %}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>