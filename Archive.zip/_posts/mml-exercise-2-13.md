---
title: Find a basis of the intersection of two solution spaces
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Basis,Linear Equations]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.13**
{% endnote %}

<!--more-->

Solution:

**Part a**

We can compute $\mathsf{rank}({A\_1})=2$ and $\mathsf{rank}({A\_2})=2$ also. Since both matrices map from $\\mathbb{R}^3$ to $\\mathbb{R}^4$, we must have that the nullity of both of the matrices is 1. Therefore, $U\_1$ and $U\_2$ both have dimension 1, since they $are$ the kernels of their respective maps.

**Part b**

Since the spaces have dimension 1, we are again simply looking for a non-zero vector in each space. Observe that $(1,1,-1)^{\\mathsf{T}}$ lies in both spaces, so $\\{ (1,1,-1)^{\\mathsf{T}} \\}$ is a basis for both.

**Part c**

From the previous part, we have that $U\_1=U\_2$, so $U\_1\\cap U\_2 = U\_1$ also, and again has $\\{ (1,1,-1)^{\\mathsf{T}} \\}$ as a basis.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>