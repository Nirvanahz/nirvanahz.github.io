---
title: Properties of operations on convex sets
categories: [Machine Learning,Calculus]
tags: [Convex Set,Intersection,Union,Difference]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 7 Exercise 7.3**
{% endnote %}

<!--more-->

Solution: 

**Part a**

Solution: True. Let $\\mathcal C\_1$ and $\\mathcal C\_2$ be two convex sets. We would like to show that $\\mathcal C\_1\\cap \\mathcal C\_2$ is convex.

If $\\mathcal C\_1\\cap \\mathcal C\_2$ is empty then we are done. Suppose $\\mathcal C\_1\\cap \\mathcal C\_2$ is nonempty. By definition 7.2, we would like to show that for any $x, y\\in \\mathcal C\_1\\cap \\mathcal C\_2$, we have $$\\theta x +(1-\\theta)y\\in \\mathcal C\_1\\cap \\mathcal C\_2$$for all $\\theta\\in \[0,1\]$.

Since $x, y\\in \\mathcal C\_1\\cap \\mathcal C\_2$, we have $x, y\\in \\mathcal C\_1$. By definition 7.2 we have \\begin{equation}\\label{mml7.3.1}\\theta x +(1-\\theta)y\\in \\mathcal C\_1\\end{equation}for all $\\theta\\in \[0,1\]$. Similarly, we have \\begin{equation}\\label{mml7.3.2}\\theta x +(1-\\theta)y\\in \\mathcal C\_2\\end{equation}for all $\\theta\\in \[0,1\]$. Therefore, combining \\eqref{mml7.3.1} and \\eqref{mml7.3.2}, we have$$\\theta x +(1-\\theta)y\\in \\mathcal C\_1\\cap \\mathcal C\_2$$for all $\\theta\\in \[0,1\]$. Hence the statement is true.

Remark: The intersection of any convex sets (not necessarily finitely many) is convex.

* * *

**Part b**

Solution: False. Definition 7.2 can be restated as follows: A set is convex if and only if the segment connecting any two points in this set is again contained in this set. Here is a counterexample. Take two disks which are non-intersecting. Clearly, a disk is convex. But they are union is not. Because the blue segment is not contained in the union of the two disks.

![Solution to Mathematics for Machine Learning Exercise 7.3](https://cdn.jsdelivr.net/gh/MathPage/gitalk/img/IMG_355652056C03-1.jpeg)

* * *

**Part c**

Solution: False. Take a big disk and removing a smaller disk inside of it. See the picture below. Then the new set shaded in green color is not convex because the purple segment is not contained in the new set.

![Solution to Mathematics for Machine Learning Exercise 7.3](https://cdn.jsdelivr.net/gh/MathPage/gitalk/img/IMG_52CBCB79387F-1.jpeg)

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_default_search_phrase = "Calculus";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "f4d7cee51e59d583948f31cc8ab6b79a";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "top";
amzn_assoc_title = "Shop Related Products";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>