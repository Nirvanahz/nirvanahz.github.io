---
title: $AA^T$ and $A^TA$ has the same nonzero eigenvalues
categories: [Machine Learning,Linear Algebra]
tags: [Matrix,Eigenvector,Eigenvalue,SVD]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.11**
{% endnote %}

<!--more-->

Solution: We start by showing that if $\\lambda\\neq 0$ is an eigenvalue of $\\boldsymbol{A}\\boldsymbol A^\\top$ then it is also a non-zero eigenvalue of $\\boldsymbol A^\\top\\boldsymbol A$. 

Let $\\lambda\\neq 0$ be an eigenvalue of $\\boldsymbol A\\boldsymbol A^\\top$ and $\\vec q$ be a corresponding eigenvector, i.e., $(\\boldsymbol A\\boldsymbol A^\\top)\\vec q = \\lambda\\vec q$. Then 

\\begin{align\*} 
(\\boldsymbol A^\\top\\boldsymbol A)\\boldsymbol A^\\top\\vec q = \\boldsymbol A^\\top(\\boldsymbol A\\boldsymbol A^\\top \\vec q) = \\boldsymbol A^\\top(\\lambda \\vec q) = \\lambda \\boldsymbol A^\\top\\vec q. 
\\end{align\*} 

*We now need to show that $\\boldsymbol A^\\top\\vec q\\neq 0$ before we can conclude that $\\lambda$ is an eigenvalue of $\\boldsymbol A^\\top\\boldsymbol A$.*

Assume $\\boldsymbol A^\\top\\vec q = \\vec 0$. Then it would follow that $$\\boldsymbol A\\boldsymbol A^\\top\\vec q = \\vec 0,$$ which contradicts $$\\boldsymbol A\\boldsymbol A^\\top\\vec q = \\lambda\\vec q\\neq \\vec 0$$ since $\\vec q$ is an eigenvector of $\\boldsymbol A\\boldsymbol A^\\top$ with associated eigenvalue $\\lambda$. Therefore, $\\vec q\\neq \\vec 0$, which implies that $\\boldsymbol A^\\top\\vec q\\neq \\vec 0$. Therefore, $\\lambda$ is an eigenvalue of $\\boldsymbol A^\\top\\boldsymbol A$ with $\\boldsymbol A^\\top\\vec q$ as the corresponding eigenvector.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>