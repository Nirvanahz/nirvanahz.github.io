---
title: Compute the determinant using Laplace expansion and Sarrus rule
categories: [Machine Learning,Linear Algebra]
tags: [Determinant,Laplace Expansion]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.1**
{% endnote %}

<!--more-->

Solution: By Laplace expansion using the first row, we have \\begin{align\*}\\det(A)=&\\ 1\\cdot \\begin{vmatrix}4 & 6\\\\ 2 & 4\\end{vmatrix}-3\\cdot \\begin{vmatrix}2 & 6\\\\ 0 & 4\\end{vmatrix} + 5\\cdot \\begin{vmatrix}2 & 4\\\\ 0 & 2\\end{vmatrix}\\\\=&\\ 1(4\\cdot 4-6\\cdot 2)-3\\cdot(2\\cdot 4-6\\cdot 0)+5\\cdot(2\\cdot 2-4\\cdot 0)\\\\ =& \\ 4-3\\cdot 8+5\\cdot 4=0.\\end{align\*}

Or by Sarrus rule, we have \\begin{align\*}\\det(A)=&\\ 1\\cdot 4\\cdot 4+2\\cdot 2\\cdot 5+0\\cdot 3\\cdot 6-0\\cdot 4\\cdot 5-1\\cdot 2\\cdot 6-2\\cdot 3\\cdot 4\\\\=&\\ 16+20-12-24=0.\\end{align\*}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>