---
title:  Wrong induction basis may give a completely wrong statement
categories: [Solution,Elementary Analysis]
tags: [Induction,Number Theory]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 1 Exercise 1.11
{% endnote %}

<!--more-->

Solution: 

### Part a

If $n^2+5n+1$ is even, then
\\begin{equation}\label{1-11-1}
(n+1)^2+5(n+1)+1=(n^2+5n+1)+2n+6
\\end{equation} is also even. Therefore $P_{n+1}$ is true whenever $P_n$ is true.

### Part b

There is no integer $n$ such that $n^2+5n+1$ is even. It can be seen easily by looking at $P_1:1^2+5\cdot 1+1$ is even which is clearly wrong. In factor, using \eqref{1-11-1}, one can show that $n^2+5n+1$ is odd by induction. You just need to show it like Part a.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>