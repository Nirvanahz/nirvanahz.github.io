---
title: An identity that can be used to show Cauchy-Schwarz inequality
categories: [Machine Learning,Statistics]
tags: [Basic Identity,Cauchy-Schwarz Inequality]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.7**
{% endnote %}

<!--more-->

Solution: 

Let us expand the square in the left-hand side of (6.45)

$$ \\frac{1}{N^2}\\sum\_{i,j=1}^N(x\_i - x\_j)^2 = \\frac{1}{N^2}\\sum\_{i,j=1}^N(x\_i^2 - 2x\_i x\_j + x\_j^2) = \\frac{1}{N^2}\\sum\_{i,j=1}^N x\_i^2 - 2\\frac{1}{N^2}\\sum\_{i,j=1}^N x\_i x\_j + \\frac{1}{N^2}\\sum\_{i,j=1}^Nx\_j^2 $$

We see that the first and the last term differ only by the summation index, i.e. they are identical: $$ \\frac{1}{N^2}\\sum\_{i,j=1}^N x\_i^2 + \\frac{1}{N^2}\\sum\_{i,j=1}^Nx\_j^2= 2\\frac{1}{N^2}\\sum\_{i,j=1}^N x\_i^2 = 2\\frac{1}{N}\\sum\_{i=1}^N x\_i^2, $$

since summation over $j$ gives factor $N$.

The remaining term can be written as

$$ 2\\frac{1}{N^2}\\sum\_{i,j=1}^N x\_i x\_j = 2\\frac{1}{N^2}\\sum\_{i=1}^N x\_i \\sum\_{i=1}^N x\_j = 2\\left(\\frac{1}{N}\\sum\_{i=1}^N x\_i\\right)^2, $$

where we again used the fact that the sum is invariant to the index of summation.

We thus have proved the required relation that

$$ \\frac{1}{N^2}\\sum\_{i,j=1}^N(x\_i - x\_j)^2 = 2\\frac{1}{N}\\sum\_{i=1}^N x\_i^2 - 2\\left(\\frac{1}{N}\\sum\_{i=1}^N x\_i\\right)^2 $$

{% note default %}
In particular, it shows that $$\\frac{1}{N}\\sum\_{i=1}^N x\_i^2 \geq  \\left(\\frac{1}{N}\\sum\_{i=1}^N x\_i\\right)^2$$
{% endnote %}

{% note info %}
A more general identity is the following,

$$
\Big(\sum_{i=1}^n a_i^2\Big)\Big(\sum_{i=1}^n b_i^2\Big)- \Big(\sum_{i=1}^n a_ib_i\Big)^2=\frac{1}{2}\sum_{i,j=1}^n (a_ib_j-a_jb_i)^2.
$$
{% endnote %}

This one can be proved in the same way. Moreover, this identity shows the classical Cauchy-Schwarz ineqaulity,

$$
\Big(\sum_{i=1}^n a_i^2\Big)\Big(\sum_{i=1}^n b_i^2\Big)\geq\Big(\sum_{i=1}^n a_ib_i\Big)^2.
$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>