---
title: Compute the gradient for a multivariable function
categories: [Machine Learning,Calculus]
tags: [Derivative,Multivariable Calculus]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 5 Exercise 5.9**
{% endnote %}

<!--more-->

Solution: 

Piecing this together, replacing $z$ with $t(\\epsilon,\\nu)$ throughout, we have that $$g(\\nu) = \\log(p(x,t(\\epsilon,\\nu))) - \\log(q(t(\\epsilon,\\nu),\\nu)).$$

Therefore, $$\\frac{dg}{d\\nu} = \\frac{p'(x,t(\\epsilon,\\nu))\\cdot t'(\\epsilon,\\nu) }{p(x,t(\\epsilon,\\nu))} - \\frac{q'(t(\\epsilon,\\nu),\\nu)\\cdot t'(\\epsilon,\\nu)}{q(t(\\epsilon,\\nu),\\nu)}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Real Analysis";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "402d8b59cc9faa66d8d6b3b1eef9c01e";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "bottom";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>