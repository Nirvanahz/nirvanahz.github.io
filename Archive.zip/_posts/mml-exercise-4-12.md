---
title: The largest singular value of a matrix
categories: [Machine Learning,Linear Algebra]
tags: [Matrix,Eigenvector,Eigenvalue,SVD]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.12**
{% endnote %}

<!--more-->

Solution: By SVD (Singular Value Decomposition), we have $A=U\\Sigma V^T$. Let $y=V^T x$, then \\\[\\|y\\|\_2^2=y^Ty=(V^Tx)^TV^Tx=x^TVV^Tx=x^Tx=\\|x\\|\_2^2.\\\]Then we have\\begin{align\*}\\|A x\\|\_2^2=&\\ (Ax)^T(Ax)=x^TA^TAx\\\\ = &\\ x^T V \\begin{bmatrix}\\sigma\_1^2 & 0 & 0\\\\ 0 & \\ddots & 0\\\\ 0 & 0 &\\sigma\_n^2\\end{bmatrix}V^Tx \\\\ =&\\ y^T \\begin{bmatrix}\\sigma\_1^2 & 0 & 0\\\\ 0 & \\ddots & 0\\\\ 0 & 0 &\\sigma\_n^2\\end{bmatrix} y \\\\ = &\\ \\sigma\_1^2 y\_1^2+\\cdots+\\sigma\_n^2y\_n^2 \\\\ \\leqslant &\\ \\sigma\_1^2 y\_1^2+\\cdots+\\sigma\_1^2y\_n^2\\\\ =&\\ \\sigma\_1^2(y\_1^2+\\cdots+y\_n^2)\\\\ =&\\ \\sigma\_1^2 \\|y\\|\_2^2= \\sigma\_1^2 \\|x\\|\_2^2.\\end{align\*}Hence we have \\\[\\max\_{x\\ne 0}\\frac{\\|Ax\\|\_2}{\\|x\\|\_2}\\leqslant \\sigma\_1^2.\\\]Moreover, it is possible to choose $x$ such that the inequality above becomes equality. Namely, setting $$x=V(1,0,\\dots,0)^T,$$then $y=(1,0,\\dots,0)^T$ and $$\\|A x\\|\_2^2=\\sigma\_1^2,\\quad \\|x\\|\_2=1.$$Hence we proved Theorem 4.24.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>