---
title: Compute the Taylor polynomials of trigonometric functions
categories: [Machine Learning,Calculus]
tags: [Derivative,Taylor Series]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 5 Exercise 5.4**
{% endnote %}

<!--more-->

Solution: By Definition 5.3, we have to compute $f(x\_0)$, $f'(x\_0)$, $f^{(2)}(x\_0)$, $f^{(3)}(x\_0)$, $f^{(4)}(x\_0)$, $f^{(5)}(x\_0)$. It is not hard to see that $$f'(x)=\\cos x -\\sin x,$$ $$f^{(2)}(x)=-\\sin x-\\cos x,$$ $$f^{(3)}(x)=-\\cos x + \\sin x,$$ $$f^{(4)}(x)=\\sin x+\\cos x,$$ $$f^{(5)}(x)=\\cos x-\\sin x.$$ Hence we get $$f(0)=f'(0)=f^{(4)}(0)=f^{(5)}(0)=1,$$ $$f^{(2)}(0)=f^{(3)}(0)=-1.$$Now it is easy to see that $$T\_0=1,$$ $$T\_1=x+1,$$ $$T\_2=-\\frac{1}{2}x^2+x+1,$$ $$T\_3=-\\frac{1}{6}x^3-\\frac{1}{2}x^2+x+1$$ $$T\_4=\\frac{1}{24}x^4-\\frac{1}{6}x^3-\\frac{1}{2}x^2+x+1,$$ $$T\_5=\\frac{1}{120}x^5+\\frac{1}{24}x^4-\\frac{1}{6}x^3-\\frac{1}{2}x^2+x+1.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Real Analysis";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "402d8b59cc9faa66d8d6b3b1eef9c01e";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "bottom";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>