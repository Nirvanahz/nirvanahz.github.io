---
title: Find a basis of the intersection of two solution spaces II
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Basis,Linear Equations]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.14**
{% endnote %}

<!--more-->

Solution:

**Part a**

Observe that these matrices are the same as those used in the previous parts, except now our spaces $U\_1$ and $U\_2$ are different. We now have $\\dim (U\_1)=\mathsf{rank}(A\_1)=2$ and $\\dim(U\_2) = \mathsf{rank} (A\_2)=2$.

**Part b**

We are looking for two linearly independent columns in each of our matrices -- we need two non-zero columns, and they can't be a multiple of each other. For example, the first two columns of each matrix will do as a basis for each space.

**Part c**

Note that $\mathsf{rank}(\[A\_1|A\_2\])=3$, i.e. $\\dim(U\_1+U\_2)=3$ (Note that $\[A\_1|A\_2\]$ is just the $4\\times 6$ matrix formed by concatenating $A\_1$ and $A\_2$.) This means that $$\\dim (U\_1\\cap U\_2) = \\dim(U\_1)+\\dim(U\_2)-\\dim(U\_1+U\_2) = 2+2-3=1,$$ so again, to find a basis of $U\_1\\cap U\_2$, we need only find a non-zero vector in the space. We proceed in a similar way to Question 2.12.

Firstly, we observe that we can write $v\_3=v\_1+v\_2$ and $v\_6=v\_4+v\_5$, so these two vectors can safely be ignored. Secondly, observe that $\\left\[v\_1|v\_2|v\_5\\right\]$ has rank three, so (using the notation of Question 12) if we take $\\alpha\_4=1$, say, and solve then we have $\\alpha\_1=3$, $\\alpha\_2=1$, and $\\alpha\_5=0$. In other words, our non-zero vector is $3v\_1+v\_2 = v\_4 = (3,1,7,3)^{\\mathsf{T}}$, and our basis of $U\_1\\cap U\_2$ is $\\{ (3,1,7,3)^{\\mathsf{T}} \\}$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>