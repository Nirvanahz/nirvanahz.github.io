---
title: Derive the dual linear program using Lagrange duality II
categories: [Machine Learning,Calculus]
tags: [Lagrange Duality,Linear Program,Optimization]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 7 Exercise 7.7**
{% endnote %}

<!--more-->

Solution: 

The process is already in Chapter 7.3.2. I will give the answer directly from (7.52) on page 242.

The dual quadratic program is $$  
\\min \_{\\boldsymbol{\\lambda} \\in \\mathbb{R}^{4}}\\ -\\frac{1}{14}\\left(\\left\[\\begin{array}{l}  
5 \\\\  
3  
\\end{array}\\right\]+\\left\[\\begin{array}{cc}  
1 & 0 \\\\  
\-1 & 0 \\\\  
0 & 1 \\\\  
0 & -1  
\\end{array}\\right\]^\\top\\left\[\\begin{array}{c}  
\\lambda\_1 \\\\  
\\lambda\_2 \\\\  
\\lambda\_3 \\\\  
\\lambda\_4  
\\end{array}\\right\]\\right)^\\top\\left\[\\begin{array}{ll}  
4 & -1 \\\\  
\-1 & 2  
\\end{array}\\right\] \\left(\\left\[\\begin{array}{l}  
5 \\\\  
3  
\\end{array}\\right\]+\\left\[\\begin{array}{cc}  
1 & 0 \\\\  
\-1 & 0 \\\\  
0 & 1 \\\\  
0 & -1  
\\end{array}\\right\]^\\top\\left\[\\begin{array}{c}  
\\lambda\_1 \\\\  
\\lambda\_2 \\\\  
\\lambda\_3 \\\\  
\\lambda\_4  
\\end{array}\\right\]\\right)-\\left\[\\begin{array}{c}  
\\lambda\_1 \\\\  
\\lambda\_2 \\\\  
\\lambda\_3 \\\\  
\\lambda\_4  
\\end{array}\\right\]^\\top \\left\[\\begin{array}{c}  
1 \\\\  
1 \\\\  
1 \\\\  
1  
\\end{array}\\right\]  
$$ $$  
\\text { subject to }\\quad\\left\[\\begin{array}{c}  
\\lambda\_1 \\\\  
\\lambda\_2 \\\\  
\\lambda\_3 \\\\  
\\lambda\_4  
\\end{array}\\right\]\\geqslant 0.  
$$

***

{% note info %}
If you are interested in more detail, see below.
{% endnote %}

We introduce $\\mathbf{Q} = \\begin{bmatrix} 2 & 1 \\\\ 1 & 4 \\end{bmatrix}$, $\\mathbf{c} = \\begin{bmatrix} 5\\\\3\\end{bmatrix}$, $ \\mathbf{A} = \\begin{bmatrix} 1 & 0\\\\-1 & 0\\\\ 0 & 1\\\\ 0 & -1 \\end{bmatrix} $ and $ \\mathbf{b}= \\begin{bmatrix} 1\\\\1\\\\1\\\\1 \\end{bmatrix} $

Then the quadratic problem takes form

$$ \\min\_{\\mathbf{x} \\in \\mathbb{R}^2} \\frac{1}{2}\\mathbf{x}^T\\mathbf{Q}\\mathbf{x} + \\mathbf{c}^T\\mathbf{x}$$ $$\\text{subject to } \\mathbf{A}\\mathbf{x} \\leq \\mathbf{b} $$

The Lagrangian corresponding to this problem is

$$ \\mathcal{L}(\\mathbf{x},\\mathbf{\\lambda}) = \\frac{1}{2}\\mathbf{x}^T\\mathbf{Q}\\mathbf{x} + \\mathbf{c}^T\\mathbf{x} + \\mathbf{\\lambda}^T(\\mathbf{A}\\mathbf{x} - \\mathbf{b})= \\frac{1}{2}\\mathbf{x}^T\\mathbf{Q}\\mathbf{x} + (\\mathbf{c}^T+\\mathbf{A}^T\\mathbf{\\lambda})^T\\mathbf{x} - \\mathbf{\\lambda}^T\\mathbf{b} $$

where $\\mathbf{\\lambda} = \\begin{bmatrix}\\lambda\_1\\\\\\lambda\_2\\\\\\lambda\_3\\\\\\lambda\_4\\end{bmatrix}$ We minimize the Lagrangian by setting its gradient to zero, which results in

$$ \\mathbf{Q}\\mathbf{x} + \\mathbf{c}+\\mathbf{A}^T\\mathbf{\\lambda} = 0 \\Rightarrow \\mathbf{x} = -\\mathbf{Q}^{-1}(\\mathbf{c}+\\mathbf{A}^T\\mathbf{\\lambda}) $$

Substituting this back into the Lagrangian we obtain

$$ \\mathcal{D}(\\mathbf{\\lambda})= \\min\_{\\mathbf{x} \\in \\mathbb{R}^2} \\mathcal{L}(\\mathbf{x},\\mathbf{\\lambda}) =-(\\mathbf{c}+\\mathbf{A}^T\\mathbf{\\lambda})^T\\mathbf{Q}^{-1}(\\mathbf{c}+\\mathbf{A}^T\\mathbf{\\lambda})- \\mathbf{\\lambda}^T\\mathbf{b} $$

The dual problem is now

$$ \\max\_{\\mathbf{\\lambda} \\in \\mathbb{R}^4} -(\\mathbf{c}+\\mathbf{A}^T\\mathbf{\\lambda})^T\\mathbf{Q}^{-1}(\\mathbf{c}+\\mathbf{A}^T\\mathbf{\\lambda})- \\mathbf{\\lambda}^T\\mathbf{b}$$ $$\\text{subject to } \\mathbf{\\lambda} \\geq 0, $$ where the parameter vectors and matrices are defined above.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_default_search_phrase = "Calculus";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "f4d7cee51e59d583948f31cc8ab6b79a";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "top";
amzn_assoc_title = "Shop Related Products";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>