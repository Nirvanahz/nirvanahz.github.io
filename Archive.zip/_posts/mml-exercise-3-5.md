---
title: Orthogonal projection and distance in Euclidean space
categories: [Machine Learning,Linear Algebra]
tags: [Inner Product,Orthogonal Projection,Euclidean Space]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.5**
{% endnote %}

<!--more-->

Solution: 

**Part a**

Let $v\_1, \\dots, v\_4$ be the four vectors defined in the question. Observe that $$\\mathsf{rank}\[v\_1|v\_2|v\_3|v\_4\]=3.$$ Moreover, $\\mathsf{rank}\[v\_1|v\_2|v\_3\]=3$, so these three vectors form a basis of $U$. Let $B$ be this matrix of basis vectors, i.e. $B=\[v\_1|v\_2|v\_3\]$.

Now we compute $$B^{\\mathsf{T}}B = \\begin{bmatrix} 9&9&0\\\\ 9&16&-14\\\\ 0&-14&31 \\end{bmatrix}$$ and $$B^{\\mathsf{T}}x = \\begin{bmatrix} 9\\\\23\\\\-25 \\end{bmatrix}.$$

Next, we solve $B^{\\mathsf{T}}B\\lambda = B^{\\mathsf{T}}x$ for $\\lambda$. Using Gaussian elimination, we obtain $\\lambda = \\begin{bmatrix}-3\\\\ 4\\\\ 1 \\end{bmatrix}$.

Finally, $\\pi\_U(x)$ is given by $$B\\lambda = \\begin{bmatrix} 1\\\\-5\\\\-1\\\\-2\\\\3 \\end{bmatrix}.$$

**Part b**

By construction, $d(x,U) = d(x,\\pi\_U(x))$. This is given by $$\\lVert x-\\pi\_U(x) \\rVert = \\begin{Vmatrix}-2\\\\-4\\\\0\\\\6\\\\-2 \\end{Vmatrix}.$$

This norm is given by the square root of the dot product of the vector with itself, so $d(x,U) = \\sqrt{60}=2\\sqrt{15}$.


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>