---
title:  Using the principle of mathematical induction to show inequalities I
categories: [Solution,Elementary Analysis]
tags: [Induction,Inequality]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 1 Exercise 1.8
{% endnote %}

<!--more-->

Solution: 

### Part a

The $n$-th proposition is
$$
P_n: \quad n^2>n+1.
$$ Clearly, $P_2$ is true because $2^2=4$ which is greater than $2+1=3$. We have the induction basis.

Now we assume $P_n$ is true (here we assume that $n\ge 2$), that is $n^2>n+1$. We would like to show $P_{n+1}$ is true based on $P_n$. Note that $n>0$, we have
\\begin{align\*}
(n+1)^2=n^2+2n+1>n+1+2n+1>(n+1)+1.
\\end{align\*} Therefore $P_{n+1}$ is true if $P_n$ is true. By the principle of mathematical induction, we make the conclusion that $P_n$ is true for all positive integers $n$.

---

### Part b

The $n$-th proposition is
$$
P_n: \quad n!> n^2.
$$ Clearly, $P_4$ is true because $4!=24$ which is greater than $4^2=16$. We have the induction basis.

Now we assume $P_n$ is true (here we assume that $n\ge 4$), that is $n!> n^2$. We would like to show $P_{n+1}$ is true based on $P_n$. Note that $n\ge 4$, we have
\\begin{equation}\label{eq:1-8-1}
n^2\ge 4n>n,\quad n^2 >1.
\\end{equation} Therefore
\\begin{align\*}
(n+1)!=&\ (n+1)\cdot n!>4\cdot n^2\\\\
=&\ n^2+2n^2+n^2\\\\
\text{use \eqref{eq:1-8-1}}\quad >&\ n^2+2n+1=(n+1)^2.
\\end{align\*} Therefore $P_{n+1}$ is true if $P_n$ is true. By the principle of mathematical induction, we make the conclusion that $P_n$ is true for all positive integers $n$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>