---
title: Distances between two vectors using difference inner products
categories: [Machine Learning,Linear Algebra]
tags: [Inner Product,Distance]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.3**
{% endnote %}

<!--more-->

Solution: The distance between $\\mathbf x$ and $\\mathbf y$ is given by $\\sqrt{\\langle \\mathbf x-\\mathbf y,\\mathbf x-\\mathbf y\\rangle }$ and we have $$\\mathbf z:=\\mathbf x-\\mathbf y =\\begin{bmatrix}2\\\\3\\\\3\\end{bmatrix}$$ a. In this case, \\begin{align\*}\\langle \\mathbf z,\\mathbf z\\rangle =\\mathbf z^\\top \\mathbf z=2^2+3^2+3^2=22.\\end{align\*}Hence the distance is $\\sqrt{22}$. 

b. In this case, \\begin{align\*}\\langle \\mathbf z,\\mathbf z\\rangle =&\\ \\mathbf z^\\top \\mathbf A\\mathbf z\\\\ =&\\ \[2,3,3\]\\begin{bmatrix}2&1&0\\\\1&3&-1\\\\ 0&-1&2\\end{bmatrix}\\begin{bmatrix}2\\\\3\\\\3\\end{bmatrix}\\\\=&\\ \[7,8,3\]\\begin{bmatrix}2\\\\3\\\\3\\end{bmatrix}=47.\\end{align\*}Hence the distance is $\\sqrt{47}$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>