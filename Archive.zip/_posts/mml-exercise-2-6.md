---
title: Solve systems of inhomogenous linear equations using Gaussian elimination
categories: [Machine Learning,Linear Algebra]
tags: [Matrix,Linear Equations,Gaussian Elimination]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.6**
{% endnote %}

<!--more-->

Solution:

We start with doing $r\_3-r\_1$, to give us $$\\left\[ \\begin{array}{cccccc|c} 0&1&0&0&1&0&2\\\\ 0&0&0&1&1&0&-1\\\\ 0&0&0&0&-1&1&-1 \\end{array} \\right\].$$

Next, do $r\_1+r\_3$, $r+2+r\_3$, and then multiply $r\_3$ by $-1$. This gives $$\\left\[ \\begin{array}{cccccc|c} 0&1&0&0&0&1&1\\\\ 0&0&0&1&0&1&-2\\\\ 0&0&0&0&1&-1&1 \\end{array} \\right\].$$

This corresponds to the equations $x\_2+x\_6=1$, $x\_4+x\_6=-2$, and $x\_5-x\_6 = 1$. Now we can take $x\_1$, $x\_3$ and $x\_6$ to be arbitrary, giving a solution set of $$\\{ (\\alpha, 1-\\beta, \\gamma, -2-\\beta, 1+\\beta, \\beta)^{\\mathsf{T}} : \\alpha,\\beta, \\gamma \\in \\mathbb{R} \\}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>