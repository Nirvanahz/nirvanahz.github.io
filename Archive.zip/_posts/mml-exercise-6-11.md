---
title:  Computation involving iterated expectations and conditional probability
categories: [Machine Learning,Statistics]
tags: [Expectation,Random Variable,Probability]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.11**
{% endnote %}

<!--more-->

Solution: 

The expectation value and the conditional expectation value are given by

$$ \\mathbb{E}\_X\[x\] = \\int x p(x) dx,\\\\ \\mathbb{E}\_Y\[f(y)\] = \\int f(y) p(y) dy,\\\\ \\mathbb{E}\_X\[x|y\] = \\int x p(x|y) dx $$

We then have

\\begin{align\*}\\mathbb{E}\_Y\\left\[\\mathbb{E}\_X\[x|y\]\\right\] =&\\ \\int \\mathbb{E}\_X\[x|y\] p(y) dy = \\int \\left\[\\int xp(x|y)dx\\right\]p(y) dy \\\\=&\\ \\int \\int xp(x|y)p(y)dx dy = \\int\\int xp(x,y)dxdy\\\\ =&\\ \\int x\\left\[\\int p(x,y) dy\\right\] dx = \\int x p(x) dx = \\mathbb{E}\_X\[x\], \\end{align\*}

where we used the definition fo the conditional probability density

$$ p(x|y)p(y) = p(x,y). $$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>