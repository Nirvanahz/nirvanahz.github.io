---
title: Write a vector as a linear combination of other vectors
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Linear Combination]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.11**
{% endnote %}

<!--more-->

Solution:

Here, we need to solve the system of equations \\begin{align\*}\\begin{cases}\\alpha\_1+\\alpha\_2+2\\alpha\_3 = 1,\\\\ \\alpha\_1+2\\alpha\_2-\\alpha\_3=-2, \\\\ \\alpha\_1+3\\alpha\_2+\\alpha\_3 = 5.\\end{cases}\\end{align\*}

Performing Gaussian elimination in the usual way, we determine that $\\alpha\_1 = -6$, $\\alpha\_2 = 3$, and $\\alpha\_3 = 2$. That is to say, $$y=-6x\_1+3x\_2+2x\_3.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>