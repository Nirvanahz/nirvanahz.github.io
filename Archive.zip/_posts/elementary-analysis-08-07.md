---
title: Show the limit does not exist
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit,Triangle Inequality,Proof]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 8 Exercise 8.7
{% endnote %}

<!--more-->

Solution: 

### Part a

Suppose the limit exists and equals $a$. Then for $\epsilon=\dfrac{1}{2}$, there exists $N>0$ such that 
$$
\left|\cos\left(\frac{n\pi}{3}\right)-a\right|<\frac{1}{2}
$$ for all $n>N$. Let $k>N$ be an integer, then we also have by taking $n=6k\pi$ and $n=6k\pi+3\pi$ respectively
$$
\left|\cos\left(\frac{6k\pi}{3}\right)-a\right|<\frac{1}{2},\quad \left|\cos\left(\frac{6k\pi+3\pi}{3}\right)-a\right|<\frac{1}{2}.
$$ Hence we have
$$
|1-a|<\frac{1}{2},\quad |-1-a|<\frac{1}{2}.
$$ Thus by Triangle Inequality we have
$$
2=|1-a-(-1-a)|<|1-a|+|-1-a|<1
$$ which is impossible. We obtain a contradiction. Thus the limit does not exist.

---

### Part b

Suppose the limit exists and equals $a$. Then for $\epsilon=\dfrac{1}{2}$, there exists $N>0$ such that 
$$
\left|(-1)^nn-a\right|<\frac{1}{2}
$$ for all $n>N$. Let $k>N$ be an integer, then we also have by taking $n=2k$ and $n=2k+1$ respectively
$$
\left|(-1)^{2k}2k-a\right|<\frac{1}{2},\quad \left|(-1)^{2k+1}(2k+1)-a\right|<\frac{1}{2}.
$$ Hence we have
$$
|2k-a|<\frac{1}{2},\quad |-2k-1-a|<\frac{1}{2}.
$$ Thus by Triangle Inequality we have
$$
4k+1=|2k-a-(-2k-1-a)|<|2k-a|+|-2k-1-a|<1
$$ which is impossible. We obtain a contradiction. Thus the limit does not exist.

---

### Part c

Suppose the limit exists and equals $a$. Then for $\epsilon=\dfrac{1}{2}$, there exists $N>0$ such that 
$$
\left|\sin\left(\frac{n\pi}{3}\right)-a\right|<\frac{1}{2}
$$ for all $n>N$. Let $k>N$ be an integer, then we also have by taking $n=6k\pi$ and $n=6k\pi+3\pi/2$ respectively
$$
\left|\sin\left(\frac{6k\pi}{3}\right)-a\right|<\frac{1}{2},\quad \left|\sin\left(\frac{6k\pi+3\pi/2}{3}\right)-a\right|<\frac{1}{2}.
$$ Hence we have
$$
|0-a|<\frac{1}{2},\quad |1-a|<\frac{1}{2}.
$$ Thus by Triangle Inequality we have
$$
1=|0-a-(1-a)|<|0-a|+|1-a|<1
$$ which is impossible. We obtain a contradiction. Thus the limit does not exist.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>