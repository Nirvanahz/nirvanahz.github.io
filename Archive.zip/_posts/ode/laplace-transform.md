---
title:  An introduction to Laplace Transform
categories: [Tutorial,Differential Equation]
tags: [Laplace Transform, Integration by Parts]
mathjax: true

---

In the article, we discuss basics of Laplace transform. The Laplace transform, named after its inventor Pierre-Simon Laplace, is an integral transform that converts a function of a real variable $t$ (often time) to a function of a complex variable (we focus on real $s$) $s$ (complex frequency). The transform has many applications in science and engineering because it is a tool for solving differential equations.

<!--more-->
---

### Definition of Laplace Transform

Recall that for a function $f(t)$ defined on $[0,\infty)$, we say that the integeral $\displaystyle\int_0^\infty f(t)dt$ *converges* if the limit exists
$$
\lim_{a\to 0}\int_0^{a}f(t)dt.
$$ Otherwise, we say it *diverges*. In this case, such an integral is not well-defined.

{% note info %}
**Definition.** Give a function $f(t)$ defined on $[0,\infty)$, the *Laplace transform* maps $f(t)$ to a new function $F(s)$ by the formula,
\\begin{equation}\label{Laplace}
\mathcal L\\{f(t)\\}=\int_0^\infty e^{-st}f(t)dt,
\\end{equation} if the integral converges.
{% endnote %}

We remark that the function $K(s,t)=e^{-st}$ used here is called a *kernel* of an integral transform. 

---

### Formulas of Laplace Transform

In this section, we compute the Laplace transform of some basic functions such as polynomials, trigonometric functions, and exponentials.

{% note default %}
**Example 1.** Compute $\mathcal L\\{1\\}$.
{% endnote %}

Solution: By \eqref{Laplace}, we have 
$$
\mathcal L\\{1\\}=\int_0^\infty e^{-st}dt.
$$ If $s=0$, it is clear that such integral diverges. Now suppose $s\ne 0$, then we have 
$$
\mathcal L\\{1\\}=\int_0^\infty e^{-st}dt=\frac{e^{-st}}{-s}\Big|\_{0}^{\infty}.
$$ This integral converges only when the limit $\lim\_{t\to \infty} e^{-st}$. That means we must have $s>0$. Moreover, if $s>0$, then $\lim\_{t\to \infty} e^{-st}=0$. Therefore, 
$$
\mathcal L\\{1\\}=\frac{e^{-st}}{-s}\Big|\_{0}^{\infty}=0-\frac{e^{-s\cdot 0}}{s}=\frac{1}{s}.
$$ We conclude the $L\\{1\\}= \dfrac{1}{s}$ for $s\in (0,\infty)$.

{% note default %}
**Example 2.** Compute $\mathcal L\\{t\\}$.
{% endnote %}

Solution: By \eqref{Laplace}, we have 
$$
\mathcal L\\{t\\}=\int_0^\infty e^{-st}tdt.
$$ We shall use integration by parts, that is the formula
$$
\int f'(t)g(t)dt=f(t)g(t)-\int f(t)g'(t)dt.
$$ Taking $f(t)=\dfrac{e^{-st}}{-s}$ (then $f'(t)=e^{-st}$) and $g(t)=t$, we have
\\begin{align\*}
\int_0^\infty e^{-st}tdt=&\int_0^\infty \left(\dfrac{e^{-st}}{-s}\right)'tdt= \dfrac{e^{-st}t}{-s}\Big|\_{0}^{\infty}-\int_0^\infty \dfrac{e^{-st}}{-s}(t)'dt\\\\
=& (0-0)+\frac{1}{s}\int_0^\infty e^{-st}dt=\frac{1}{s}\cdot\frac{1}{s}=\frac{1}{s^2}.
\\end{align\*} Here we used the fact that $\lim\_{t\to \infty} e^{-st}t=0$ (you can show it using L'Hôpital's rule) if $s>0$ and $\displaystyle\int_0^\infty e^{-st}dt=\frac{1}{s}$ from Example 1. Again, this answer is only for $s\in(0,\infty)$.

{% note default %}
**Exercise.** Compute $\mathcal L\\{t^2\\}$.
{% endnote %}

In general, using integration by parts, we can show that
$$
\mathcal L\\{t^n\\}=\frac{n}{s}\mathcal L\\{t^{n-1}\\}
$$ and hence obtain that $\mathcal L\\{t^n\\}=\dfrac{n!}{s^{n+1}}$ for $n\ge 0$ by induction on $n$.

{% note info %}
We have $\mathcal L\\{t^n\\}=\dfrac{n!}{s^{n+1}}$ for $s>0$.
{% endnote %}

{% note default %}
**Example 3.** Compute $\mathcal L\\{e^{3t}\\}$.
{% endnote %}

Solution: By \eqref{Laplace}, we have 
$$
\mathcal L\\{e^{3t}\\}=\int_0^\infty e^{-st}e^{3t}dt=\int_0^\infty e^{-(s-3)t}dt=\frac{1}{s-3}.
$$ This integeral converges when $s>3$. This follows exactly the same as Example 1.

In general, we have

{% note info %}
$\mathcal L\\{e^{\alpha t}\\}=\dfrac{1}{s-\alpha}$ for $s>\alpha$.
{% endnote %}

{% note default %}
**Example 4.** Compute the Laplace transform of cosine function $\mathcal L\\{\cos(\alpha t)\\}$, where $\alpha$ is a real constant.
{% endnote %}

Solution: We shall use integration by parts twice to compute it. By \eqref{Laplace}, we have 
\\begin{align\*}
\mathcal L\\{\cos(\alpha t)\\}=&\ \int_0^\infty e^{-st}\cos(\alpha t)dt =\int_0^\infty \left(\dfrac{e^{-st}}{-s}\right)'\cos(\alpha t)dt\\\\
=&\ \left(\dfrac{e^{-st}}{-s}\right)\cos(\alpha t)\Big|\_0^\infty-\int_0^\infty \left(\dfrac{e^{-st}}{-s}\right)(-\alpha)\sin(\alpha t)dt\\\\
=&\ \frac{1}{s}-\frac{\alpha}{s}\int_0^\infty e^{-st}\sin(\alpha t)dt\ \left(= {\color{red}\frac{1}{s}-\frac{\alpha}{s}\mathcal L\\{\sin(\alpha t)\\}}\right)\\\\
=&\ \frac{1}{s}-\frac{\alpha}{s}\left(\int_0^\infty \left(\dfrac{e^{-st}}{-s}\right)'\sin(\alpha t)dt \right)\\\\
=&\ \frac{1}{s}-\frac{\alpha}{s}\left(\dfrac{e^{-st}}{-s}\sin(\alpha t)\Big|\_0^\infty-\int_0^\infty \left(\dfrac{e^{-st}}{-s}\right)\alpha\cos(\alpha t)dt \right)\\\\
=&\ \frac{1}{s}-\frac{\alpha}{s}\left(\frac{\alpha}{s}\int_0^\infty e^{-st}\cos(\alpha t)dt \right)\\\\
=&\ \frac{1}{s}-\frac{\alpha^2}{s^2}\int_0^\infty e^{-st}\cos(\alpha t)dt=\frac{1}{s}-\frac{\alpha^2}{s^2}\mathcal L\\{\cos(\alpha t)\\}.
\\end{align\*} Hence we obtain that 
$$
\mathcal L\\{\cos(\alpha t)\\}=\frac{1}{s}-\frac{\alpha^2}{s^2}\mathcal L\\{\cos(\alpha t)\\}.
$$ Solving for $\mathcal L\\{\cos(\alpha t)\\}$, we finally get that
\\begin{equation}\label{eq:L-cos}
\mathcal L\\{\cos(\alpha t)\\}=\frac{s}{s^2+\alpha^2}.
\\end{equation} Recall that in the meanwhile, the following equation is also observed (formulas in red color)
$$
\mathcal L\\{\cos(\alpha t)\\}=\frac{1}{s}-\frac{\alpha}{s}\mathcal L\\{\sin(\alpha t)\\}.
$$ Combining this with \eqref{eq:L-cos}, we get the formula for Laplace transform of sine function $\sin(\alpha t)$,
\\begin{equation}\label{eq:L-sin}
\mathcal L\\{\sin(\alpha t)\\}=\frac{\alpha}{s^2+\alpha^2}.
\\end{equation}

We summarise all the formulas we obtained.
{% note info %}
1. $\mathcal L\\{t^n\\}=\dfrac{n!}{s^{n+1}}$.
2. $\mathcal L\\{e^{\alpha t}\\}=\dfrac{1}{s-\alpha}$.
3. $\mathcal L\\{\sin(\alpha t)\\}=\dfrac{\alpha}{s^2+\alpha^2}$.
4. $\mathcal L\\{\cos(\alpha t)\\}=\dzfrac{s}{s^2+\alpha^2}$.
{% endnote %}


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_default_search_phrase = "Differential equation";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "159d3ae0cb7130e1e6397488c386dfdd";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "top";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>