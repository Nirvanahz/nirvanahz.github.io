---
title:  Solving homogeneous linear differential equations with constant coefficients
categories: [Tutorial,Differential Equation]
tags: [Linear Differential Equation,Auxiliary Equation]
mathjax: true

---

In the article, we discuss how to solve homogeneous linear differential equations with constant coefficients.

<!--more-->

### First order 

We start with the first order homogeneous linear differential equations. In this case, the differential equations have the following form
$$
\frac{dy}{dx}+ky=0\quad\text{or}\quad \frac{dy}{dx}=\alpha y.
$$ For our purpose, we use the second form, then this is a separable equation. Hence we can solve it using separation of variables. Clearly, $y=0$ is a trivial solution to this equation. Now suppose $y$ is nontrivial, that is not identically zero. Then we have 
$$
\frac{dy}{y}=\alpha dx.
$$ Taking the integral for both sides, we have 
$$
\int \frac{dy}{y}=\int \alpha dx\Longrightarrow \ln|y|=\alpha x+c_1.
$$ Therefore, we have
$$
|y|=e^{c_1}e^{\alpha x}\Longrightarrow y=\pm e^{c_1}e^{\alpha x}.
$$ Note that $e^{c_1}$ is always positive, hence $\pm e^{c_1}$ can take any positive or negative values. Recall that $y=0=0e^{\alpha x}$ is also a solution. Hence the general solution in this case can be written compactly as $y=ce^{\alpha x}$.

{% note info %}
The general solution of the first order homogeneous linear differential equation $\dfrac{dy}{dx}=\alpha y$ is $y=ce^{\alpha x}$, where $c$ is an arbtrary real (or complex) number.
{% endnote %}

---

### Second order 

Then we come to our main topic, solving homogeneous linear differential equations with constant coefficients. In general, we consider the second order homogeneous linear differential equations of the form 
\\begin{equation}\\label{2nd-order-ode}
a\frac{d^2y}{dx^2}+b\frac{dy}{dx}+cy=0,
\\end{equation} where $a,b,c$ are real numbers. One may guess that the solution is similar to the first order case, that is an exponential function. Let use first check for what value $m$, the function $y=e^{mx}$ is a solution of the equation \eqref{2nd-order-ode}. By Chain Rule, we have 
$$
y'=me^{mx},\quad y^{\prime \prime}=m^2e^{mx}.
$$ Substituting into \eqref{2nd-order-ode}, we obtain
$$
0=a\frac{d^2y}{dx^2}+b\frac{dy}{dx}+cy=am^2e^{mx}+bme^{mx}+ce^{mx}=(am^2+bm+c)e^{mx}.
$$ Since $e^{mx}$ is never zero, we must have 
\\begin{equation}\\label{aux-equ}
am^2+bm+c=0.
\\end{equation} The equation \eqref{aux-equ} is usually called the *auxiliary equation* of the equation \eqref{2nd-order-ode}. If we can solve \eqref{aux-equ} for $m$, we obtain a solution to \eqref{2nd-order-ode}. This is a quadratic equation with single variable which one can solve it using the quadratic formula
\\begin{equation}\\label{quadratic}
m=\frac{-b+\sqrt{b^2-4ac}}{2a}.
\\end{equation} Note that $\Delta=b^2-4ac$ is called the *discriminant* of \eqref{quadratic}. In general we have three cases depending on the value of the discriminant or the roots of \eqref{aux-equ}.

---

#### Two distinct real roots

If \eqref{aux-equ} has two distinct real roots $\alpha,\beta$ (equivalently it means $\Delta>0$), then we obtain two solutions of \eqref{2nd-order-ode}. Moreover, it is clear that they are linearly independent since we can compute their Wronskian
$$
W(e^{\alpha x},e^{\beta x})=e^{\alpha x}(e^{\beta x})'-(e^{\alpha x})'e^{\beta x}=(\beta-\alpha)e^{(\alpha+\beta)x}\ne 0.
$$ Hence we obtain a fundamental set of solutions of \eqref{2nd-order-ode},
$$
y_1=e^{\alpha x},\quad y_2=e^{\beta x}.
$$ In addition, all solutions of \eqref{2nd-order-ode} are linear combinations of $y_1$ and $y_2$, that is 

{% note info %}
If the auxiliary equation \eqref{aux-equ} of \eqref{2nd-order-ode} has two distinct real roots, then the general solution of \eqref{2nd-order-ode} is
$$
y=c_1e^{\alpha x}+c_2e^{\beta x}.
$$
{% endnote %}

{% note default %}
**Example 1.** Find the general solution of $\dfrac{d^2y}{dx^2}+5\dfrac{dy}{dx}+6y=0$.
{% endnote %}

Solution: The auxiliary equation is $m^2+5m+6=0$. Factoring it, we have 
$$
(m+2)(m+3)=0.
$$ Hence it has two solutions $m=-2,-3$. Therefore, the general solution is $y=c_1 e^{-2x}+c_2 e^{-3x}$.

---

#### A double root

If \eqref{aux-equ} has a double real root $\alpha=-\dfrac{b}{2a}$ (equivalently it means $\Delta=0$), then we obtain just one solution $y_1=e^{\alpha x}$ of \eqref{2nd-order-ode} using this method. In order to obtain a fundamental set of solutions of \eqref{2nd-order-ode}, we need one more solution. Recall that if we know a solution for a second order linear differential equation, we are able to get a new solution using the method of reduction of order. Let us recall this procedure. Suppose the other solution is given by $y_2(x)=u(x)y_1(x)$, then we have
$$
y_2'(x)=u'(x)y_1(x)+u(x)y_1'(x),
$$ $$
y_2^{\prime\prime}(x)=u^{\prime\prime}(x)y_1(x)+2u'(x)y_1'(x)+y_1^{\prime\prime}(x),
$$ \\begin{equation}\\label{proof-double}
2ay_1'(x)+by_1(x)=2a\alpha e^{\alpha x}+be^{\alpha x}=(2a\alpha +b)e^{\alpha x}=0.
\\end{equation} If $y_2(x)$ is a solution of \eqref{2nd-order-ode}, we must have
$$
ay_2^{\prime\prime}(x)+by_2'(x)+cy_2(x)=0,
$$ that is
\\begin{align\*}
& a(u^{\prime\prime}(x)y_1(x)+2u'(x)y_1'(x)+u(x)y_1^{\prime\prime}(x))+b(u'(x)y_1(x)+u(x)y_1'(x))+cu(x)y_1(x)\\\\
=& au^{\prime\prime}(x)y_1(x)+u'(x)(2ay_1'(x)+by_1(x))+u(x)(ay_1^{\prime\prime}(x)+by_1'(x)+cy(x))\\\\
=& au^{\prime\prime}(x)y_1(x)+u'(x)\cdot 0+u(x)\cdot 0=au^{\prime\prime}(x)y_1(x),
\\end{align\*} here we used \eqref{proof-double} and $y_1(x)$ is a solution of \eqref{2nd-order-ode}. Hence we only need to take a function $u(x)$ such that $u''(x)=0$. A good chocie which would give a new solution is $u(x)=x$ ($u(x)=c$ is no good since $y_2(x)$ and $y_1(x)$ will be linearly dependent). Thus $y_2(x)=xe^{\alpha x}$ is a new solution of \eqref{2nd-order-ode}. It suffices to check that $y_1(x)=e^{\alpha x}$ and $y_2(x)=xe^{\alpha x}$ are linearly independent. This can be done using Wronskian as well (it can also be done directly since $e^{\alpha x}$ is never zero),
$$
W(e^{\alpha x},xe^{\alpha x})=e^{\alpha x}(xe^{\alpha x})'-(e^{\alpha x})'xe^{\alpha x}=e^{2\alpha x}\ne 0.
$$ Therefore, we have

{% note info %}
If the auxiliary equation \eqref{aux-equ} of \eqref{2nd-order-ode} has a double real root, then the general solution of \eqref{2nd-order-ode} is
$$
y=c_1e^{\alpha x}+c_2xe^{\alpha x}=(c_1+c_2x)e^{\alpha x}.
$$
{% endnote %}

{% note default %}
**Example 2.** Find the general solution of $\dfrac{d^2y}{dx^2}+6\dfrac{dy}{dx}+9y=0$.
{% endnote %}

Solution: The auxiliary equation is $m^2+6m+9=0$. Factoring it, we have 
$$
(m+3)^2=0.
$$ Hence it has a double root $m=-3$. Therefore, the general solution is $y=c_1 e^{-3x}+c_2 xe^{-3x}$.

---

#### Two complex roots

If \eqref{aux-equ} has two complex roots, then they must be complex conjugate to each other, namely these two roots have the form $\alpha +\beta i$, where $\alpha,\beta$ are real numbers. Then we obtain two solutions 
$$
\tilde y_1(x)=e^{(\alpha+\beta i)x},\quad \tilde y_2(x)=e^{(\alpha-\beta i)x}.
$$
Usin Euler's identity $e^{\theta i}=\cos\theta +i\sin\theta$ for $\theta\in \mathbb R$, we have
$$
\tilde y_1(x)=e^{(\alpha+\beta i)x}=e^{\alpha x}e^{i\beta x}=e^{\alpha x}(\cos(\beta x)+i\sin (\beta x)),
$$ $$
\tilde y_2(x)=e^{(\alpha-\beta i)x}=e^{\alpha x}e^{-i\beta x}=e^{\alpha x}(\cos(-\beta x)+i\sin (-\beta x))=e^{\alpha x}(\cos(\beta x)-i\sin (\beta x)).
$$ However, they are complex solution which are not good. We need to find real solutions. To do that, we try to get new real solutions by taking complex linear combinations of those two solutions. Explicitly, we consider
$$
y_1(x)=\frac{\tilde  y_1(x)+\tilde y_2(x)}{2}=e^{\alpha x}\cos(\beta x),
$$ $$
y_2(x)=\frac{\tilde  y_1(x)-\tilde y_2(x)}{2i}=e^{\alpha x}\sin(\beta x).
$$ Then $y_1(x)$ and $y_2(x)$ are solutions of \eqref{2nd-order-ode}. Moreover, they are linearly independent as the Wronskian is nonzero,
$$
W(e^{\alpha x}\cos(\beta x),e^{\alpha x}\sin(\beta x))=e^{2\alpha x}\ne 0.
$$ Therefore, we obtain the following

{% note info %}
If the auxiliary equation \eqref{aux-equ} of \eqref{2nd-order-ode} has complex solutions $\alpha\pm\beta i$, then the general solution of \eqref{2nd-order-ode} is
$$
y=c_1e^{\alpha x}\cos(\beta x)+c_2e^{\alpha x}\sin(\beta x)=(c_1\cos(\beta x)+c_2\sin(\beta x))e^{\alpha x}.
$$
{% endnote %}

{% note default %}
**Example 3.** Find the general solution of $\dfrac{d^2y}{dx^2}+4\dfrac{dy}{dx}+13y=0$.
{% endnote %}

Solution: The auxiliary equation is $m^2+4m+13=0$. Solving it using the quadratic formula \eqref{quadratic}, we have 
$$
m=-2\pm 3i
$$ Hence it has two complex roots $\alpha\pm\beta i$, where $\alpha =-2$ and $\beta =3$. Therefore, the general solution is $y=(c_1\cos 3x+c_2\sin 3x) e^{2x}$.

---

### Higher orders

Let us consider higher order case
\\begin{equation}\label{higher-ode}
a_n\frac{d^ny}{dx^n}+a_{n-1}\frac{d^{n-1}y}{dx^{n-1}}+\cdots+a_1\frac{dy}{dx}+a_0y=0,
\\end{equation} where $a_n,a_{n-1},\dots,a_1,a_0$ are real numbers. Then we consider the corresponding *auxiliary equation*
\\begin{equation}\label{higher-aux}
a_nm^n+a_{n-1}m^{n-1}+\cdots+a_1m+a_0=0.
\\end{equation} The rule to get the auxiliary equation is that the $n$-th derivative of $y$ becomes $m^n$. Note that $y$ is considered as the 0-th derivative and hence corresponds to 1.

We give the result without a proof.

Suppose \eqref{higher-aux} has a real root $\alpha$ of multiplicity $k_{\alpha}$, then we obtain $k_{\alpha}$ solutions of \eqref{higher-ode}
\\begin{equation}\label{higher-solution-1}
e^{\alpha x},\ xe^{\alpha x},\dots, \ x^{k_{\alpha}-1}e^{\alpha x}.
\\end{equation} Suppose \eqref{higher-aux} has a complex root $\alpha+\beta i$ of multiplicity $k_{\alpha,\beta}$, then $\alpha-\beta i$ is also a root of multiplicity $k_{\alpha,\beta}$. We obtain $2k_{\alpha,\beta}$ solutions of \eqref{higher-ode}
\\begin{equation}\label{higher-solution-2}
e^{\alpha x}\cos(\beta x),\ xe^{\alpha x}\cos(\beta x),\dots, \ x^{k_{\alpha,\beta}-1}e^{\alpha x}\cos(\beta x),
\\end{equation} \\begin{equation}\label{higher-solution-3}
e^{\alpha x}\sin(\beta x),\ xe^{\alpha x}\sin(\beta x),\dots, \ x^{k_{\alpha,\beta}-1}e^{\alpha x}\sin(\beta x).
\\end{equation} Then the general solution of \eqref{higher-ode} is obtained by taking linear combinations of all such solutions in \eqref{higher-solution-1}, \eqref{higher-solution-2}, \eqref{higher-solution-3} with all possible roots of the auxiliary equation \eqref{higher-aux}.

{% note default %}
**Example 4.** Find the general solution of $\dfrac{d^4y}{dx^4}+2\dfrac{d^2y}{dx^2}+y=0$.
{% endnote %}

Solution: The auxiliary equation is $m^4+2m^2+1=0$. Solving it by noticing that $m^4+2m^2+1=(m^2+1)$, we have 
$$
m=\pm i,\pm i. 
$$ Hence the auxiliary equation has two complex roots $\pm i$ each with multiplicity 2. Therefore, the general solution is $y=(c_1+c_2 x)\cos x+(c_3+c_4 x)\sin x$.

---

### Exercise

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_default_search_phrase = "Differential equation";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "159d3ae0cb7130e1e6397488c386dfdd";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "top";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>