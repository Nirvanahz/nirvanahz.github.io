---
title:  Determine if a real number is rational using roots of polynomial IV
categories: [Solution,Elementary Analysis]
tags: [Rational Number,Polynomial]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 2 Exercises 2.5
{% endnote %}

<!--more-->

{% note default %}
Our main tool is Corollary 2.3.
{% endnote %}

Solution: First, we need to find an equation with integer coefficients such that $(3+\sqrt{2})^{2/3}$ is a solution to it. 

Let $x=(3+\sqrt{2})^{2/3}$. Taking cube for both sides, we obtain that $x^3=(3+\sqrt{2})^{2}$. Hence 
$$
x^3=9+6\sqrt 2+2=11+6\sqrt 2.
$$ In particular, $x^3-11=6\sqrt 2$. Squaring both sides, we get
$$
(x^3-11)^2=72,
$$ which is 
$$
x^6-22x^3+49=0.
$$ Consider the rational solution of $x^6-22x^3+49=0$. It follows from Corollary 2.3 that those rationa solutions can only be $\pm 1$,$\pm 7$, $\pm 49$.

Direct computations would show that none of them will be a solution of $x^6-22x^3+49=0$. Hence $x^6-22x^3+49=0$ has no rational solutions. Therefore, as a solution to $x^6-22x^3+49=0$, $(3+\sqrt{2})^{2/3}$ is irrational.



<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>