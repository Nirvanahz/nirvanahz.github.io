---
title: Check if a Bilinear form is an Inner Product
categories: [Machine Learning,Linear Algebra]
tags: [Inner Product]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.2**
{% endnote %}

<!--more-->

Solution: Let $\\mathbf x=\[x\_1,x\_2\]^\\top$, $\\mathbf y=\[y\_1,y\_2\]^\\top$. By direct computations, we have $$\\langle \\mathbf x,\\mathbf y\\rangle=2x\_1y\_1+x\_2y\_1+2x\_2y\_2$$ and $$\\langle \\mathbf y,\\mathbf x\\rangle=2x\_1y\_1+y\_2x\_1+2x\_2y\_2.$$Therefore, in general, we see that $\\langle \\mathbf x,\\mathbf y\\rangle \\ne \\langle \\mathbf y,\\mathbf x\\rangle$. This implies that $\\langle ,\\rangle$ is not an inner product.

***

In general, to be an inner, it requires $\\langle \\mathbf x,\\mathbf y\\rangle =\\langle \\mathbf y,\\mathbf x\\rangle$. That means $$\\mathbf x^T\\mathbf A\\mathbf y=\\mathbf y^T \\mathbf A \\mathbf x.$$Note that $x^T\\mathbf A\\mathbf y$ is a number and hence equal to its transpose $y^T\\mathbf A^T\\mathbf x$. Therefore, it suffices to make sure $$y^T\\mathbf A^T\\mathbf x=\\mathbf y^T \\mathbf A \\mathbf x,$$ $$y^T (\\mathbf A^T-\\mathbf A)\\mathbf x=0.$$Because of this, $A$ has to be symmetric. 

In the complex situation, then we need $\bar{\mathbf{A}}^T=\mathbf A$ since $$\langle \mathbf x,\mathbf y\rangle =\overline{\langle \mathbf y,\mathbf x\rangle}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>