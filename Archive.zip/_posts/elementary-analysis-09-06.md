---
title: Finding the limit by solving equation needs convergence
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 9 Exercise 9.6
{% endnote %}

<!--more-->

Solution: 

### Part a

This part is the same as that of [Exercise 9.4](/elementary-analysis-09-04.html) and [Exercise 9.5](/elementary-analysis-09-05.html). One needs to solve 
$$
a=3a^2
$$ for $a$. Hence $a=0$ or $a=\dfrac{1}{3}$.

### Part b

The sequence $x_1$ diverges to $+\infty$. Indeed, one can show that $x_n\ge 3^{n-1}$ by induction and hence $\lim x_n=+\infty$.

We show $x_n\ge 3^{n-1}$ by induction. The base case is clear. 

Suppose $x_n\ge 3^{n-1}$, we show that $x_{n+1}\ge 3^{n}$. This follows from
$$
x_{n+1}=3x_n^2\ge 3(3^{n-1})^2=3\cdot 3^{2n-2}=3^{2n-1}\ge 3^n.
$$ Hence we have $x_n\ge 3^{n-1}$ for all $n$.

Now it is clear that $\lim x_n$ is infinity.

### Part c

There is no contradiction at all. Part (a) is obtained from the assumption that $\lim x_n$ exists. However, we can show that $\lim x_n$ does not exist in Part (b). Hence in reality, we cannot obtain $\lim x_n=\dfrac{1}{3}$ or $\lim x_n=0$.

{% note warning %}
This exercise explains if we would like to find limit using the method used in [Exercise 9.4](/elementary-analysis-09-04.html) and [Exercise 9.5](/elementary-analysis-09-05.html). We must show convergence first. Otherwise, such a method cannot be applied at all.
{% endnote %}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>