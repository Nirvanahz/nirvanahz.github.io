---
title:  Find limits of sequences III
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit,Counterexample]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 7 Exercise 7.5
{% endnote %}

<!--more-->

We shall use the following useful formula.

{% note default %}
$\sqrt{a}-b=\dfrac{a-b^2}{\sqrt{a}+b}$, which is a variation of $(a-b)(a+b)=a^2-b^2$.
{% endnote %}

Solution: 

### Part a

Using the formula $\sqrt{a}-b=\dfrac{a-b^2}{\sqrt{a}+b}$, We have 
$$
s_n=\dfrac{(n^2+1)-n^2}{\sqrt{n^2+1}+n}=\frac{1}{\sqrt{n^2+1}+n}.
$$ Now it is clear that $\lim_{n\to 0} s_n=0$.

---

### Part b

Using the formula $\sqrt{a}-b=\dfrac{a-b^2}{\sqrt{a}+b}$, We have 
\\begin{align\*}
s_n
=&\ \dfrac{(n^2+n)-n^2}{\sqrt{n^2+n}+n}\\\\
=&\ \frac{n}{\sqrt{n^2+n}+n}\\\\
=&\ \frac{1}{\sqrt{1+\frac{1}{n}}+1}.
\\end{align\*} In the last step, we simultaneously divide numerator and denominantor by $n$. Now it is clear that $\lim_{n\to 0} s_n=\dfrac{1}{2}$.

---

### Part c

Using the formula $\sqrt{a}-b=\dfrac{a-b^2}{\sqrt{a}+b}$, We have 
\\begin{align\*}
s_n
=&\ \dfrac{(4n^2+n)-4n^2}{\sqrt{4n^2+n}+2n}\\\\
=&\ \frac{n}{\sqrt{4n^2+n}+2n}\\\\
=&\ \frac{1}{\sqrt{4+\frac{1}{n}}+2}.
\\end{align\*} In the last step, we simultaneously divide numerator and denominantor by $n$. Now it is clear that $\lim_{n\to 0} s_n=\dfrac{1}{4}$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>