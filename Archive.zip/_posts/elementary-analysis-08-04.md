---
title: If the limit of sequence is zero then so is the limit of sequence multiplied by a bounded one
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit,Proof,Bounded]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 8 Exercise 8.4
{% endnote %}

<!--more-->

Solution: Let $\epsilon>0$. Since $\lim s_n=0$, there exists $N>0$ such that 
$$
|s_n-0|=s_n < \frac{\epsilon}{M+1}
$$ for all $n>N$. Therefore $n>N$ implies that
$$
|s_nt_n|=|s_n|M<\frac{\epsilon}{M+1}M<\epsilon
$$ for all $n>N$ as desired. Thus $\lim (s_nt_n)=0$.

{% note warning %}
Here we use $\dfrac{\epsilon}{M+1}$ instead of $\dfrac{\epsilon}{M}$ because $M$ may be *zero*. With this modification, we do not need to consider the case where $M=0$ separately.
{% endnote %}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>