---
title: Compute the determinant of a 5 by 5 matrix
categories: [Machine Learning,Linear Algebra]
tags: [Determinant,Laplace Expansion,Gaussian Elimination]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.2**
{% endnote %}

<!--more-->

Solution: 

Perform Gaussian elimination to "fix" the first columns. I have used only the rule allowing us to add a multiple of a row to a different row, which doesn't change the determinant. We have $$\\begin{bmatrix} 2&0&1&2&0\\\\ 0&-1&-1&-1&1\\\\ 0&0&1&0&3\\\\ 0&0&3&1&2\\\\ 0&0&-1&-1&1 \\end{bmatrix}.$$

From here, we can either continue with Gaussian elimination to get our matrix into upper triangular form, then multiply the entries on the diagonal together (remembering to take into account any elementary operations which would change the determinant!), or we can simply compute the determinant of the lower-right $3\\times 3$ matrix, since this is quick to do by hand (it is $-3$). Thus the determinant of the overall matrix is $2\\cdot -1\\cdot -3 = 6$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>