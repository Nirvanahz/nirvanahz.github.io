---
title:  Using the principle of mathematical induction to show identities III
categories: [Solution,Elementary Analysis]
tags: [Induction,Identity]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 1 Exercise 1.3
{% endnote %}

<!--more-->

Solution: The $n$-th proposition is
$$
P_n: 1^3+2^3+\cdots+n^3=(1+2+\cdots+n)^2.
$$ Then $P_1$ asserts $1^3=1^2$ which is clearly true and we have the induction basis.

Now we assume $P_n$ is true, that is the equation
\\begin{equation}\label{eq:1-1-3-1}
1^3+2^3+\cdots+n^3=(1+2+\cdots+n)^2.
\\end{equation} We would like to show $P_{n+1}$ is true based on $P_n$. To do that, we shall use the following identity from Example 1
\\begin{equation}\label{eq:1-1-3-2}
1+2+\cdots+n=\frac{1}{2}n(n+1).
\\end{equation} We add both sides of \eqref{eq:1-1-3-1} by $(n+1)^3$ and obtain
\\begin{align\*}
&\ 1^3+2^3+\cdots +n^3+(n+1)^3\\\\
=&\ (1+2+\cdots+n)^2+(n+1)^3\\\\
\text{use \eqref{eq:1-1-3-2}}=&\ \frac{1}{4}n^2(n+1)^2+(n+1)^3\\\\
=&\ \frac{1}{4}n^2(n+1)^2+\frac{1}{4}(n+1)^2(4n+4)\\\\
=&\ \frac{1}{4}(n+1)^2(n^2+4n+4)\\\\
=&\ \frac{1}{4}(n+1)^2(n+2)^2\\\\
=&\ \left(\frac{1}{2}(n+1)\big((n+1)+1\big)\right)^2\\\\
\text{use \eqref{eq:1-1-3-2}}=&\ \big(1+2+\cdots+n+(n+1)\big)^2.
\\end{align\*} Therefore $P_{n+1}$ is true if $P_n$ is true. By the principle of mathematical induction, we make the conclusion that $P_n$ is true for all positive integers $n$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>