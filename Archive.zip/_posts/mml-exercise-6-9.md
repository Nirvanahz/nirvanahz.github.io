---
title:  Express the Binomial and Beta distributions as an exponential family distribution
categories: [Machine Learning,Statistics]
tags: [Bernoulli Distribution,Beta Distribution,Distribution,Probability]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.9**
{% endnote %}

<!--more-->

Solution: 

The binomial distribution can be transformed as

\\begin{align\*} p(x|N,\\mu) =&\\ {N\\choose x} \\mu^x (1-\\mu)^{N-x} = {N \\choose x} e^{x\\log\\mu + (N-x)\\log(1-\\mu)}\\\\ =&\\ {N \\choose x}e^{x\\log\\left(\\frac{\\mu}{1-\\mu}\\right) +N\\log(1-\\mu)} = h(x)e^{x\\theta - A(\\theta)}
\\end{align\*}

where

$$ h(x) = {N \\choose x},\\\\ \\theta = \\log\\left(\\frac{\\mu}{1-\\mu}\\right),$$ 

$$ A(\\theta) = -N\\log(1-\\mu) = N\\log(1+e^\\theta), $$

i.e., the binomial distribution can be represented as an exponential family distribution (only $\\mu$ is treated here as a parameter, since the number of trials $N$ is fixed.)

Similarly, the beta distribution can be transoformed as

\\begin{align\*} p(x |\\alpha, \\beta) = &\\ \\frac{1}{\\mathcal{B}(\\alpha,\\beta)} x^{\\alpha-1}(1-x)^{\\beta-1} \\\\=&\\ e^{(\\alpha -1)\\log x + (\\beta -1)\\log(1-x) - \\log(\\mathcal{B}(\\alpha,\\beta))}\\\\ =&\\ h(x)e^{\\theta\_1\\phi\_1(x) + \\theta\_2\\phi\_2(x) -A(\\theta\_1, \\theta\_2)}
\\end{align\*}

where

$$ h(x) = 1,\\\\ \\theta\_1 = \\alpha-1, \\theta\_2 = \\beta-1,$$ $$\\phi\_1(x) = \\log x, \\phi\_2(x) = \\log(1-x),$$ $$A(\\theta\_1, \\theta\_2) = \\log(\\mathcal{B}(\\alpha,\\beta)) = \\log(\\mathcal{B}(1+\\theta\_1,1 + \\theta\_2)) $$

i.e. this is a distribution form the exponential family.

The product of the two distributions is then given by

\\begin{align\*} p(x|N,\\mu) p(x|\\alpha, \\beta)=&\\ {N \\choose x}e^{x\\log\\left(\\frac{\\mu}{1-\\mu}\\right) + (\\alpha-1)\\log x + (\\beta -1)\\log(1-x) + N\\log(1-\\mu) - \\log(\\mathcal{B}(\\alpha,\\beta))}\\\\ =&\\ h(x) e^{\\theta\_1 \\phi\_1(x) + \\theta\_2 \\phi\_2(x) + \\theta\_3\\phi\_3(x) - A(\\theta\_1, \\theta\_2, \\theta\_3)},
\\end{align\*}

where

$$ h(x) = {N \\choose x},\\qquad \\theta\_1 = \\alpha-1, \\theta\_2 = \\beta-1,\\theta\_3 = \\log\\left(\\frac{\\mu}{1-\\mu}\\right)$$

$$ \\phi\_1(x) = \\log x, \\phi\_2(x) = \\log(1-x), $$

$$\\phi\_3(x) = x\\\\ A(\\theta\_1, \\theta\_2, \\theta\_3) = \\log(\\mathcal{B}(\\alpha,\\beta)) -N\\log(1-\\mu) = \\log(\\mathcal{B}(1+\\theta\_1,1 + \\theta\_2)) + N\\log(1+e^\\theta\_3). $$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>