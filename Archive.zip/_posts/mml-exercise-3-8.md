---
title: Computation using Gram-Schmidt method
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Gram-Schmidt,Inner Product]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.8**
{% endnote %}

<!--more-->

Solution: 

We will assume we use the standard dot product as our inner product. Firstly, let's get an orthogonal basis, then we can simply divide by the magnitude of each vector to get our orthonormal basis.

Since $b\_1$ is our first vector, there is nothing to do for now. To get the second vector in our basis, we need a vector, $b\_2'$, perpendicular to $b\_1$, such that $span(b\_1,b\_2) = span (b\_1, b\_2')$. This is given by $b\_2' = b\_2 - \\pi\_{span(b\_1)}(b\_2)$.

Now, $$\\pi\_{span(b\_1)}(b\_2) = \\frac{b\_1b\_1^\\mathsf{T}}{\\lVert b\_1 \\rVert^2} b\_2 = \\frac{1}{3} \\begin{bmatrix} 1&1&1\\\\ 1&1&1\\\\ 1&1&1 \\end{bmatrix} \\begin{bmatrix}-1\\\\2\\\\0 \\end{bmatrix} = \\frac{1}{3}\\begin{bmatrix} 1\\\\1\\\\1 \\end{bmatrix}.$$

Therefore, $$b\_2' = \\begin{bmatrix}-\\frac43 \\\\ \\frac53 \\\\ -\\frac13 \\end{bmatrix}.$$

Hence, our orthonormal basis, $C$, is given by $$C=\\left\\{\\frac{1}{\\sqrt3}\\begin{bmatrix} 1\\\\1\\\\1 \\end{bmatrix} , \\frac{1}{\\sqrt42}\\begin{bmatrix}-4\\\\5\\\\-1 \\end{bmatrix}\\right\\}.$$


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>