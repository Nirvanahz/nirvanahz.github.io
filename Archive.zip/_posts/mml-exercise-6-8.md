---
title: Express the Bernoulli distribution in the natural parameter form of the exponential family
categories: [Machine Learning,Statistics]
tags: [Bernoulli Distribution,Distribution,Probability]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.8**
{% endnote %}

<!--more-->

Solution: 

Bernoulli distribution is given by

$$ p(x|\\mu) = \\mu^x (1-\\mu)^{1-x}. $$

We can use relation

$$ a^x = e^{x\\log a} $$

to write the Bernoulli distribution as

$$ p(x|\\mu) = e^{x\\log\\mu + (1-x)\\log(1-\\mu)}= e^{x\\log\\left(\\frac{\\mu}{1-\\mu}\\right) + \\log(1-\\mu)} = h(x)e^{\\theta x - A(\\theta)}, $$

where the last equation is the definition of a single-parameter distribution from the exponential family, in which

$$ h(x) = 1,\\\\ \\theta = \\log\\left(\\frac{\\mu}{1-\\mu}\\right)$$ $$\\leftrightarrow \\mu = \\frac{e^\\theta}{1+e^\\theta},\\\\ A(\\theta) = -\\log(1-\\mu) = \\log(1+e^\\theta). $$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>