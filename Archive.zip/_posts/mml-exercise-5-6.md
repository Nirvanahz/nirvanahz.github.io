---
title: Differentiate vector-valued functions with respect to vector-valued variables
categories: [Machine Learning,Calculus]
tags: [Derivative,Multivariable Calculus]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 5 Exercise 5.6**
{% endnote %}

<!--more-->

Solution: 

We have $$\\frac{df}{dt} = \\cos(\\log(t^{\\mathsf{T}}t))\\cdot\\frac1{t^{\\mathsf{T}}t}\\cdot \\begin{bmatrix} 2t\_1&2t\_2&\\cdots&2t\_D \\end{bmatrix} = \\cos(\\log(t^{\\mathsf{T}}t))\\cdot\\frac{2t^{\\mathsf{T}}}{t^{\\mathsf{T}}t}.$$

For $g$, if we explicitly compute $AXB$ and find its trace, we have that $$g(X) = \\sum\_{k=1}^D \\sum\_{j=1}^F \\sum\_{i=1}^E a\_{ki}x\_{ij}b\_{jk}.$$ Thus we have, $$\\frac{\\partial g}{\\partial x\_{ij}} = \\sum\_{k=1}^D b\_{jk}a\_{ki},$$ and this is the $(i,j)$-th entry of the required derivative. Hence $$\\frac{dg}{dX} = B^{\\mathsf{T}}A^{\\mathsf{T}}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Real Analysis";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "402d8b59cc9faa66d8d6b3b1eef9c01e";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "bottom";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>