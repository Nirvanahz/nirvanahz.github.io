---
title:  Find all rational solutions of an monic polynomial with integer coefficients
categories: [Solution,Elementary Analysis]
tags: [Rational Number,Polynomial]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 2 Exercises 2.8
{% endnote %}

<!--more-->

{% note default %}
Our main tool is Corollary 2.3.
{% endnote %}

Solution: By Corollary 2.3, if $x^8-4x^5+13x^3-7x+1=0$ has a rational solution, then this rational solution must be a divisor of $1$ which means it can only be $\pm 1$.

If $x=1$, we have 

$$
x^8-4x^5+13x^3-7x+1=1-4+13-7+1=4\ne 0.
$$ Hence $1$ is not a solution.

If $x=1$, we have 
$$
x^8-4x^5+13x^3-7x+1=1+4-13+7+1=0.
$$ Hence $-1$ is a solution.

The only rational solution of $x^8-4x^5+13x^3-7x+1=0$ is $-1$. 

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>