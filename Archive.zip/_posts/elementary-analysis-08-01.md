---
title: Formal proof of limits I
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit,Proof]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 8 Exercise 8.1
{% endnote %}

<!--more-->


Solution: 

### Part a

Let $\epsilon>0$ and let $N=\dfrac{1}{\epsilon}$. Then $n>N$ implies 
$$
\frac{1}{n}<\frac{1}{N}=\epsilon,
$$ and hence
$$
\left|\dfrac{(-1)^n}{n}-0\right|=\frac{1}{n}<\epsilon
$$ as desired. Therefore $\lim\dfrac{(-1)^n}{n}=0$.

---

### Part b

Let $\epsilon>0$ and let $N=\dfrac{1}{\epsilon^3}$. Then $n>N$ implies
$$
\frac{1}{n^{1/3}}<\dfrac{1}{N^{1/3}}=\frac{1}{1/\epsilon}=\epsilon.
$$ and hence
$$
\left|\frac{1}{n^{1/3}}-0\right|=\frac{1}{n^{1/3}}<\epsilon.
$$ as desired. Therefore $\lim\dfrac{1}{n^{1/3}}=0$.

---

### Part c

Let $\epsilon>0$ and let $N=\dfrac{7}{9\epsilon}$. Then $n>N$ implies
$$
\frac{7}{9n+6}<\frac{7}{9N}=\epsilon.
$$ and hence
\\begin{align\*}
\left|\frac{2n-1}{3n+2}-\frac{2}{3}\right|=\frac{7}{9n+6}<\epsilon.
\\end{align\*} as desired. Therefore $\lim\dfrac{2n-1}{3n+2}=\dfrac{2}{3}$.

---

### Part d

Let $\epsilon>0$ and let $N=6+\dfrac{1}{\epsilon}$. Then $n>N$ implies
$$
0<\frac{n+6}{n^2-6}<\frac{n+6}{n^2-36}=\frac{1}{n-6}<\frac{1}{N-6}=\epsilon,
$$ and hence
$$
\left|\frac{n+6}{n^2-6}-0\right|=\frac{n+6}{n^2-6}<\epsilon
$$ as desired. Therefore $\lim\dfrac{n+6}{n^2-6}=0$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>