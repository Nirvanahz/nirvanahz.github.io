---
title:  Manipulation of Gaussian Random Variables
categories: [Machine Learning,Statistics]
tags: [Gaussian Distribution,Distribution,Random Variable,Probability]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.12**
{% endnote %}

<!--more-->

Solution: 

**Part a**

If $\\mathbf{x}$ is fixed, then $\\mathbf{y}$ has the same distribution as $\\mathbf{w}$, but with the mean shifter by $\\mathbf{A}\\mathbf{x} + \\mathbf{b}$, that is

$$ p(\\mathbf{y}|\\mathbf{x}) = \\mathcal{N}(\\mathbf{y}|\\mathbf{A}\\mathbf{x} + \\mathbf{b}, \\mathbf{Q}). $$

---

**Part b**

Let us consider random variable $\\mathbf{u} = \\mathbf{A}\\mathbf{x}$, it is distributed according to

$$ p(\\mathbf{u}) = \\mathcal{N}(\\mathbf{u}|\\mathbf{A}\\mathbf{\\mu}\_x, \\mathbf{A}\\mathbf{\\Sigma}\_x\\mathbf{A}^T). $$

Then $\\mathbf{y}$ is a sum of two Gaussian random variables $\\mathbf{u}$ and $\\mathbf{w}$ with its mean additionally shifted by $\\mathbf{b}$, that is

$$ p(\\mathbf{y}) = \\mathcal{N}(\\mathbf{y}|\\mathbf{A}\\mathbf{\\mu}\_x + \\mathbf{b}, \\mathbf{A}\\mathbf{\\Sigma}\_x\\mathbf{A}^T + \\mathbf{Q}), $$

that is

$$ \\mathbf{\\mu}\_y = \\mathbf{A}\\mathbf{\\mu}\_x + \\mathbf{b},\\\\ \\mathbf{\\Sigma}\_y = \\mathbf{A}\\mathbf{\\Sigma}\_x\\mathbf{A}^T + \\mathbf{Q}. $$

---

**Part c**

Like in b), assuming that $\\mathbf{y}$ is fixed we obtain the conditional distribution

$$ p(\\mathbf{z}|\\mathbf{y}) = \\mathcal{N}(\\mathbf{z}|\\mathbf{C}\\mathbf{y}, \\mathbf{R}) $$

Since $\\mathbf{C}\\mathbf{y}$ is a Gausssian random variable with distribution $\\mathcal{N}(\\mathbf{C}\\mathbf{\\mu}\_y, \\mathbf{C}\\mathbf{\\Sigma}\_y\\mathbf{C}^T)$ we obtain the distribution of $\\mathbf{z}$ as that of a sum of two Gaussian random variables:

$$ p(\\mathbf{z})= \\mathcal{N}(\\mathbf{z} |\\mathbf{C}\\mathbf{\\mu}\_y, \\mathbf{C}\\mathbf{\\Sigma}\_y\\mathbf{C}^T + \\mathbf{R})= \\mathcal{N}(\\mathbf{z} |\\mathbf{C}(\\mathbf{A}\\mathbf{\\mu}\_x + \\mathbf{b}), \\mathbf{C}(\\mathbf{A}\\mathbf{\\Sigma}\_x\\mathbf{A}^T + \\mathbf{Q})\\mathbf{C}^T + \\mathbf{R}) $$

---

**Part d**

The posterior distribution $p(\\mathbf{x}|\\mathbf{y})$ can be obtained by applying the Bayes' theorem:

$$ p(\\mathbf{x}|\\mathbf{y})= \\frac{p(\\mathbf{y}|\\mathbf{x})p(\\mathbf{x})}{p(\\mathbf{y})}= \\frac{\\mathcal{N}(\\mathbf{y}|\\mathbf{A}\\mathbf{x} + \\mathbf{b}, \\mathbf{Q})\\mathcal{N}(\\mathbf{x}|\\mathbf{\\mu}\_x,\\mathbf{\\Sigma}\_x)} {\\mathcal{N}(\\mathbf{y}|\\mathbf{A}\\mathbf{\\mu}\_x + \\mathbf{b}, \\mathbf{A}\\mathbf{\\Sigma}\_x\\mathbf{A}^T + \\mathbf{Q})}. $$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>