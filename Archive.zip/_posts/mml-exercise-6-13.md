---
title:  Probability Integral Transformation and uniform distribution
categories: [Machine Learning,Statistics]
tags: [Uniform Distribution,Distribution,Random Variable,Probability]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.13**
{% endnote %}

<!--more-->

Solution: 

Cdf is related to pdf as

$$ F\_x(x) = \\int\_{-\\infty}^xdx' f\_x(x'),\\quad \\frac{d}{dx} F\_x(x) = f\_x(x), $$

and changes in the interval $\[0,1\]$.

The pdf of variable $y=F\_x(x)$ then can be defined as

$$ f\_y(y) = f\_x(x) \\left|\\frac{dx}{dy}\\right| = \\frac{f\_x(x)}{\\left|\\frac{dy}{dx}\\right|} = \\frac{f\_x(x)}{\\left|\\frac{dF\_x(x)}{dx}\\right|} = \\frac{f\_x(x)}{f\_x(x)} = 1, $$

i.e. $y$ is uniformly distributed in interval $\[0,1\]$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>