---
title: Determine if a subset is a subspace
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space, Subspace]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.9**
{% endnote %}

<!--more-->

Solution:

**Part a**

We can relabel $\\mu^3$ as $\\nu$, so $\\nu$ can be any real number, and then we have $A = \\{ (\\lambda, \\lambda+\\nu, \\lambda-\\nu)^{\\mathsf{T}} : \\lambda, \\nu \\in \\mathbb{R} \\}$. This has a basis of $\\{(1,1,1)^{\\mathsf{T}}, (0,1,-1)^{\\mathsf{T}}\\}$ (obtained by taking $\\lambda=1$, $\\mu=0$ and $\\lambda=0$, $\\mu=1$ respectively), so it is a subspace of $\\mathbb{R}^3$.

**Part b**

We cannot do the same trick as before, since the square of a real number is always at least zero. Clearly $(1,-1,0)^{\\mathsf{T}}\\in B$, but $-1$ times this vector, i.e. $(-1,1,0)^{\\mathsf{T}}\\notin B$, and thus $B$ is not a subspace.

**Part c**

We know that $(0,0,0)^{\\mathsf{T}}$ is an element of every (three-dimensional!) subspace, so we can $C$ can only be a subspace if $\\gamma = 0$. In this case, we can find a basis for $C$ (say $\\{ (3,0,-1)^{\\mathsf{T}},(0,3,2)^{\\mathsf{T}} \\}$), and conclude that it is indeed a subspace.

**Part d**

Again, this is not a subspace. Observe that $(0,1,0)^{\\mathsf{T}}\\in D$, so if $D$ were a subspace, then any (real!) multiple should be in $D$ also. However, $\\frac12 (0,1,0)^{\\mathsf{T}} \\notin D$ because the second component is not an integer.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>