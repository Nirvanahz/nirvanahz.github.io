---
title: Derive the dual linear program using Lagrange duality
categories: [Machine Learning,Calculus]
tags: [Lagrange Duality,Linear Program,Optimization]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 7 Exercise 7.6**
{% endnote %}

<!--more-->

Solution: 

We use (7.43) on Page 239 directly. Note that in this case, see (7.39), we have $$\\boldsymbol  c=-\\left\[\\begin{array}{l}  
5 \\\\  
3  
\\end{array}\\right\],\\quad \\boldsymbol b=\\left\[\\begin{array}{c}  
33 \\\\  
8 \\\\  
5 \\\\  
\-1 \\\\  
8  
\\end{array}\\right\],$$ $$\\boldsymbol A=\\left\[\\begin{array}{cc}  
2 & 2 \\\\  
2 & -4 \\\\  
\-2 & 1 \\\\  
0 & -1 \\\\  
0 & 1  
\\end{array}\\right\].$$By (7.43), the dual linear program is $$  
\\max \_{\\boldsymbol{\\lambda} \\in \\mathbb{R}^{5}}\\quad -\\left\[\\begin{array}{c}  
33 \\\\  
8 \\\\  
5 \\\\  
\-1 \\\\  
8  
\\end{array}\\right\]^{\\top}\\left\[\\begin{array}{c}  
\\lambda\_{1} \\\\  
\\lambda\_{2} \\\\  
\\lambda\_{3} \\\\  
\\lambda\_{4} \\\\  
\\lambda\_{5}  
\\end{array}\\right\]  
$$ $$  
\\text { subject to } \\quad -\\left\[\\begin{array}{l}  
5 \\\\  
3  
\\end{array}\\right\]+\\left\[\\begin{array}{cc}  
2 & 2 \\\\  
2 & -4 \\\\  
\-2 & 1 \\\\  
0 & -1 \\\\  
0 & 1  
\\end{array}\\right\]^\\top \\left\[\\begin{array}{c}  
\\lambda\_{1} \\\\  
\\lambda\_{2} \\\\  
\\lambda\_{3} \\\\  
\\lambda\_{4} \\\\  
\\lambda\_{5}  
\\end{array}\\right\]=0  
$$ $$\\left\[\\begin{array}{c}  
\\lambda\_{1} \\\\  
\\lambda\_{2} \\\\  
\\lambda\_{3} \\\\  
\\lambda\_{4} \\\\  
\\lambda\_{5}  
\\end{array}\\right\]\\geqslant 0.$$

***

{% note info %}
If you are interested in more detail, see below.
{% endnote %}

Let us define $\\mathbf{c} = (-5, -3)^T$, $\\mathbf{b} = (33, 8, 5, -1, 8)^T$ and

$$ \\mathbf{A}= \\begin{bmatrix} 2 & 2\\\\ 2 & -4\\\\-2 & 1\\\\ 0 & -1\\\\ 0 & 1 \\end{bmatrix} $$

The linear program is then written as

$$ \\min\_{\\mathbf{x} \\in \\mathbb{R}^2} \\mathbf{c}^T\\mathbf{x}$$ $$\\text{subject to } \\mathbf{A}\\mathbf{x} \\leq \\mathbf{b} $$

The Lagrangian of this problem is

$$ \\mathcal{L}(\\mathbf{x},\\mathbf{\\lambda}) = \\mathbf{c}^T\\mathbf{x} + \\mathbf{\\lambda}^T(\\mathbf{A}\\mathbf{x} - \\mathbf{b})= (\\mathbf{c}^T\\mathbf{x} + \\mathbf{\\lambda}^T\\mathbf{A})\\mathbf{x} - \\mathbf{\\lambda}^T\\mathbf{b}= (\\mathbf{c}\\mathbf{x} + \\mathbf{A}^T\\mathbf{\\lambda})^T\\mathbf{x} - \\mathbf{\\lambda}^T\\mathbf{b} $$

Taking gradient in respect to $\\mathbf{x}$ and setting it to zero we obtain the extremum condition

$$ \\mathbf{c}\\mathbf{x} + \\mathbf{A}^T\\mathbf{\\lambda} = 0, $$

that is

$$ \\mathcal{D}(\\mathbf{\\lambda}) = \\min\_{\\mathbf{x} \\in \\mathbb{R}^2} \\mathcal{L}(\\mathbf{x},\\mathbf{\\lambda}) = - \\mathbf{\\lambda}^T\\mathbf{b} $$

that is the dual problem is given by

$$ \\max\_{\\mathbf{\\lambda} \\in \\mathbb{R}^5} - \\mathbf{b}^T\\mathbf{\\lambda}$$ $$\\text{subject to } \\mathbf{c}\\mathbf{x} + \\mathbf{A}^T\\mathbf{\\lambda} = 0$$ $$\\text{ and } \\mathbf{\\lambda} \\geq 0 $$

In terms of the original values of the parameters it can be thus written as

$$ \\max\_{\\mathbf{\\lambda} \\in \\mathbb{R}^5} - \\begin{bmatrix} 33 \\\\ 8 \\\\ 5 \\\\ -1 \\\\ 8 \\end{bmatrix}^T \\begin{bmatrix} \\lambda\_1 \\\\ \\lambda\_2 \\\\ \\lambda\_3 \\\\ \\lambda\_4 \\\\ \\lambda\_5 \\end{bmatrix}$$ $$\\text{subject to } - \\begin{bmatrix} 5 \\\\ 3 \\end{bmatrix}+ \\begin{bmatrix} 2 & 2 & -2 & 0 & 0\\\\ 2 & -4 & 1 & -1 & 1 \\end{bmatrix} \\begin{bmatrix} \\lambda\_1 \\\\ \\lambda\_2 \\\\ \\lambda\_3 \\\\ \\lambda\_4 \\\\ \\lambda\_5 \\end{bmatrix} = 0$$ $$\\text{and } \\begin{bmatrix} \\lambda\_1 \\\\ \\lambda\_2 \\\\ \\lambda\_3 \\\\ \\lambda\_4 \\\\ \\lambda\_5 \\end{bmatrix} \\geq 0 $$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_default_search_phrase = "Calculus";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "f4d7cee51e59d583948f31cc8ab6b79a";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "top";
amzn_assoc_title = "Shop Related Products";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>