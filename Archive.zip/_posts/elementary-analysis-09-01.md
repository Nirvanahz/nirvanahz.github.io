---
title: Justify the following limits
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 9 Exercise 9.1
{% endnote %}

<!--more-->

Solution: 

### Part a

Let $s_n=\dfrac{n+1}{n}$. We have
$$
s_n=1+\frac{1}{n}.
$$ By Theorem 9.7(a) we have $\lim\dfrac{1}{n}=0$. Thus by Theorem 9.3, we have
$$
\lim \left(1+\frac{1}{n}\right)=\lim 1+\lim\frac{1}{n}=1+0=1.
$$

---

### Part b

Let $s_n=\dfrac{3n+7}{6n-5}$. We have
$$
s_n=\frac{3+\frac{7}{n}}{6-\frac{5}{n}}.
$$ By Theorem 9.7(a) we have $\lim\dfrac{1}{n}=0$. Thus by Theorems 9.2 and 9.3, we have
$$
\lim \left(3+\frac{7}{n}\right)=\lim 3+7\lim\frac{1}{n}=3+7\cdot 0=3,
$$ and
$$
\lim \left(6-\frac{5}{n}\right)=\lim 6-5\lim\frac{1}{n}=6-5\cdot 0=6.
$$ Then by Theorem 9.6 we obtain
$$
\lim \frac{3+\frac{7}{n}}{6-\frac{5}{n}}=\frac{3}{6}=\frac{1}{2}.
$$

---

### Part c

Let $s_n=\dfrac{17n^5+73n^4-18n^2+3}{23n^5+13n^3}$. We have
$$
s_n=\frac{17+\frac{73}{n}-\frac{18}{n^3}+\frac{3}{n^5}}{23+\frac{13}{n^2}}.
$$ By Theorem 9.7(a) we have 
$$
\lim \frac{1}{n}=\lim\frac{1}{n^2}=\lim\frac{1}{n^3}=\lim\frac{1}{n^5}=0.
$$ Hence by Theorems 9.2 and 9.3 we have
\begin{align\*}
&\ \lim\left(17+\frac{73}{n}-\frac{18}{n^3}+\frac{3}{n^5}\right)\\\\
=& \lim 17+73\lim\frac{1}{n}-18\frac{1}{n^3}+3\frac{1}{n^5}\\\\
=&\ 17+73\cdot 0-18\cdot 0+3\cdot 0= 17
\end{align\*} and
$$
\lim\left(23+\frac{13}{n^2}\right)=23+13\lim\frac{1}{n^2}=23+13\cdot 0=23.
$$ Therefore by Theorem 9.6, we obtain
$$
\lim \dfrac{17n^5+73n^4-18n^2+3}{23n^5+13n^3}=\dfrac{17}{23}.
$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>