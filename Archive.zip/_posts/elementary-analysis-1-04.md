---
title:  Using the principle of mathematical induction to show identities IV
categories: [Solution,Elementary Analysis]
tags: [Induction,Identity]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 1 Exercise 1.4
{% endnote %}

<!--more-->

Solution: 

#### Part a

If $n=1$, the sum is $1$.
If $n=2$, the sum is $1+3=4$.
If $n=3$, the sum is $1+3+5=9$.
If $n=4$, the sum is $1+3+5+7=16$.

Note that $1=1^2$, $4=2^2$, $9=3^2$, and $16=4^2$. It is natural to guess the answer should be $n^2$.

---

#### Part b

{% note default %}
We show by induction on $n$ that
$$
1+3+\cdots+(2n-1)=n^2
$$ is true for all positive integers $n$.
{% endnote %}

The $n$-th proposition is
$$
P_n: 1+3+\cdots+(2n-1)=n^2.
$$ Then $P_1$ asserts $1=1^2$ which is clearly true and we have the induction basis.

Now we assume $P_n$ is true, that is the equation
\\begin{equation}\label{eq:1-4-1}
1+3+\cdots+(2n-1)=n^2.
\\end{equation} We would like to show $P_{n+1}$ is true based on $P_n$. We add both sides of \eqref{eq:1-4-1} by $2(n+1)-1$ and obtain
\\begin{align\*}
&\ 1+3+\cdots+(2n-1)+\big(2(n+1)-1\big)\\\\
=&\ n^2+\big(2(n+1)-1\big)=n^2+(2n+2-1)\\\\
=&\ n^2+2n+1=(n+1)^2.
\\end{align\*} Therefore $P_{n+1}$ is true if $P_n$ is true. By the principle of mathematical induction, we make the conclusion that $P_n$ is true for all positive integers $n$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>