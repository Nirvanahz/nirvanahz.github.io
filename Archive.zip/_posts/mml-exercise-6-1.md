---
title: Compute marginal distributions and conditional distributions
categories: [Machine Learning,Statistics]
tags: [Distribution,Random Variables]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.1**
{% endnote %}

<!--more-->

Solution: 

**Part a**

The marginal distributions are obtained by summing the probabilies over all the values of the variable being marginalized. Thus, to obtain $p(x)$ we sum over columns (i.e., over the values corresponding to different $y$):

\\begin{align*} 
p(x\_1) &= P(X = x\_1) = P(X = x\_1, Y = y\_1) + P(X = x\_1, Y = y\_2) + P(X = x\_1, Y = y\_3)\\\\& = 0.01 + 0.05 + 0.1 = 0.16 
\\end{align*} \\begin{align*}
p(x\_2) &= P(X = x\_2) = P(X = x\_2, Y = y\_1) + P(X = x\_2, Y = y\_2) + P(X = x\_2, Y = y\_3)\\\\& = 0.02 + 0.1 + 0.05 = 0.17
\\end{align*} \\begin{align*}
p(x\_3) &= P(X = x\_3) = P(X = x\_3, Y = y\_1) + P(X = x\_3, Y = y\_2) + P(X = x\_3, Y = y\_3)\\\\& = 0.03 + 0.05 + 0.03 = 0.11
\\end{align*} \\begin{align*}
p(x\_4) &= P(X = x\_4) = P(X = x\_4, Y = y\_1) + P(X = x\_4, Y = y\_2) + P(X = x\_4, Y = y\_3)\\\\& = 0.1 + 0.07 + 0.05 = 0.22
\\end{align*} \\begin{align*}
p(x\_5) &= P(X = x\_5) = P(X = x\_5, Y = y\_1) + P(X = x\_5, Y = y\_2) + P(X = x\_5, Y = y\_3)\\\\& = 0.1 + 0.2 + 0.04 = 0.34
\\end{align*} As a correctness check, note that this distribution satisfies the normalization condition, i.e. that sum of the probabilities is $1$:

$ \\begin{equation} \\sum\_{i=1}^5 p(x\_i) = 1 \\end{equation} $

The marginal distribution $p(y)$ can be obtained in a similar way, by summing the matrix rows:

\\begin{align*} p(y\_1) &= P(Y = y\_1) = \\sum\_{i=1}^5 P(X = x\_i, Y = y\_1) = 0.01 + 0.02 + 0.03 + 0.1 + 0.1 = 0.26 \\\\ p(y\_2) &= P(Y = y\_2) = \\sum\_{i=1}^5 P(X = x\_i, Y = y\_2) = 0.05 + 0.1 + 0.05 + 0.07 + 0.2 = 0.47 \\\\ p(y\_3) &= P(Y = y\_3) = \\sum\_{i=1}^5 P(X = x\_i, Y = y\_3) = 0.1 + 0.05 + 0.03 + 0.05 + 0.04 = 0.27 \\end{align*} We can again check that the normalization condition is satisfied: \\begin{equation*} \\sum\_{i=1}^3p(y\_i) = 1 \\end{equation*}

---

**Part b**

To determine conditional distributions we use the definition of the conditional probability:

$$ P(X = x , Y = y\_1) = P(X = x | Y = y\_1)P(Y = y\_1) = p(x | Y = y\_1) p(y\_1). $$

Thus,

\\begin{align*}
p(x\_1 | Y = y\_1) = \\frac{P(X = x\_1, Y = y\_1)}{p(y\_1)} = \\frac{0.01}{0.26} \\approx 0.038\\\\ p(x\_2 | Y = y\_1) = \\frac{P(X = x\_2, Y = y\_1)}{p(y\_1)} = \\frac{0.02}{0.26} \\approx 0.077\\\\ p(x\_3 | Y = y\_1) = \\frac{P(X = x\_3, Y = y\_1)}{p(y\_1)} = \\frac{0.03}{0.26} \\approx 0.115\\\\ p(x\_4 | Y = y\_1) = \\frac{P(X = x\_4, Y = y\_1)}{p(y\_1)} = \\frac{0.1}{0.26} \\approx 0.385\\\\ p(x\_5 | Y = y\_1) = \\frac{P(X = x\_5, Y = y\_1)}{p(y\_1)} = \\frac{0.1}{0.26} \\approx 0.385 
\\end{align*}

Likewise the conditional distribution $p(y | X = x\_3)$ is given by

\\begin{align*}
p(y\_1 | X = y\_3) = \\frac{P(X = x\_3, Y = y\_1)}{p(x\_3)} = \\frac{0.03}{0.11} \\approx 0.273\\\\ p(y\_2 | X = y\_3) = \\frac{P(X = x\_3, Y = y\_2)}{p(x\_3)} = \\frac{0.05}{0.11} \\approx 0.454\\\\ p(y\_3 | X = y\_3) = \\frac{P(X = x\_3, Y = y\_3)}{p(x\_3)} = \\frac{0.03}{0.11} \\approx 0.273
\\end{align*}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>