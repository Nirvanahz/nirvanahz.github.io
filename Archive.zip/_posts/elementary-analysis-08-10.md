---
title: If the limit is greater than a number, so are all but finitely many of numbers in this sequence
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 8 Exercise 8.10
{% endnote %}

<!--more-->

This part actually has been shown in [Exercise 8.9](/elementary-analysis-08-09.html).

Solution: Suppose $\lim s_n=s$. Then we have  $s - a>0$.

Let $\epsilon =\dfrac{s-a}{2}$. Then there exists $N>0$ such that if $n>N$ then
$$
|s_n-s|<\epsilon\Longrightarrow s_n - s>-\epsilon.
$$ If $n>N$, then we have
$$
s_n-s>-\epsilon.
$$ Therefore, we have
$$
s_n > s-\epsilon=s-\frac{s-a}{2}=\frac{a+s}{2}.
$$ for all $n>N$. Because $s > a$, we have
$$
\frac{a+s}{2} > a
$$ which implies that 
$$
s_n > \frac{a+s}{2} > a
$$ for all $n>N$. We are done.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>