---
title: Determine matrices if they are diagonalisable II
categories: [Machine Learning,Linear Algebra]
tags: [Diagonalisability,Matrix,Eigenvector,Eigenvalue]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.7**
{% endnote %}

<!--more-->

Solution: 

**Part a**

If we form the characteristic polynomial, we have $\\lambda^2-4\\lambda +8$, which has no roots in $\\mathbb{R}$. However, if we extend to $\\mathbb{C}$, then we will be able to diagonalise the matrix.

**Part b**

This is a symmetric matrix, and is therefore diagonalisable. Its eigenvalues are $3$, and $0$ with multiplicity two, so its diagonal form is $$\\begin{bmatrix} 3&0&0\\\\ 0&0&0\\\\ 0&0&0 \\end{bmatrix},$$ and a basis of eigenvectors is $$\\{(1,1,1),(1,-1,0),(1,0,-1)\\}.$$

**Part c**

Here, we have three distinct eigenvalues, and $\\lambda = 4$ has multiplicity two. However, $\mathrm{rank}(A-4I) = 3$, so there is only one linearly independent eigenvector, and this $A$ cannot have a basis of eigenvectors, so it is not diagonalisable.

**Part d**

Again here we have two eigenvectors -- $\\lambda=1$ with multiplicity one and $\\lambda=2$ with multiplicity two. However, this time, observe that $\mathrm{rank}(A-2I)=1$, so there are indeed two linearly independent eigenvectors for this eigenvalue. Thus $A$ is diagonalisable, with diagonal form $$\\begin{bmatrix} 1&0&0\\\\ 0&2&0\\\\ 0&0&2 \\end{bmatrix},$$ with eigenvectors $$\\{(3,-1,3),(2,1,0),(2,0,1)\\}.$$

We have $$E\_1 = \mathrm{span}\\{(1,0,0,0)\\},$$ and $$E\_0 = \mathrm{span}\\{(1,-1,0,0),(0,0,1,0),(0,0,0,1)\\}.$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>