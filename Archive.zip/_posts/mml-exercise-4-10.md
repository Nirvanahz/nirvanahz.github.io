---
title: Find the best rank-1 approximation of a matrix
categories: [Machine Learning,Linear Algebra]
tags: [SVD,Matrix,Eigenvector,Eigenvalue,Approximation]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.10**
{% endnote %}

<!--more-->

Solution: 

Using our Singular value decomposition from [Question 4.8](/mml-exercise-4-8.html), we construct $$A\_1 = \\sigma\_1 u\_1 v\_1^{\\mathsf{T}} = 5 \\begin{bmatrix} \\frac{1}{\\sqrt2}\\\\ \\frac{1}{\\sqrt2} \\end{bmatrix} \\begin{bmatrix} \\frac{1}{\\sqrt2}&\\frac{1}{\\sqrt2}&0 \\end{bmatrix} = \\frac52 \\begin{bmatrix} 1&1&0\\\\ 1&1&0 \\end{bmatrix},$$ and similarly $$A\_2 = \\frac12 \\begin{bmatrix} 1&-1&4\\\\-1&1&-4 \\end{bmatrix}.$$ Then $A\_1$ and $A\_2$ both have rank one, with $A=A\_1+A\_2$, as required.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>