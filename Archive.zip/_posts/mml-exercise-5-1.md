---
title: Compute derivative using product rule and chain rule
categories: [Machine Learning,Calculus]
tags: [Derivative,Product Rule,Chain Rule]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 5 Exercise 5.1**
{% endnote %}

<!--more-->

Solution: By Chain Rule (5.32), we have 
$$ \\big(\\sin(x^3)\\big)'=\\cos(x^3)(x^3)'=3x^2\\cos(x^3). $$
We also have 
$$ \\big(\\log(x^4)\\big)'=\\big(4\\log(x)\\big)'=\\frac{4}{x}=4x^{-1}. $$
Applying Product Rule (5.29), we obtain 
\\begin{align\*} f'(x)=&\\ \\log(x^4) \\sin(x^3)\\\\=&\\ \\big(\\log(x^4)\\big)'\\sin(x^3)+\\log(x^4)\\big(\\sin(x^3)\\big)'\\\\=&\\ 4x^{-1}\\sin(x^3)+\\log(x^4)3x^2\\cos(x^3)\\\\=&\\ 4x^{-1}\\sin(x^3)+3x^2\\log(x^4)\\cos(x^3). \\end{align\*}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Real Analysis";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "402d8b59cc9faa66d8d6b3b1eef9c01e";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "bottom";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>