---
title: Properties of operations on convex functions
categories: [Machine Learning,Calculus]
tags: [Convex Function,Intersection,Union,Difference]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 7 Exercise 7.4**
{% endnote %}

<!--more-->

Solution: 

**Part a**

Solution: True. Let $f\_1(\\mathbf x)$ and $f\_2(\\mathbf x)$ be two convex functions. Suppose their domains are $\\mathcal C\_1$ and $\\mathcal C\_2$, respectively. Then $\\mathcal C\_1$ and $\\mathcal C\_2$ are convex sets, by Definition 7.3. Hence by Exercise 7.3 (a), the intersection $\\mathcal C\_1\\cap \\mathcal C\_2$ is also convex. Note that $\\mathcal C\_1\\cap \\mathcal C\_2$ is also the domain of $f\_1+f\_2$. Hence the domain of $f\_1+f\_2$ is convex. Now we only need to check the condition (7.30) in the textbook.

For any $\\mathbf x,\\mathbf y$ in $\\mathcal C\_1\\cap \\mathcal C\_2$ and $0\\leq \\theta \\leq 1$, we have\\begin{align\*}&\\ (f\_1+f\_2)(\\theta \\mathbf x+(1-\\theta)\\mathbf y) \\\\ = &\\ f\_1((\\theta \\mathbf x+(1-\\theta)\\mathbf y))+f\_2((\\theta \\mathbf x+(1-\\theta)\\mathbf y))\\\\ \\leq &\\ \\theta f\_1(\\mathbf x)+(1-\\theta)f\_1(\\mathbf y) +\\theta f\_2(\\mathbf x)+(1-\\theta)f\_2(\\mathbf y)\\\\ = &\\ \\theta f\_1(\\mathbf x) +\\theta f\_2(\\mathbf x)+(1-\\theta)f\_1(\\mathbf y) +(1-\\theta)f\_2(\\mathbf y)\\\\ = &\\ \\theta (f\_1+f\_2)(\\mathbf x)+(1-\\theta)(f\_1+f\_2)(\\mathbf y).\\end{align\*}In the inequality, we used equation (7.30) for $f\_1$ and $f\_2$ as they are convex. Therefore, $f\_1+f\_2$ is also convex.

* * *

**Part b**

I will use the following well-known fact.

{% note info %}
If $f''(x)\\geq 0$ holds for all $x$ in the domain (assumed to be convex) of $f$, then $f(x)$ is convex.
{% endnote %}

Solution: False. For example, let $f\_1(x)=x^2$ and $f\_2(x)=2x^2$. Then $f\_1$ and $f\_2(x)$ are convex, but $$(f\_1-f\_2)(x)=f\_1(x)-f\_2(x)=-x^2$$ is not convex. Please fill the details.

* * *

**Part c**

Solution: False. Let $f\_1(x)=x^2$ and $f\_2(x)=x$. Then $f\_1$ and $f\_2(x)$ are convex, but $$(f\_1f\_2)(x)=f\_1(x)f\_2(x)=-x^3$$ is not convex. Please fill the details, e.g. use $\\theta=1/2$, $x=-1$ and $y=0$ to get a counterexample.

* * *

**Part d**

Solution: True. Let $f\_1(\\mathbf x)$ and $f\_2(\\mathbf x)$ be two convex functions. Let $f(x):=\\max\\{f\_1(x),f\_2(x)\\}$ be the maximum of them. Suppose their domains are $\\mathcal C\_1$ and $\\mathcal C\_2$, respectively. Then $\\mathcal C\_1$ and $\\mathcal C\_2$ are convex sets, by Definition 7.3. Hence by Exercise 7.3 (a), the intersection $\\mathcal C\_1\\cap \\mathcal C\_2$ is also convex. Note that $\\mathcal C\_1\\cap \\mathcal C\_2$ is also the domain of $f(x)$. Hence the domain of $f(x)$ is convex. Now we only need to check the condition (7.30) in the textbook.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_default_search_phrase = "Calculus";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "f4d7cee51e59d583948f31cc8ab6b79a";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "top";
amzn_assoc_title = "Shop Related Products";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>