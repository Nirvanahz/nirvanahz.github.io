---
title: In a unit ring $1-ab$ is invertible if and only if $1-ba$ is invertible
date: 2021/02/06 12:00:00
categories: [Problems,Abstract Algebra]
tags: [Ring,Unit,Invertibility]
mathjax: true

---

{% note info %}
Problem 2
{% endnote %}

Let $a$ and $b$ be two elements in a unit ring $R$. Prove that $1-ab$ is invertible if and only if $1-ba$ is invertible.

<!--more-->

---

**Solution**

By symmetry, it suffices to show that if $1-ab$ is invertible, then so is $1-ba$. (To obtain the "only if" part, you just need to interchange $a$ and $b$ and repeat the "if" part.)

Let $c$ be the inverse of $1-ab$, we have $(1-ab)c=1$ that is $c=1+abc$. Now we check that $1+bca$ is the inverse of $1-ba$ by direct computations,

\\begin{align*}
(1-ba)(1+bca)=&\\ 1+bca-ba-babca \\\\
=&\\ 1+b(c-1-abc)a \\\\
=&\\ 1+b\cdot 0\cdot a = 1.
\\end{align*}

Here we used that $c=1+abc$. 

Similarly, using $c=1+cab$ (comes from $c(1-ab)=1$), one shows that

$$(1+bca)(1-ba)=1.$$

Hence $1-ba$ is invertible.

---

You may wonder how we know that the inverse of $1-ba$ is given by such a specific element. The idea comes from the following.

{% note warning %}
This is not a proof, because you *cannot* do infinite sum in a ring! 
{% endnote %}

We have the well-known Taylor's expansion,

$$
(1-x)^{-1}=1+x+x^2+x^3+\cdots.
$$

Hence we have

$$
(1-ab)^{-1}=1+ab+abab+ababab+\cdots,
$$

and hence

\\begin{align*}
(1-ba)^{-1}=&\\ 1+ba+baba+bababa+babababa+\cdots \\\\
=&\\ 1+b(1+ab+abab+ababab+\cdots)a \\\\
=&\\ 1+b(1-ab)^{-1}a.
\\end{align*}


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>