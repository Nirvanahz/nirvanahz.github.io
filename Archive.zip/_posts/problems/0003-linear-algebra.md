---
title: Exist a linear combination of two relatively prime polynomials having no multiple roots
date: 2021/02/07 12:00:00
categories: [Problems,Linear Algebra]
tags: [Polynomial,Root]
mathjax: true

---

{% note info %}
Problem 3
{% endnote %}

Let $f(x)$ and $g(x)$ be two relatively prime polynomials in $x$. Prove that there must exists a (real or complex) number $s$ such that $f(x)+sg(x)$ has no multiple root.

<!--more-->

---

**Solution**

We argue it by contradiction. Suppose $f(x)+sg(x)$ has a multiple root (maybe complex) for every number $s$. Let $x_s$ be one of the multiple root of $f(x)+sg(x)$ (note that $x_s$ may change as $s$ varies), then we have

$$
f(x_s)+sg(x_s)=0,
$$

$$
f'(x_s)+sg'(x_s)=0.
$$

This implies that the vector $(1,s)^T$ is a solution to the system of homogeneous equations with the coefficient matrix 

$$
\\begin{bmatrix} f(x_s) & g(x_s)\\\\ f'(x_s) & g'(x_s)\\end{bmatrix}.
$$ 

Hence its determinant must be zero, that is 

$$
f(x_s)g'(x_s)-f'(x_s)g(x_s)=0.
$$

Let $h(x)$ be the polynomial $f(x)g'(x)-f'(x)g(x)$ (this is indeed the Wronskian of $f(x)$ and $g(x)$). Then $h(x)$ is not zero since otherwise we have $f(x)|f'(x)g(x)$ while $f(x)$ and $g(x)$ are relatively prime and $f(x)$ does divide $f'(x)$.

Denote by $K$ the set of solutions of $h(x)$. Since $h(x)$ is non-zero, $K$ is a finite set. By our observation above, we have $x_s\in K$ for every $s$. Because $K$ is finite, there exists an element $\alpha\in K$ which corresponds to $x_s$ for infinitely many $s$. That implies $f(\alpha)+sg(\alpha)=0$ for infinitely many $s$ which holds only when $f(\alpha)=g(\alpha)=0$, contradicting with the fact that $f(x)$ and $g(x)$ are relatively prime (i.e. no common root). This completes the proof.

{% note default %}
In general, Wronskian is the tool to check if functions are linearly independent. Wronksian is nonzero if and only if they are linearly independent. Clearly, in this case, $f(x)$ and $g(x)$ are linearly independent and hence the Wronskian $h(x)$ can not be zero. 
{% endnote %}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>