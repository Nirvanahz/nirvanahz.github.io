---
title:  Two subsets generate the whole finite group
date: 2021/02/05 12:00:00
categories: [Problems,Abstract Algebra]
tags: [Finite Group,Cardinality]
mathjax: true

---

{% note info %}
Problem 1
{% endnote %}

Let $G$ be a finite group. Let $A$ and $B$ be two non-empty subsets of $G$ such that $|A|+|B|>|G|$. Here $|S|$ denotes the cardinality of the set $S$, that is the number of elements in the set $S$. Define 

$$
AB=\\{ab\\ |\\ a\in A,\\ b\in B\\}.
$$

Prove that $G=AB$.

<!--more-->

---

**Solution**

If $G=AB$, then it means that for any $g\in G$, we can find $a\in A$ and $b\in B$ such that $g=ab$. Note that this is equivalent to $a^{-1}g=b$. Hence we only need to show that $A^{-1}g\cap B\ne \emptyset$. Below is the proof.

---

Let $g$ be an arbitrary element in $G$. Now we fix $g$. Define 

$$
A^{-1}g=\\{a^{-1}g\\ |\\ a\in A\\}.
$$

Then we have $|A^{-1}g|=|A|$ (they clearly have the same number of elements). Hence

$$
|A^{-1}g|+|B|=|A|+|B|>|G|.
$$

Therefore, we must have $A^{-1}g\cap B\ne \emptyset$. Let $b\in A^{-1}g\cap B$, then $b\in B$. Moreover, since $b\in A^{-1}g$, there exists $a\in A$ such that $b=a^{-1}g$. Thus $g=ab\in AB$. As $g$ is chosen arbitrarily at the beginning. We conclude that $G=AB$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>