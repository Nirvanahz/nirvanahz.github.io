---
title: Solve systems of homogenous linear equations
categories: [Machine Learning,Linear Algebra]
tags: [Matrix,Linear Equations,Gaussian Elimination]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.7**
{% endnote %}

<!--more-->

Solution:

The problem can be solved as follows:

+ Find all solutions of the system of equations $Ax=12x$.
+ Find solutions such that $x\_1+x\_2+x\_3=1$.

We have that $$A-12I = \\begin{bmatrix}-6&4&3\\\\ 6&-12&9\\\\ 0&8&-12 \\end{bmatrix}.$$ It is easy to find that all solutions are of the form $(3\\alpha,3\\alpha,2\\alpha)^{\\mathsf{T}} \\in \\ker(A-12I)$. 

Finally, to make $x\_1+x\_2+x\_3=1$, we only need to divide the vector $(3\\alpha,3\\alpha,2\\alpha)^{\\mathsf{T}}$ by $3\\alpha+3\\alpha+2\\alpha=8\\alpha$. Here we should take nonzero $\\alpha$. Hence we have only one solution to the problem, that is $$(3/8, 3/8, 1/4).$$

{% note success %}
The problem shows that 12 is an eigenvector of the matrix $A$ and the corresponding eigenvector is $(3/8, 3/8, 1/4)$.
{% endnote %}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>