---
title: Find stationary points and determine their types
categories: [Machine Learning,Calculus]
tags: [Function,Extreme Value,Calculus,Optimization]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 7 Exercise 7.1**
{% endnote %}

<!--more-->

Solution: First, we compute the derivative of $f(x)$, $$f'(x)=3x^2+12x-3=3(x^2+4x-1).$$Its stationary points (also known as _critical points_) are the zeros of derivative. Hence by quadratic formula, we see that the stationary points are $$x\_1=-2+\\sqrt{5},\\quad x\_2=-2-\\sqrt{5}.$$To determine the local extreme values, we have find the signs of the derivative on some intervals. Since we know that the graph of the derivative is an open-upward parabola with $x$-intercepts $-2\\pm \\sqrt 5$, it is clear that the function $f'(x)$ is positive on $(-\\infty,-2-\\sqrt 5)$ and $(-2+\\sqrt 5,\\infty)$ and negative on $(-2-\\sqrt 5,-2+\\sqrt 5)$. Below is the graph of the derivative.

![Solution to Mathematics for Machine Learning Exercise 7.1](https://cdn.jsdelivr.net/gh/MathPage/gitalk/img/mml7-1-1-1.gif)

Hence by the first derivative test, we see that the original function has local maximum at $x\_2=-2-\\sqrt{5}$ and local minimum at $x=-2+\\sqrt{5}$. There is no global maximum or global minimum since $f(-\\infty)=-\\infty$ and $f(\\infty)=\\infty$. Here is the graph of the original function.

![Solution to Mathematics for Machine Learning Exercise 7.1](https://cdn.jsdelivr.net/gh/MathPage/gitalk/img/mml7-1-2-1.gif)

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_default_search_phrase = "Calculus";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "f4d7cee51e59d583948f31cc8ab6b79a";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "top";
amzn_assoc_title = "Shop Related Products";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>