---
title: Find the singular value decomposition of a matrix
categories: [Machine Learning,Linear Algebra]
tags: [SVD,Matrix,Eigenvector,Eigenvalue]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.8**
{% endnote %}

<!--more-->

Solution: 

First, we compute $$A^{\\mathsf{T}}A = \\begin{bmatrix} 13&12&2\\\\ 12&13&-2\\\\ 2&-2&8 \\end{bmatrix}.$$ We can diagonalise this to find $$D = \\begin{bmatrix} 25&0&0\\\\ 0&9&0\\\\ 0&0&0 \\end{bmatrix}$$ and $$P = \\begin{bmatrix} \\frac{1}{\\sqrt2}&\\frac{1}{\\sqrt{18}}&-\\frac23\\\\ \\frac{1}{\\sqrt2}&-\\frac{1}{\\sqrt{18}}&\\frac23\\\\ 0&\\frac{4}{\\sqrt{18}}&\\frac13 \\end{bmatrix}.$$

We take the square roots of the entries of $D$ to find $\\Sigma = \\begin{bmatrix} 5&0&0\\\\ 0&3&0 \\end{bmatrix}$, with $V$ equalling our $P$ above.

From here, we compute $$u\_1 = \\frac1{\\sigma\_1}Av\_1 = \\frac15\\begin{bmatrix} 3&2&2\\\\ 2&3&-2 \\end{bmatrix} \\begin{bmatrix} \\frac{1}{\\sqrt2}\\\\ \\frac{1}{\\sqrt2}\\\\ 0 \\end{bmatrix} = \\begin{bmatrix} \\frac{1}{\\sqrt2}\\\\ \\frac{1}{\\sqrt2} \\end{bmatrix},$$ and $$u\_2 = \\frac{1}{\\sigma\_2} A v\_2 = \\frac13 \\begin{bmatrix} 3&2&2\\\\ 2&3&-2 \\end{bmatrix} \\begin{bmatrix} \\frac{1}{\\sqrt{18}}\\\\-\\frac{1}{\\sqrt{18}}\\\\ \\frac{4}{\\sqrt{18}} \\end{bmatrix} = \\begin{bmatrix} \\frac{1}{\\sqrt2}\\\\-\\frac{1}{\\sqrt2} \\end{bmatrix},$$ giving $U=\\frac{1}{\\sqrt2}\\begin{bmatrix} 1&1\\\\1&-1 \\end{bmatrix}$.

It can be checked that $A = U\\Sigma V^{\\mathsf{T}}$, indeed!

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>