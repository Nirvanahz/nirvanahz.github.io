---
title: Find the limit by solving equations
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 9 Exercise 9.4
{% endnote %}

<!--more-->

Solution: 

### Part a

$s_1=1$, $s_2=\sqrt{2}$, $s_3=\sqrt{\sqrt 2+1}$, $s_4=\sqrt{\sqrt{\sqrt 2+1}+1}$.

---

### Part b

Since $(s_n)$ converges. Set $\lim s_n=s$. By $s_{n+1}=\sqrt{s_n+1}$, we have
$$
s_{n+1}^2=s_n+1.
$$ Hence we have
\begin{equation}\label{09-04-01}
\lim s_{n+1}^2=\lim (s_n+1).
\end{equation} On one hand, by Theorem 9.4, we have
\begin{equation}\label{09-04-02}
\lim s_{n+1}^2=(\lim s_{n+1})^2=s^2.
\end{equation} On the other hand, by Theorem 9.3, we have
\begin{equation}\label{09-04-03}
\lim(s_n+1)=\lim s_n+\lim 1=s+1.
\end{equation} Combining \eqref{09-04-01}, \eqref{09-04-02}, \eqref{09-04-03}, we have
$$
s^2=s+1.
$$ Solving for $s$, we must have $s=\dfrac{1\pm \sqrt 5}{2}$.

Since $s_n>0$ for all $n$, it follows from [Exercise 8.9](/elementary-analysis-08-09.html) that $s>0$. Therefore, we conclude that $s=\dfrac{1+\sqrt 5}{2}$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>