---
title: Find a basis of the intersection of two vector spaces
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Basis]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.12**
{% endnote %}

<!--more-->

Solution:

We write the given vectors as $v\_1, \\dots v\_6$ from left to right. Firstly, observe that $\\dim(U\_1)=2$ and $\\dim(U\_2)=2$ (compute the rank of $\\left\[v\_1|v\_2|v\_3\\right\]$, then $\\left\[v\_4|v\_5|v\_6\\right\]$). Since we can write $$v\_3= \\frac13 (v\_1-2v\_2)\\quad\\text{and}\\quad v\_6=-v\_4-2v\_5,$$ we need not consider $v\_3$ and $v\_6$ any further.

Now, if we find the rank of $\\left\[v\_1|v\_2|v\_4|v\_5\\right\]$, we get 3, so $\\dim(U\_1+U\_2)=3$. Therefore, $$\\dim(U\_1\\cap U\_2) = 2+2-3=1.$$ Hence, to find a basis of $U\_1 \\cap U\_2$, we need only find any non-zero vector in the space.

Let $0\\neq v \\in U\_1\\cap U\_2$. Then we can write $v=\\alpha\_1v\_1 + \\alpha\_2v\_2$, and $v=\\alpha\_4v\_4 + \\alpha\_5v\_5$. Subtracting these equations, we have $$0=\\alpha\_1v\_1 + \\alpha\_2v\_2 -\\alpha\_4v\_4 - \\alpha\_5v\_5.$$ Remember we want a non-zero solution for $v$, and observe that the rank of $\\left\[v\_1|v\_2|v\_4\\right\]$ is 3 (i.e. these three vectors are linearly independent). Hence we can take $\\alpha\_5=9$, say (this means we don't have fractions later, but there's no way to know this a priori!), and solve for the other $\\alpha\_i$'s. Using Gaussian elimination, we obtain $\\alpha\_1=4$, $\\alpha\_2=10$ and $\\alpha\_4 = -6$. Thus $$\\begin{equation\*} v=4v\_1+10v\_2 = -6v\_4+9v\_5 = \\begin{bmatrix} 24\\\\-6\\\\-12\\\\-6 \\end{bmatrix}. \\end{equation\*}$$

Finally, we can write our basis of $U\_1\\cap U\_2$ as just $\\{ v \\}$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>