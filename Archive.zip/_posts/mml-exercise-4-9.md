---
title: Find the singular value decomposition of a matrix II
categories: [Machine Learning,Linear Algebra]
tags: [SVD,Matrix,Eigenvector,Eigenvalue]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 4 Exercise 4.9**
{% endnote %}

<!--more-->

Solution: 

Observe that the eigenvalues of $A$ are complex, so we cannot simply find the eigendecomposition. Proceeding as in [Question 4.8](/mml-exercise-4-8.html), we have $A^{\\mathsf{T}}A = \\begin{bmatrix} 5&3\\\\ 3&5 \\end{bmatrix}$, which when we perform the eigendecomposition on this new matrix, we obtain $$D = \\begin{bmatrix} 8&0\\\\ 0&2 \\end{bmatrix}\\quad \\text{and} \\quad P=\\frac{1}{\\sqrt2}\\begin{bmatrix} 1&-1\\\\ 1&1 \\end{bmatrix}.$$ This $P$ is again our required $V$, and we have $\\Sigma = \\begin{bmatrix} 2\\sqrt2 & 0\\\\ 0&\\sqrt2 \\end{bmatrix}$.

As before, we can now compute $$u\_1 = \\frac{1}{2\\sqrt2}\\begin{bmatrix} 2&2\\\\-1&1 \\end{bmatrix} \\begin{pmatrix} \\frac{1}{\\sqrt2}\\\\ \\frac{1}{\\sqrt2} \\end{pmatrix} = \\begin{bmatrix} 1\\\\0 \\end{bmatrix},$$ and similarly $u\_2 = \\begin{bmatrix} 0\\\\1 \\end{bmatrix}$. Hence, our $U$ turns out to be the identity matrix.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>