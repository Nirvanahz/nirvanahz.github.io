---
title: Compute the derivative of the logistic sigmoid
categories: [Machine Learning,Calculus]
tags: [Derivative,Quotient Rule,Chain Rule,Logistic]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 5 Exercise 5.2**
{% endnote %}

<!--more-->

Solution: By Chain rule (5.32), we have $$(1+\\exp(-x))'=0+\\exp(-x)(-x)'=-\\exp(-x).$$ By the Quotient rule (5.30), we have\\begin{align\*}f'(x)=&\\ \\frac{(1)'(1+\\exp(-x))-1(1+\\exp(-x))'}{(1+\\exp(-x))^2}\\\\=&\\ \\frac{0(1+\\exp(-x))-(-\\exp(-x))}{(1+\\exp(-x))^2}\\\\=&\\ \\frac{\\exp(-x)}{(1+\\exp(-x))^2}.\\end{align\*}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Real Analysis";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "402d8b59cc9faa66d8d6b3b1eef9c01e";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "bottom";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>