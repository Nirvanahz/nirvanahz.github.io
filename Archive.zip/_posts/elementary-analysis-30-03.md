---
title:  Compute limits using L’Hospital’s Rule III
categories: [Solution,Elementary Analysis]
tags: [Limit,L’Hospital’s Rule,Derivative]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 30 Exercises 30.3
{% endnote %}

<!--more-->

Solution: 

### Part a

Since $|\sin x|\leq 1$, we have
\\begin{equation}\label{30-3-1}
\lim_{x\to \infty}\frac{\sin x}{x}=0.
\\end{equation} Therefore, by \eqref{30-3-1},
$$
\lim_{x\to \infty}\frac{x-\sin x}{x}=\lim_{x\to \infty}\frac{1-\frac{\sin x}{x}}{1}=\frac{1-0}{1}=1.
$$

{% note warning %}
In this case, we cannot apply L’Hospital’s Rule because the limit $\lim_{x\to \infty}(1-\cos x)$ does not exists.
{% endnote %}
---

### Part b

We consider 
$$
\ln x^{\sin(1/x)}=\sin(1/x)\ln x=-\sin (1/x)\ln(1/x).
$$ Using substitution $u=1/x$, we have
\\begin{align\*}
\lim_{x\to \infty }\ln x^{\sin(1/x)}
=&\ \lim_{u\to 0^+ }-\sin u\ln u\\\\
=&\ -\lim_{u\to 0^+ }\frac{\ln u}{\csc u}\\\\
\text{L’Hospital’s Rule}\ =&\ \lim_{u\to 0^+ }\frac{\frac{1}{u}}{\csc u\cot u}\\\\
=&\ \lim_{u\to 0^+ }\frac{\sin^2 u}{u\cos u}\\\\
=&\ \lim_{u\to 0^+ }\frac{\sin^2 u}{u^2}\lim_{u\to 0^+ }\frac{u}{\cos u}\\\\
\text{Use Example 1}\ =&\ 1\cdot \frac{0}{1}=0.
\\end{align\*} Here we used Example 1,
$$
\lim_{x\to 0}\frac{\sin x}{x}=1.
$$ Therefore by Theorem 20.5, we have
$$
\lim_{x\to \infty} x^{\sin(1/x)}=e^{0}=1.
$$


---

### Part c

Clearly, we have 
$$
\lim_{x\to 0^+}(1+\cos x)=2
$$ and 
$$
\lim_{x\to 0^+}(e^x-1)=(1^+-1)=0^+.
$$ Therefore,
$$
\lim_{x\to 0^+}\frac{1+\cos x}{e^x-1}=\frac{2}{0^+}=\infty.
$$

---

### Part d

Repeatedly applying L’Hospital’s Rule, we have 
\\begin{align\*}
\lim_{x\to 0}\frac{1-\cos 2x -2x^2}{x^4}
=&\ \lim_{x\to 0}\frac{2\sin 2x-4x}{4x^3} \\\\
=&\ \lim_{x\to 0}\frac{4\cos 2x-4}{12x^2} \\\\
=&\ \lim_{x\to 0}\frac{-8\sin 2x}{24x}\\\\
=&\ \lim_{x\to 0}\frac{-16\cos 2x}{24}\\\\
=&\ \frac{-16}{24}=-\frac{2}{3}.
\\end{align\*}

Another solution:

{% note success %}
We can also do it using [Exercise 30.2 (a)](/elementary-analysis-30-02.html#Part-a). Namely,
$$
\lim_{u\to 0}\frac{u^3}{\sin u-u}=-6\quad \text{ or }\quad \lim_{u\to 0}\frac{\sin u-u}{u^3}=-\frac{1}{6}.
$$
{% endnote %}

Apply L’Hospital’s Rule and set $u=2x$. We have
\\begin{align\*}
\lim_{x\to 0}\frac{1-\cos 2x -2x^2}{x^4}
=&\ \lim_{x\to 0}\frac{2\sin 2x-4x}{4x^3} \\\\
=&\ \lim_{u\to 0}\frac{2\\sin u-2 u}{\frac{1}{2}u^3} \\\\
=&\ 4\lim_{u\to 0}\frac{\sin u-u}{u^3}\\\\
=&\ -\frac{4}{6}=-\frac{2}{3}.
\\end{align\*}


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>