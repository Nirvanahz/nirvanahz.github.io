---
title: Differentiate vector-valued functions with respect to vector-valued variables II
categories: [Machine Learning,Calculus]
tags: [Derivative,Multivariable Calculus]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 5 Exercise 5.7**
{% endnote %}

<!--more-->

Solution: 

**Part a**

The chain rule tells us that $$\\frac{df}{dx} = \\frac{df}{dz}\\frac{dz}{dx},$$ where $\\dfrac{df}{dz}$ has dimension $1\\times 1$, and $\\dfrac{dz}{dx}$ has dimension $1\\times D$. We know $$\\frac{dz}{dx}=2x^{\\mathsf{T}}$$ from $f$ in [Question 6](/mml-exercise-5-6.html). Also, $\\dfrac{df}{dz} = \\dfrac{1}{1+z}$.

Therefore, $\\dfrac{df}{dx} = \\dfrac{2x^{\\mathsf{T}}}{1+x^{\\mathsf{T}}x}$.

---

**Part b**

Here we have $\\dfrac{df}{dz}$ is an $E\\times E$ matrix, namely $$\\begin{bmatrix} \\cos z\_1 & 0 & \\cdots & 0\\\\ 0 & \\cos z\_2 & \\cdots & 0\\\\ \\vdots & \\vdots & \\ddots & \\vdots \\\\ 0 & 0&\\cdots&\\cos z\_E \\end{bmatrix}.$$

Also, $\\dfrac{dz}{dx}$ is an $E\\times D$-dimensional matrix, namely $A$ itself.

The overall derivative is obtained by multiplying these two matrices together, which will again give us an $E\\times D$-dimensional matrix.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Real Analysis";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "402d8b59cc9faa66d8d6b3b1eef9c01e";
amzn_assoc_search_bar = "true";
amzn_assoc_search_bar_position = "bottom";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>