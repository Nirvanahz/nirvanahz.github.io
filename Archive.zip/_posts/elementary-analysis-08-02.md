---
title: Determine the limits and prove your claims
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit,Proof]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 8 Exercise 8.2
{% endnote %}

<!--more-->


Solution: 

### Part a

The limit is zero.

Let $\epsilon>0$ and let $N=\dfrac{1}{\epsilon}$. Then $n>N$ implies 
$$
\frac{n}{n^2+1}<\frac{n}{n^2}=\frac{1}{n}<\frac{1}{N}=\epsilon,
$$ and hence
$$
\left|\frac{n}{n^2+1}-0\right|=\frac{n}{n^2+1}<\epsilon
$$ as desired. Therefore $\lim\dfrac{n}{n^2+1}=0$.

---

### Part b

The limit is $\dfrac{7}{3}$.

Let $\epsilon>0$ and let $N=\dfrac{106}{9\epsilon}$. Then $n>N$ implies
$$
\frac{106}{9n+21}<\frac{106}{9N}=\epsilon.
$$ and hence
\\begin{align\*}
\left|\frac{7n-19}{3n+7}-\frac{7}{3}\right|=\frac{106}{9n+21}<\epsilon.
\\end{align\*} as desired. Therefore $\lim\dfrac{7n-19}{3n+7}=\dfrac{7}{3}$.

---

### Part c

The limit is $\dfrac{4}{7}$.

Let $\epsilon>0$ and let $N=\dfrac{41}{49\epsilon}+\dfrac{5}{7}$. Then $n>N$ implies
$$
\frac{41}{49n-35}<\frac{41}{49(\frac{41}{49\epsilon}+\frac{5}{7})-35}=\epsilon.
$$ and hence
\\begin{align\*}
\left|\frac{4n+3}{7n-5}-\frac{4}{7}\right|=\frac{41}{49n-35}<\epsilon.
\\end{align\*} as desired. Therefore $\lim\dfrac{4n+3}{7n-5}=\dfrac{4}{7}$.

---

### Part d

The limit is $\dfrac{2}{5}$.

Let $\epsilon>0$ and let $N=\dfrac{16}{25\epsilon}$. Then $n>N$ implies
$$
\frac{16}{25n+10}<\frac{16}{25n}<\frac{16}{25N}=\epsilon,
$$ and hence
$$
\left|\frac{2n+4}{5n+2}-\dfrac{2}{5}\right|=\frac{16}{25n+10}<\epsilon
$$ as desired. Therefore $\lim\dfrac{2n+4}{5n+2}=\dfrac{2}{5}$.

---

### Part e

The limit is $0$.

Let $\epsilon>0$ and let $N=\dfrac{1}{\epsilon}$. Then $n>N$ implies
$$
\left|\frac{1}{n}\sin n\right| \le \frac{1}{n}<\frac{1}{N}=\epsilon,
$$ here we used $|\sin n|\le 1$, and hence
$$
\left|\frac{1}{n}\sin n-0\right|=\left|\frac{1}{n}\sin n\right|<\epsilon
$$ as desired. Therefore $\lim \dfrac{1}{n}\sin n=0$.



<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>