---
title:  Limits involving the definition of the natural constant e
categories: [Solution,Elementary Analysis]
tags: [Limit,L’Hospital’s Rule,Natural Constant]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 30 Exercises 30.5
{% endnote %}

<!--more-->

Solution: 

We start by showing that
\\begin{equation}\label{30-5-1}
\lim_{x\to 0}\left(1+x\right)^{1/x}=e.
\\end{equation} Indeed, note that
$$
\left(1+x\right)^{1/x}=e^{ \ln\left(1+x\right)^{1/x} }.
$$ By L’Hospital’s Rule, we have
\\begin{align\*}
\lim_{x\to 0}\ln\left(1+x\right)^{1/x}
=&\ \lim_{x\to 0}\frac{\ln(1+x)}{x}\\\\
=&\ \lim_{x\to 0}\frac{\frac{1}{1+x}}{1}\\\\
=&\ 1.
\\end{align\*} Therefore, by Theorem 20.5, we have
$$
\lim_{x\to 0}\left(1+x\right)^{1/x}=e^1=e.
$$

{% note default %}
Usually, the natural constant $e$ is defined by \eqref{30-5-1}.
{% endnote %}

Apply Exercise 30.4, we also have
\\begin{equation}\label{30-5-2}
\lim_{y\to \infty}\left(1+\frac{1}{y}\right)^y=e.
\\end{equation}

---

### Part a

Let $u=2x$, then $\dfrac{1}{x}=\dfrac{2}{u}$. We have
\\begin{align\*}
\lim_{x\to 0}(1+2x)^{1/x}
=&\ \lim_{x\to 0}(1+2x)^{1/x}\\\\
=&\ \lim_{u\to 0}(1+u)^{2/u}\\\\
=&\ \lim_{u\to 0}\Big((1+u)^{1/u}\Big)^2\\\\
=&\ \Big(\lim_{u\to 0}(1+u)^{1/u}\Big)^2\\\\
\text{By \eqref{30-5-1} }\ =&\ e^2.
\\end{align\*}

---

### Part b

Let $u=y/2$, then $\dfrac{2}{y}=\dfrac{1}{u}$ and $y=2u$. We have
\\begin{align\*}
\lim_{y\to \infty}\left(1+\frac{2}{y}\right)^{y}
=&\ \lim_{u\to \infty}\left(1+\frac{1}{u}\right)^{2u}\\\\
=&\ \lim_{u\to \infty}\left(\Big(1+\frac{1}{u}\Big)^{u}\right)^2\\\\
=&\ \left(\lim_{u\to \infty}\Big(1+\frac{1}{u}\Big)^{u}\right)^2\\\\
\text{By \eqref{30-5-2} }\ =&\ e^2.
\\end{align\*}

---

### Part c

Note that
$$
\ln (e^x+x)^{1/x}=\frac{\ln(e^x+x)}{x}.
$$ By L’Hospital’s Rule, we have
\\begin{align\*}
\lim_{x\to \infty}\ln (e^x+x)^{1/x}
=&\ \lim_{x\to \infty}\frac{\ln(e^x+x)}{x}\\\\
=&\ \lim_{x\to \infty}\frac{\frac{e^x+1}{e^x+x}}{1}\\\\
=&\ \lim_{x\to \infty}\frac{e^x+1}{e^x+x}\\\\
=&\ \lim_{x\to \infty}\frac{1+\frac{1}{e^x}}{1+\frac{x}{e^x}}\\\\
=&\ \frac{1+0}{1+0}=1.
\\end{align\*} Here we used $\lim_{x\to\infty}\dfrac{1}{e^x}=0$ and (using L’Hospital’s Rule below)
$$
\lim_{x\to \infty}\frac{x}{e^x}=\lim_{x\to \infty}\frac{1}{e^x}=0.
$$ Therefore, we conclude using Theorem 20.5 that
$$
\lim_{x\to\infty}(e^x+x)^{1/x}=e^1=e.
$$


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>