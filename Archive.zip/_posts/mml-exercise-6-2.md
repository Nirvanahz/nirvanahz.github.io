---
title: Computations ivolving a mixture of two Gaussian distributions
categories: [Machine Learning,Statistics]
tags: [Distribution,Random Variables,Gaussian Distribution]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.2**
{% endnote %}

<!--more-->

Solution: 

**Part a**

We can write the probability density of the two-dimensional distribution as

$$ p(x,y)= 0.4\\mathcal{N}\\left(x, y|\\begin{bmatrix} 10\\\\ 2\\end{bmatrix}, \\begin{bmatrix} 1&0\\\\0&1\\end{bmatrix}\\right)+ 0.6\\mathcal{N}\\left(x, y|\\begin{bmatrix} 0\\\\ 0\\end{bmatrix}, \\begin{bmatrix} 8.4&2.0\\\\2.0&1.7\\end{bmatrix}\\right) $$

The marginal distribution of a weighted sum of distributions is given by the weighted sum of marginals, whereas the marginals of a bivariate normal distribution $\\mathcal{N}(x,y|\\mathbf{\\mu},\\mathbf{\\Sigma})$ are obtained according to the rule

$$ \\int \\mathcal{N}(x,y|\\mathbf{\\mu},\\mathbf{\\Sigma})dy= \\mathcal{N}(x|\\mu\_x, \\Sigma\_{xx}),$$  $$ \\int \\mathcal{N}(x,y|\\mathbf{\\mu},\\mathbf{\\Sigma})dx = \\mathcal{N}(y|\\mu\_y, \\Sigma\_{yy}) $$

Thus, the marginals of the distribution of interest are

$$ p(x) = 0.4\\mathcal{N}(x| 10, 1) + 0.6\\mathcal{N}(x| 0, 8.4),$$ $$ p(y) = 0.4\\mathcal{N}(x| 2, 1) + 0.6\\mathcal{N}(x| 0, 1.7). $$

---

**Part b**

The mean of a weighted sum of two distributions is the weighted sum of their averages

$$ \\mathbb{E}\_X\[x\] = 0.4\*10 + 0.6\*0 = 4,\\\\ \\mathbb{E}\_Y\[y\] = 0.4\*2 + 0.6\*0 = 0.8. $$

The mode of a continuous distribution is a point where this distribution has a peak. It can be determined by solving the extremum condition for each of the marginal distributions:

$$ \\frac{dp(x)}{dx} = 0,\\qquad \\frac{dp(y)}{dy} = 0 $$

In the case of a mixture of normal distributions these equations are non-linear and can be solved only numerically. After finding all the solutions of these equations one has to verify for every solution that it is a peak rather than an inflection point, i.e. that at this point

$$ \\frac{d^2p(x)}{dx^2} < 0 \\qquad \\text{ or } \\qquad \\frac{d^2p(y)}{dy^2} < 0 $$

The medians $m\_x, m\_y$ can be determined from the conditions

$$ \\int\_{-\\infty}^{m}p(x)dx = \\int^{+\\infty}\_{m}p(x)dx,$$ $$ \\int\_{-\\infty}^{m}p(y)dy = \\int^{+\\infty}\_{m}p(y)dy. $$

Again, these equations can be solved here only numerically.

---

**Part c**

The mean of a two-dimensional distribution is a vector of means of the marginal distributions

$$ \\mathbf{\\mu} = \\begin{bmatrix}4\\\\0.8\\end{bmatrix}. $$

The mode of two dimensional distribution is obtained first by solving the extremum conditions

$$ \\frac{\\partial p(x,y)}{\\partial x} = 0,\\quad \\frac{\\partial p(x,y)}{\\partial y} = 0. $$

and then verifying for every solution that it is indeed a peak, i.e.

$$ \\frac{\\partial^2 p(x,y)}{\\partial x^2} < 0,\\quad \\frac{\\partial^2 p(x,y)}{\\partial y^2} < 0,$$ $$\\det\\left( \\begin{bmatrix} \\frac{\\partial^2 p(x,y)}{\\partial x^2} & \\frac{\\partial^2 p(x,y)}{\\partial x\\partial y}\\\\ \\frac{\\partial^2 p(x,y)}{\\partial x\\partial y} & \\frac{\\partial^2 p(x,y)}{\\partial y^2} \\end{bmatrix} \\right) > 0. $$

Again, these equations can be solved only numerically.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>