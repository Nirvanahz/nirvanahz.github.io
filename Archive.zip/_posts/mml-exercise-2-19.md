---
title: Computations of an automorphism of vector space
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Linear Map,Automorphism]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.19**
{% endnote %}

<!--more-->

Solution:

**Part a**

Note that $\mathsf{rank}(A\_\\Phi) = 3$, so $\\ker(\\Phi)=\\{0\\}$ and $\mathsf{Im}(\\Phi)=\\mathbb{R}^3$.

**Part b**

Let $P$ be the change of basis matrix from the standard basis of $B$ to $\\mathbb{R}^3$. Then $$P=\\begin{bmatrix} 1&1&1\\\\ 1&2&0\\\\ 1&1&0 \\end{bmatrix}.$$

The matrix $\\overline{A\_\\Phi}$ is given by $$P^{-1}A\_\\Phi P = \\begin{bmatrix} 6&9&1\\\\-3&-5&0\\\\-1&-1&0 \\end{bmatrix}.$$


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>