---
title: Naive applications of Cauchy-Schwarz inequality
categories: [Machine Learning,Linear Algebra]
tags: [Inner Product,Cauchy-Schwarz inequality]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.9**
{% endnote %}

<!--more-->

Solution:  

a. Let $\\mathbf x=\[x\_1,\\dots,x\_n\]^\\top$ and $\\mathbf y=\[1,\\dots,1\]^\\top \\in\\mathbb R^n$. Then $$\\langle \\mathbf x, \\mathbf y\\rangle=x\_1+\\dots+x\_n=1,$$ $$\\langle \\mathbf x, \\mathbf x\\rangle = x\_1^2+\\dots+x\_n^2,$$ $$\\langle \\mathbf y, \\mathbf y\\rangle = 1+\\dots+1=n.$$Applying the Cauchy-Schwarz inequality, we have $$\\langle \\mathbf x, \\mathbf x\\rangle\\langle \\mathbf y, \\mathbf y\\rangle\\geqslant (\\langle \\mathbf x, \\mathbf y\\rangle)^2,$$which implies that $$n\\sum\_{i=1}^n x\_i^2\\geqslant 1.$$Therefore, we obtain $\\sum\_{i=1}^n x\_i^2\\geqslant \\frac{1}{n}$. 

b. Let $\\mathbf x=\[\\sqrt{x\_1},\\dots,\\sqrt{x\_n}\]^\\top$ and $\\mathbf y=\[1/\\sqrt{x\_1},\\dots,1/\\sqrt{x\_n}\]^\\top \\in\\mathbb R^n$. Then $$\\langle \\mathbf x, \\mathbf y\\rangle = 1+\\dots+1=n,$$ $$\\langle \\mathbf x, \\mathbf x\\rangle = x\_1+\\dots+x\_n=1,$$ $$\\langle \\mathbf y, \\mathbf y\\rangle =\\frac{1}{x\_1}+\\cdots+\\frac{1}{x\_n}.$$Applying the Cauchy-Schwarz inequality, we have $$\\langle \\mathbf x, \\mathbf x\\rangle\\langle \\mathbf y, \\mathbf y\\rangle\\geqslant (\\langle \\mathbf x, \\mathbf y\\rangle)^2,$$which implies that $$1\\sum\_{i=1}^n\\dfrac{1}{x\_i}\\geqslant n^2.$$Therefore, we obtain $\\sum\_{i=1}^n \\frac{1}{x\_i}\\geqslant n^2$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>