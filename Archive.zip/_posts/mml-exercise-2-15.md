---
title: Find a basis of the intersection of two solution spaces III
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Basis,Linear Equations]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.15**
{% endnote %}

<!--more-->

Solution:

**Part a**

Firstly, observe that $(0,0,0) \\in F$, and $(0,0,0)\\in G$ also. Next, we check that adding any two elements of the set does indeed get us another element of the set. Finally, if we multiply any element of the set by any real number, we again get another element of the required form. Thus $F$ and $G$ are subspaces indeed!

**Part b**

A vector in $F\\cap G$ will satisfy both conditions in the sets, so if we put $G$'s condition into $F$'s, we find $$(a-b)+(a+b)-(a-3b) = 0,$$ from which we have $a=-3b$. Thus, $$F\\cap G = \\{ (-4b,-2b,-6b) : b\\in \\mathbb{R} \\} = \mathsf{span}\[ (2,1,3)\].$$

**Part c**

Doing the same dimensional analysis as the previous three questions, we find that $F\\cap G$ has dimension 1. We have $$F=\mathsf{span}\[(1,0,1), (0,1,1)\],$$ and $$G=\mathsf{span}\[ (1,1,1),(-1,1,-3)\].$$

Proceeding in the same way as [Problem 2.12](/mml-exercise-2-12.html), we find that $-4v\_1-2v\_2 = -3v\_3+v\_4$, and hence $\\{(-4,-2,-6)\\}$ is a basis of $F \\cap G$, which agrees with Part b.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>