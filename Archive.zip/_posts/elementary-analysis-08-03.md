---
title: If the limit of sequence is zero then so is the limit of square roots
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit,Proof]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 8 Exercise 8.3
{% endnote %}

<!--more-->

Solution: Let $\epsilon>0$. Since $\lim s_n=0$, there exists $N>0$ such that 
$$
|s_n-0|=s_n < \epsilon^2
$$ for all $n>N$. Therefore $n>N$ implies that
$$
|\sqrt{s_n}-0|=\sqrt{s_n}<\sqrt{\epsilon^2}=\epsilon
$$ for all $n>N$ as desired. Thus $\lim s_n=0$.


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>