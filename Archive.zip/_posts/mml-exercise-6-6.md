---
title: Express variance using expectation in a different form
categories: [Machine Learning,Statistics]
tags: [Probability,Variance,Expectation]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.6**
{% endnote %}

<!--more-->

Solution: 

The standard definition of variance is

$$ \\mathbb{V}\_X\[x\] = \\mathbb{E}\_X\[(x-\\mu)^2\], $$

where

$$ \\mu = \\mathbb{E}\_X\[x\]. $$

Using the properties of average we can write:

\\begin{align\*} 
\\mathbb{V}\_X\[x\] = &\\ \\mathbb{E}\_X\[(x-\\mu)^2\] = \\mathbb{E}\_X\[x^2 - 2x\\mu +\\mu^2\] \\\\ =&\\ \\mathbb{E}\_X\[x^2\] - \\mathbb{E}\_X\[2x\\mu\] + \\mathbb{E}\_X\[\\mu^2\]\\\\=&\\ \\mathbb{E}\_X\[x^2\] - 2\\mu\\mathbb{E}\_X\[x\] + \\mu^2\\\\ =&\\ \\mathbb{E}\_X\[x^2\] - 2\\mu^2 + \\mu^2 = \\mathbb{E}\_X\[x^2\] - \\mu^2.
\\end{align\*}

By substituting to this equation the definition of $\\mu$, we obtain the desired equation

$$ \\mathbb{V}\_X\[x\] = \\mathbb{E}\_X\[(x-\\mu)^2\] = \\mathbb{E}\_X\[x^2\] - (\\mathbb{E}\_X\[x\])^2. $$

{% note default %}
In particular, it shows that the variance is always nonnegative. Moreover, $$ \\mathbb{E}\_X\[x^2\] \geqslant (\\mathbb{E}\_X\[x\])^2. $$
{% endnote %}

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>