---
title: An application of Bayes’ theorem
categories: [Machine Learning,Statistics]
tags: [Probability,Bayes’ Theorem]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.4**
{% endnote %}

<!--more-->

Solution: 

The probabilities of picking a mango or an apple from teh first bag are given by

$$ p(mango |1) = \\frac{4}{6} = \\frac{2}{3}\\\\ p(apple |1) = \\frac{2}{6} = \\frac{1}{3} $$

The probabilities of picking a mango or an apple from teh second bag are 

$$ p(mango |2) = \\frac{4}{8} = \\frac{1}{2}\\\\ p(apple |2) = \\frac{4}{8} = \\frac{1}{2} $$

The probability of picking the first or the second bag are equal to teh probabilities of head and tail respectively:

$$ p(1) = 0.6,\\qquad p(2) = 0.4 $$

We now can obtain the probability that the mango was picked from the second bag using Bayes' theorem:

$$ p(2 | mango) = \\frac{p(mango | 2)p(2)}{p(mango)} = \\frac{p(mango | 2)p(2)}{p(mango | 1)p(1) + p(mango | 2)p(2)} = \\frac{\\frac{1}{2}0.4}{\\frac{2}{3}0.6 + \\frac{1}{2}0.4} = \\frac{1}{3} $$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>