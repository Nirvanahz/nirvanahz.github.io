---
title: A time series model and Gaussian noise variable
categories: [Machine Learning,Statistics]
tags: [Time Series,Random Variable,Probability]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.5**
{% endnote %}

<!--more-->

Solution: 

**Part a**

$\\mathbf{x}\_{t+1}$ is obtained from $\\mathbf{x}\_{t}$ by a linear transformation, $\\mathbf{A}\\mathbf{x}\_{t}$ and adding a Gaussian random variabme $\\mathbf{w}$. Initial distribution for $\\mathbf{x}\_{0}$ is a Gaussian distribution, a linear transformation of a Gaussian random variable is also a Gaussian random variable, whareas a sum of Gaussian random variables is a Gaussian random variable. Thus, the joint distribution $p(\\mathbf{x}\_{0}, \\mathbf{x}\_{1},...,\\mathbf{x}\_{T})$ is also a Gaussian distribution.

---

**Part b (1)**


Let $\\mathbf{z} = \\mathbf{A}\\mathbf{x}\_{t+1}$. Since this is a linear transformation of a Gaussian random variable, $\\mathbf{x}\_t \\sim \\mathcal{N}(\\mathbf{\\mu}\_t,\\mathbf{\\Sigma})$, then $\\mathbf{z}$ is distributed as (see Eq. (6.88))

$$ \\mathbf{z} \\sim \\mathcal{N}(\\mathbf{A}\\mathbf{\\mu}\_t, \\mathbf{A}\\mathbf{\\Sigma}\\mathbf{A}^T), $$

whereas the mean and the covariance of a sum of two Gaussian random variables are given by the sum of the means and the covariances of these variables, i.e.,

$$ \\mathbf{x}\_{t+1} = \\mathbf{z} + \\mathbf{w} \\sim \\mathcal{N}(\\mathbf{A}\\mathbf{\\mu}\_t, \\mathbf{A}\\mathbf{\\Sigma}\\mathbf{A}^T + \\mathbf{Q}), $$

That is

$$ p(\\mathbf{x}\_{t+1}|\\mathbf{y}\_1,...,\\mathbf{y}\_t)= \\mathcal{N}(\\mathbf{x}\_{t+1}|\\mathbf{A}\\mathbf{\\mu}\_t, \\mathbf{A}\\mathbf{\\Sigma}\\mathbf{A}^T + \\mathbf{Q}). $$

---

**Part b (2)**

If we assume that $\\mathbf{x}\_{t+1}$ is fixed, then $\\mathbf{y}\_{t+1} = \\mathbf{C}\\mathbf{x}\_{t+1} + \\mathbf{v}$ follows the same distribution as $\\mathbf{v}$, but with the mean shifted by $\\mathbf{C}\\mathbf{x}\_{t+1}$, i.e.

$$ p(\\mathbf{y}\_{t+1}|\\mathbf{x}\_{t+1}, \\mathbf{y}\_1,...,\\mathbf{y}\_t)= \\mathcal{N}(\\mathbf{y}\_{t+1}|\\mathbf{C}\\mathbf{x}\_{t+1}, \\mathbf{R}). $$

The the joint probability is obtained as

\\begin{align\*} p(\\mathbf{y}\_{t+1}, \\mathbf{x}\_{t+1}| \\mathbf{y}\_1,...,\\mathbf{y}\_t)=&\\ p(\\mathbf{y}\_{t+1}|\\mathbf{x}\_{t+1}, \\mathbf{y}\_1,...,\\mathbf{y}\_t) p(\\mathbf{x}\_{t+1}| \\mathbf{y}\_1,...,\\mathbf{y}\_t)\\\\=&\\ \\mathcal{N}(\\mathbf{y}\_{t+1}|\\mathbf{C}\\mathbf{x}\_{t+1}, \\mathbf{R}) \\mathcal{N}(\\mathbf{x}\_{t+1}|\\mathbf{A}\\mathbf{\\mu}\_t, \\mathbf{A}\\mathbf{\\Sigma}\\mathbf{A}^T + \\mathbf{Q}). \end{align\*}

**Part b (3)**

Let us introduce temporary notation

$$ \\mathbf{\\mu}\_{t+1} = \\mathbf{A}\\mathbf{\\mu}\_t,$$ 

$$ \\mathbf{\\Sigma}\_{t+1} = \\mathbf{A}\\mathbf{\\Sigma}\\mathbf{A}^T + \\mathbf{Q},$$

$$p(\\mathbf{x}\_{t+1}|\\mathbf{y}\_1,...,\\mathbf{y}\_t) = \\mathcal{N}(\\mathbf{\\mu}\_{t+1}, \\mathbf{\\Sigma}\_{t+1}). $$

Then $\\mathbf{y}\_{t+1}$ is obtained in terms of the parameters of distribution $p(\\mathbf{x}\_{t+1}|\\mathbf{y}\_1,...,\\mathbf{y}\_t)$ following the same steps as question 1), with the result

$$ p(\\mathbf{y}\_{t+1}|\\mathbf{y}\_1,...,\\mathbf{y}\_t)= \\mathcal{N}(\\mathbf{y}\_{t+1}|\\mathbf{C}\\mathbf{\\mu}\_{t+1}, \\mathbf{C}\\mathbf{\\Sigma}\_{t+1}\\mathbf{C}^T + \\mathbf{R})= \\mathcal{N}\\left(\\mathbf{y}\_{t+1}|\\mathbf{C}\\mathbf{A}\\mathbf{\\mu}\_t, \\mathbf{C}(\\mathbf{A}\\mathbf{\\Sigma}\\mathbf{A}^T+ \\mathbf{Q})\\mathbf{C}^T + \\mathbf{R}\\right). $$

The required conditional distribution is then obtained as

$$ p(\\mathbf{x}\_{t+1}|\\mathbf{y}\_1,...,\\mathbf{y}\_t, \\mathbf{y}\_{t+1})= \\frac{p(\\mathbf{y}\_{t+1}, \\mathbf{x}\_{t+1}| \\mathbf{y}\_1,...,\\mathbf{y}\_t)} {p(\\mathbf{y}\_{t+1}| \\mathbf{y}\_1,...,\\mathbf{y}\_t)}= \\frac{\\mathcal{N}(\\mathbf{y}\_{t+1}|\\mathbf{C}\\mathbf{x}\_{t+1}, \\mathbf{R}) \\mathcal{N}(\\mathbf{x}\_{t+1}|\\mathbf{A}\\mathbf{\\mu}\_t, \\mathbf{A}\\mathbf{\\Sigma}\\mathbf{A}^T + \\mathbf{Q})} {\\mathcal{N}\\left(\\mathbf{y}\_{t+1}|\\mathbf{C}\\mathbf{A}\\mathbf{\\mu}\_t, \\mathbf{C}(\\mathbf{A}\\mathbf{\\Sigma}\\mathbf{A}^T + \\mathbf{Q})\\mathbf{C}^T + \\mathbf{R}\\right)}. $$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>