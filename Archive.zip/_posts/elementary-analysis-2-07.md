---
title:  Irrational-looking expressions may be rational
categories: [Solution,Elementary Analysis]
tags: [Rational Number]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 2 Exercises 2.7
{% endnote %}

<!--more-->

{% note default %}
Our main tool is Corollary 2.3.
{% endnote %}

Solution: 

### Part a

If $\sqrt{4+2\sqrt 3}-\sqrt 3$ is rational. Let us assume it to be $x$, we would like to determine $x$. Then we must have
$$
\sqrt{4+2\sqrt 3}=x+\sqrt{3}.
$$ Taking square of both sides, we obtain
\\begin{equation}\label{2-7}
4+2\sqrt{3}=x^2+2x\sqrt 3+3.
\\end{equation} Since $x$ is rational, we should expect that $2\sqrt{3}=2x\sqrt 3$ which is true only when $x=1$. Moreover, \eqref{2-7} is true if $x=1$. We have
$$
4+2\sqrt{3}=1+2\sqrt 3+3=(1+\sqrt 3)^2.
$$
Hence $\sqrt{4+2\sqrt 3}=1+\sqrt 3$ and $\sqrt{4+2\sqrt 3}-\sqrt 3=1$ is rational.

---

### Part b

This works very similar as Part a. We only give an outline. Note that
$$
(2+\sqrt 2)^2=4+4\sqrt 2+2=6+4\sqrt 2.
$$ Therefore
$$
\sqrt{6+4\sqrt 2}-\sqrt 2=(2+\sqrt 2)-\sqrt 2=2
$$ is rational.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>