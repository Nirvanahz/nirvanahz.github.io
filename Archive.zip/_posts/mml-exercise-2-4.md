---
title: Compute products of Matrices
categories: [Machine Learning,Linear Algebra]
tags: [Matrix]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.4**
{% endnote %}

<!--more-->

Solution:

**Part a**

The numbers of columns in the first matrix must equal the number of rows in the second, so this product is not defined.

**Part b**

$$\\begin{bmatrix} 4&3&5\\\\ 10&9&11\\\\ 16&15&17 \\end{bmatrix}$$

**Part c**

$$\\begin{bmatrix} 5&7&9\\\\ 11&13&15\\\\ 8&10&12 \\end{bmatrix}$$

**Part d**

$$\\begin{bmatrix} 14&6\\\\-21&2 \\end{bmatrix}$$

**Part e**

$$\\begin{bmatrix} 12&3&-3&-12\\\\-3&1&2&6\\\\ 6&5&1&0\\\\ 13&12&3&2 \\end{bmatrix}$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>