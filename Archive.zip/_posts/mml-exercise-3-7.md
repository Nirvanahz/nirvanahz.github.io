---
title: Compute Kernel and Image of identity minus a projection
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Projection,Kernel,Image]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 3 Exercise 3.7**
{% endnote %}

<!--more-->

Solution: 

**Part a**

Let $x\\in V$. Observe that $$((id-\\pi)\\circ(id-\\pi))(x) = (id-\\pi)(x-\\pi(x)) = (x-\\pi(x))-(\\pi(x)-\\pi^2(x)) = x-2\\pi(x)+\\pi^2(x).$$ Hence $(id -\\pi)$ is a projection if and only if $$x-\\pi(x) = x-2\\pi(x)+\\pi^2(x).$$ This happens if and only if $\\pi(x) = \\pi^2(x)$, that is to say, where $\\pi$ is a projection.

**Part b**

We have $$Im(id-\\pi) = \\{(id-\\pi)(x):x\\in V\\} = \\{x-\\pi(x):x\\in V\\}.$$ Observe that $\\pi(x-\\pi(x)) = \\pi(x)-\\pi^2(x) = 0$, since $\\pi$ is a projection. Thus, $Im(id-\\pi)\\subseteq\\ker\\pi$.

Now, suppose $k\\in \\ker \\pi$. Then $k-\\pi(k)=k$, so $k\\in Im(id-\\pi)$. Thus $\\ker\\pi\\subseteq Im(id-\\pi)$. Therefore, we have that $$Im(id-\\pi) = \\ker\\pi. \\qquad \\lozenge$$

---

We have that $$\\ker(id-\\pi) = \\{x\\in V : (id-\\pi)(x) = 0\\} = \\{x\\in V : x=\\pi(x)\\}.$$ Clearly, $\\ker(id-\\pi)\\subseteq Im\\pi$.

Take $x\\in Im\\pi$. Then there exists some $y\\in V$ such that $\\pi(y)=x$. Observe that $$(id-\\pi)(x) = x-\\pi(x) = \\pi(y)-\\pi^2(y) = 0,$$ since $\\pi$ is a projection. Hence $Im\\pi\\subseteq\\ker(id-\\pi)$. Therefore we have that $\\ker(id-\\pi) = Im\\pi$.


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>