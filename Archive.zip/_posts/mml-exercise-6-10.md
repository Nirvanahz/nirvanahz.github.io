---
title:  Express the Gaussian distributions as an exponential family distribution
categories: [Machine Learning,Statistics]
tags: [Gaussian Distribution,Distribution,Probability]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 6 Exercise 6.10**
{% endnote %}

<!--more-->

Solution: 

**Part a**

The two normal distributions are given by

$$ \\mathcal{N}(\\mathbf{x}|\\mathbf{a}, \\mathbf{A}) = (2\\pi)^{-\\frac{D}{2}}|\\mathbf{A}|^{-\\frac{1}{2}} \\exp\\left\[-\\frac{1}{2}(\\mathbf{x} - \\mathbf{a})^T\\mathbf{A}^{-1}(\\mathbf{x} - \\mathbf{a})\\right\],$$ $$\\mathcal{N}(\\mathbf{x}|\\mathbf{b}, \\mathbf{B}) = (2\\pi)^{-\\frac{D}{2}}|\\mathbf{B}|^{-\\frac{1}{2}} \\exp\\left\[-\\frac{1}{2}(\\mathbf{x} - \\mathbf{b})^T\\mathbf{B}^{-1}(\\mathbf{x} - \\mathbf{b})\\right\] $$

their product is

$$ \\mathcal{N}(\\mathbf{x}|\\mathbf{a}, \\mathbf{A}) \\mathcal{N}(\\mathbf{x}|\\mathbf{b}, \\mathbf{B}) = (2\\pi)^{-D}|\\mathbf{A}\\mathbf{B}|^{-\\frac{1}{2}} \\exp\\left\\{-\\frac{1}{2}\\left\[(\\mathbf{x} - \\mathbf{a})^T\\mathbf{A}^{-1}(\\mathbf{x} - \\mathbf{a})+(\\mathbf{x} - \\mathbf{b})^T\\mathbf{B}^{-1}(\\mathbf{x} - \\mathbf{b})\\right\]\\right\\} $$

The expression in the exponent can be written as

\\begin{align\*} \\Phi =&\\ (\\mathbf{x} - \\mathbf{a})^T\\mathbf{A}^{-1}(\\mathbf{x} - \\mathbf{a})+(\\mathbf{x} - \\mathbf{b})^T\\mathbf{B}^{-1}(\\mathbf{x} - \\mathbf{b})\\\\=&\\ \\mathbf{x}^T\\mathbf{A}^{-1}\\mathbf{x} - \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{x} - \\mathbf{x}^T\\mathbf{A}^{-1}\\mathbf{a}+ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a}+ \\mathbf{x}^T\\mathbf{B}^{-1}\\mathbf{x} - \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{x} - \\mathbf{x}^T\\mathbf{B}^{-1}\\mathbf{b}+ \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b}\\\\=&\\ \\mathbf{x}^T(\\mathbf{A}^{-1}+\\mathbf{B}^{-1})\\mathbf{x}- (\\mathbf{a}^T\\mathbf{A}^{-1} + \\mathbf{b}^T\\mathbf{B}^{-1})\\mathbf{x}- \\mathbf{x}^T(\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{B}^{-1}\\mathbf{b})+ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b}
\\end{align\*}

we now introduce notation

$$ \\mathbf{C}^{-1} = (\\mathbf{A}^{-1}+\\mathbf{B}^{-1}),$$  $$ \\mathbf{c} = \\mathbf{C}(\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{B}^{-1}\\mathbf{b}),$$ $$ \\mathbf{c}^T = (\\mathbf{a}^T\\mathbf{A}^{-1} + \\mathbf{b}^T\\mathbf{B}^{-1})C.$$

(This can be checked by transposing the previous equation).

The expression in the exponent now takes form

\\begin{align\*} \\Phi=&\\ \\mathbf{x}^T\\mathbf{C}^{-1}\\mathbf{x} - \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{x} - \\mathbf{x}^T\\mathbf{C}^{-1}\\mathbf{c}+ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b}\\\\=&\\ \\mathbf{x}^T\\mathbf{C}^{-1}\\mathbf{x} - \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{x} - \\mathbf{x}^T\\mathbf{C}^{-1}\\mathbf{c}+ \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{c} + \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b}- \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{c}\\\\=&\\ (\\mathbf{x} - \\mathbf{c})^T\\mathbf{C}^{-1}(\\mathbf{x} - \\mathbf{c})+ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b} - \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{c}\\end{align\*}

where we have completed the square.

The product of the two probability distributions can be now written as

\\begin{align\*} &\\ \\mathcal{N}(\\mathbf{x}|\\mathbf{a}, \\mathbf{A}) \\mathcal{N}(\\mathbf{x}|\\mathbf{b}, \\mathbf{B}) \\\\=&\\ (2\\pi)^{-D}|\\mathbf{A}\\mathbf{B}|^{-\\frac{1}{2}} \\exp\\left\\{-\\frac{1}{2}\\left\[(\\mathbf{x} - \\mathbf{c})^T\\mathbf{C}^{-1}(\\mathbf{x} - \\mathbf{c})+ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b} - \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{c} \\right\]\\right\\}\\\\=&\\ (2\\pi)^{-\\frac{D}{2}}|\\mathbf{C}|^{-\\frac{1}{2}} \\exp\\left\[-\\frac{1}{2}(\\mathbf{x} - \\mathbf{c})^T\\mathbf{C}^{-1}(\\mathbf{x} - \\mathbf{c})\\right\] \\times (2\\pi)^{-\\frac{D}{2}}\\frac{|\\mathbf{A}\\mathbf{B}|^{-\\frac{1}{2}}}{|\\mathbf{C}|^{-\\frac{1}{2}}} \\exp\\left\\{-\\frac{1}{2}\\left\[ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b} - \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{c} \\right\]\\right\\}\\\\=&\\ c\\mathcal{N}(\\mathbf{c}|\\mathbf{c}, \\mathbf{C}),\\end{align\*}

where we defined

$$ c = (2\\pi)^{-\\frac{D}{2}}\\frac{|\\mathbf{A}\\mathbf{B}|^{-\\frac{1}{2}}}{|\\mathbf{C}|^{-\\frac{1}{2}}} \\exp\\left\\{-\\frac{1}{2}\\left\[ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b} - \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{c} \\right\]\\right\\} $$

We now can used the properties that a) the determinant of a matrix product is product of the determinants, and b) determinant of a matrix inverse is the inverse of the determinant of this matrix, and write

$$ \\frac{|\\mathbf{A}||\\mathbf{B}|}{|\\mathbf{C}|}= |\\mathbf{A}||\\mathbf{C}^{-1}||\\mathbf{B}|= |\\mathbf{A}\\mathbf{C}^{-1}\\mathbf{B}|= |\\mathbf{A}(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})\\mathbf{B}|= |\\mathbf{A} + \\mathbf{B}| $$

For the expression in the exponent we can write

\\begin{align\*} &\\ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b} - \\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{c}\\\\=&\\ \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b}- (\\mathbf{a}^T\\mathbf{A}^{-1} + \\mathbf{b}^T\\mathbf{B}^{-1})(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})^{-1} (\\mathbf{A}^{-1}\\mathbf{a} + \\mathbf{B}^{-1}\\mathbf{b})\\\\=&\\ \\mathbf{a}^T\\left\[\\mathbf{A}^{-1} - \\mathbf{A}^{-1}(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})\\mathbf{A}^{-1}\\right\]\\mathbf{a}+ \\mathbf{b}^T\\left\[\\mathbf{B}^{-1} - \\mathbf{B}^{-1}(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})\\mathbf{B}^{-1}\\right\]\\mathbf{b}\\\\& \\qquad- \\mathbf{a}^T\\mathbf{A}^{-1}(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})^{-1} \\mathbf{B}^{-1}\\mathbf{b}- \\mathbf{b}^T\\mathbf{B}^{-1}(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})^{-1} \\mathbf{A}^{-1}\\mathbf{a} \\end{align\*}

Using the property $(\\mathbf{A}\\mathbf{B})^{-1} = \\mathbf{B}^{-1}\\mathbf{A}^{-1}$ we obtain

$$ \\mathbf{A}^{-1}(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})^{-1} \\mathbf{B}^{-1}= \\left\[\\mathbf{B}(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})\\mathbf{A}\\right\]^{-1}= (\\mathbf{A} + \\mathbf{B})^{-1} $$

and

\\begin{align\*} &\\ \\mathbf{A}^{-1} - \\mathbf{A}^{-1}(\\mathbf{A}^{-1} + \\mathbf{B}^{-1})\\mathbf{A}^{-1}=\\mathbf{A}^{-1}\\left\[1 - (\\mathbf{A}^{-1} + \\mathbf{B}^{-1})\\mathbf{A}^{-1}\\right\]\\\\=&\\ \\mathbf{A}^{-1}\\left\[1 - \\mathbf{B}(\\mathbf{A} + \\mathbf{B})^{-1}\\mathbf{A}\\mathbf{A}^{-1}\\right\]= \\mathbf{A}^{-1}\\left\[1 - \\mathbf{B}(\\mathbf{A} + \\mathbf{B})^{-1}\\right\]\\\\=&\\ \\mathbf{A}^{-1}\\left\[(\\mathbf{A} + \\mathbf{B}) - \\mathbf{B}\\right\](\\mathbf{A} + \\mathbf{B})^{-1}= (\\mathbf{A} + \\mathbf{B})^{-1} \\end{align\*}

we thus conclude that

$$ c = (2\\pi)^{-\\frac{D}{2}}|\\mathbf{A}+\\mathbf{B}|^{-\\frac{1}{2}} \\exp\\left\\{-\\frac{1}{2}( \\mathbf{a} - \\mathbf{b})^T(\\mathbf{A} + \\mathbf{B})^{-1}(\\mathbf{a} -\\mathbf{b})\\right\\}= \\mathcal{N}(\\mathbf{b}|\\mathbf{a}, \\mathbf{A}+ \\mathbf{B})= \\mathcal{N}(\\mathbf{a}|\\mathbf{b}, \\mathbf{A}+ \\mathbf{B}). $$

---

**Part b**

Multivariate normal distribution, $\\mathcal{N}(\\mathbf{x}|\\mathbf{a},\\mathbf{A})$ can be represented as a distribution from an exponential family:

\\begin{align\*} &\\ \\mathcal{N}(\\mathbf{x}|\\mathbf{a},\\mathbf{A}) = (2\\pi)^{-\\frac{D}{2}}|\\mathbf{A}|^{-\\frac{1}{2}} \\exp\\left\[-\\frac{1}{2}(\\mathbf{x} - \\mathbf{a})^T\\mathbf{A}^{-1}(\\mathbf{x} - \\mathbf{a})\\right\]\\\\=&\\ (2\\pi)^{-\\frac{D}{2}} \\exp\\left\[-\\frac{1}{2}\\text{tr}(\\mathbf{A}^{-1}\\mathbf{x}\\mathbf{x}^T) + \\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{x}- \\frac{1}{2}\\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} - \\frac{1}{2}\\log|\\mathbf{A}| \\right\],\\end{align\*} 

where we used that $\\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{x} = \\mathbf{x}^T\\mathbf{A}^{-1}\\mathbf{a}$, and also write the first term as

$$ \\mathbf{x}^T\\mathbf{A}^{-1}\\mathbf{x}= \\sum\_{i,j}x\_i (\\mathbf{A}^{-1})\_{ij} x\_j= \\sum\_{i,j}(\\mathbf{A}^{-1})\_{ij} x\_j x\_i= \\sum\_{i,j}(\\mathbf{A}^{-1})\_{ij} (\\mathbf{x}\\mathbf{x}^T)\_{ji}= \\text{tr}(\\mathbf{A}^{-1}\\mathbf{x}\\mathbf{x}^T) $$

Representing $\\mathcal{N}(\\mathbf{x}|\\mathbf{b},\\mathbf{B})$ in a similar way and multiplying the two distributions we readily obtain

\\begin{align\*} &\\ \\mathcal{N}(\\mathbf{x}|\\mathbf{a},\\mathbf{A})\\mathcal{N}(\\mathbf{x}|\\mathbf{b},\\mathbf{B})\\\\=&\\ (2\\pi)^{-D} \\exp\\left\\{-\\frac{1}{2}\\text{tr}\\left\[(\\mathbf{A}^{-1}+ \\mathbf{B}^{-1})\\mathbf{x}\\mathbf{x}^T\\right\]+ (\\mathbf{a}^T\\mathbf{A}^{-1}+\\mathbf{b}^T\\mathbf{B}^{-1})\\mathbf{x}\\right.\\\\ &\\ \\left. - \\frac{1}{2}\\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} - \\frac{1}{2}\\log|\\mathbf{A}|- \\frac{1}{2}\\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b} - \\frac{1}{2}\\log|\\mathbf{B}| \\right\\}\\\\=&\\ c\\mathcal{N}(\\mathbf{x}|\\mathbf{c},\\mathbf{C}), \\end{align\*} 

where we defined

$$ \\mathbf{C}^{-1} = \\mathbf{A}^{-1}+ \\mathbf{B}^{-1},\\quad \\mathbf{c}^T\\mathbf{C}^{-1} = \\mathbf{a}^T\\mathbf{A}^{-1}+\\mathbf{b}^T\\mathbf{B}^{-1},$$ $$ c = (2\\pi)^{-\\frac{D}{2}} \\exp\\left\\{\\frac{1}{2}\\mathbf{c}^T\\mathbf{C}^{-1}\\mathbf{c} + \\frac{1}{2}\\log|\\mathbf{C}|- \\frac{1}{2}\\mathbf{a}^T\\mathbf{A}^{-1}\\mathbf{a} - \\frac{1}{2}\\log|\\mathbf{A}|- \\frac{1}{2}\\mathbf{b}^T\\mathbf{B}^{-1}\\mathbf{b} - \\frac{1}{2}\\log|\\mathbf{B}| \\right\\} $$

Coefficient $c$ can now be reduced to the required form using the matrix transformations described in part a).

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Statistics";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "a1702ca86c77f1a4b0df1c05cdf77dce";
amzn_assoc_rows = "2";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>