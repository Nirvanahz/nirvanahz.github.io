---
title: Verify a set with certain binary operation is an Abelian group
categories: [Machine Learning,Linear Algebra]
tags: [Abelian Group, Group]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.1**
{% endnote %}

<!--more-->

Solution:

a. We check conditions in Definition 2.7 and the commutativity. Note that \\begin{equation}\\label{2.1.2}a\\star b=(a+1)(b+1)-1.\\end{equation} (1) Closure of $\\mathbb R\\setminus \\{-1\\}$ under $\\star$: if $a,b\\in\\mathbb R\\setminus \\{-1\\}$, then $(a+1)(b+1)\\ne 0$. Therefore $ab+a+b\\ne -1$, which shows $a\\star b\\in \\mathbb R\\setminus \\{-1\\}$.

(2) Associativity: if $a,b,c\\in\\mathbb R\\setminus \\{-1\\}$, then it follows from \\eqref{2.1.2} that \\begin{align\*}(a\\star b)\\star c = &\\ ((a+1)(b+1)-1)\\star c\\\\ =& \\ (a+1)(b+1)(c+1)-1\\end{align\*}and \\begin{align\*}a\\star(b\\star c)=&\\ a\\star((b+1)(c+1)-1)\\\\ = &\\ (a+1)(b+1)(c+1)-1.\\end{align\*}Thus $(a\\star b)\\star c=a\\star(b\\star c)$.

(3) Neural element: if $a\\in\\mathbb R\\setminus \\{-1\\}$, then $$a\\star 0= a\\cdot 0+a+0=a$$and $$0\\star a=0\\cdot a +0+a=a.$$ (4) Inverse element: if $a\\in\\mathbb R\\setminus \\{-1\\}$, then $a+1\\ne 0$ and we have $a^{-1}=\\dfrac{1}{a+1}-1$. This can be checked directly using \\eqref{2.1.2}.

(5) Commutativity: if $a,b\\in\\mathbb R\\setminus \\{-1\\}$, it is clear from \\eqref{2.1.2} that \\begin{align\*}a\\star b= &\\ (a+1)(b+1)-1\\\\= &\\ (b+1)(a+1)-1=b\\star a.\\end{align\*} b. Recall the computation from part a.(2), we have $$3\\star x \\star x = (3+1)(x+1)(x+1)-1.$$Hence we have to it reduces to solve $$4(x+1)^2=16,$$which gives $x+1=\\pm 2$. We have $x=1$ or $x=-3$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>