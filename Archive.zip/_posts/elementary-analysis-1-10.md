---
title:  Show an identity using known identities
categories: [Solution,Elementary Analysis]
tags: [Induction,Identity]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 1 Exercise 1.10
{% endnote %}

<!--more-->

Solution: Recall from [Exercise 1.4](/elementary-analysis-1-04.html) that
\\begin{equation}\label{eq:1-10-1}
1+3+\cdots+(2n-1)=n^2.
\\end{equation} Note that 
$$
(2n+1)+(2n+3)+\cdots+(4n-1)=(1+3+5+\cdots+(4n-3)+(4n-1)) -(1+3+\cdots+(2n-1)).
$$ Using \eqref{eq:1-10-1}, we find that
$$
1+3+5+\cdots+(4n-3)+(4n-1)=(2n)^2=4n^2,
$$ and
$$
1+3+\cdots+(2n-1)=n^2.
$$ Therefore
$$
(2n+1)+(2n+3)+\cdots+(4n-1)=4n^2-n^2=3n^2.
$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>