---
title:  Using the principle of mathematical induction to show inequalities II
categories: [Solution,Elementary Analysis]
tags: [Induction,Inequality]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 1 Exercise 1.9
{% endnote %}

<!--more-->

Solution: 

### Part a

If $n=1$, $2^1=2$ and $1^2=1$. True!
If $n=2$, $2^2=4$ and $2^2=4$. False!
If $n=3$, $2^3=8$ and $3^2=9$. False!
If $n=4$, $2^4=16$ and $4^2=16$. False!
If $n=5$, $2^5=32$ and $5^2=25$. True!
If $n=6$, $2^6=64$ and $6^2=36$. True!

We probably should guess that $2^n>n^2$ is true for all integers $n\ge 5$.

---

### Part b

The $n$-th proposition is
$$
P_n: \quad 2^n> n^2.
$$ Clearly, $P_5$ is true as we checked in Part a. We have the induction basis.

Now we assume $P_n$ is true (here we assume that $n\ge 5$), that is $2^n> n^2$. We would like to show $P_{n+1}$ is true based on $P_n$. Note that $n\ge 5$, we have
\\begin{equation}\label{eq:1-9-1}
n^2\ge 5n>3n\ge 2n+1.
\\end{equation} Therefore
\\begin{align\*}
2^{n+1}=&\ 2\cdot 2^n> 2\cdot n^2\\\\
=&\ n^2+n^2>n^2+2n+1=(n+1)^2.
\\end{align\*} Here in the last inequality we used \eqref{eq:1-9-1}. Therefore $P_{n+1}$ is true if $P_n$ is true. By the principle of mathematical induction, we make the conclusion that $P_n$ is true for all positive integers $n$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>