---
title: Find the limit by solving equation II
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 9 Exercise 9.5
{% endnote %}

<!--more-->

{% note default %}
The idea is pretty much the same as [Exercise 9.4](/elementary-analysis-09-04.html).
{% endnote %}

Solution: Since $(t_n)$ converges. Set $\lim t_n=s$. By $t_{n+1}=\dfrac{t_n^2+2}{2t_n}$, we have
\begin{equation}\label{09-05-01}
\lim 2t_{n+1}t_n=\lim (t_n^2+2).
\end{equation} On one hand, by Theorems 9.2 and 9.4, we have
\begin{equation}\label{09-05-02}
\lim 2t_{n+1}t_n=2\lim t_{n+1}\lim t_n=2t^2.
\end{equation} On the other hand, by Theorems 9.3 and 9.4, we have
\begin{equation}\label{09-05-03}
\lim (t_n^2+2)=\lim t_n\lim t_n+\lim 2=t^2+2.
\end{equation} Combining \eqref{09-05-01}, \eqref{09-05-02}, \eqref{09-05-03}, we have
$$
2t^2=t^2+2.
$$ Solving for $t$, we must have $t=\pm \sqrt 2$.

Since $t_1>0$, it is clear by induction that $t_n>0$ for all $n$. Now it follows from [Exercise 8.9](/elementary-analysis-08-09.html) that $t>0$. Therefore, we conclude that $t=\sqrt 2$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>