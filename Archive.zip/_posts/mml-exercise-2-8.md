---
title: Compute the inverse of matrix
categories: [Machine Learning,Linear Algebra]
tags: [Matrix,Gaussian Elimination]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.8**
{% endnote %}

<!--more-->

Solution:

**Part a**

Observe that $\\det A = 2(24-25) -3(18-20) + 4(15-16) = -2+6-4=0$, so $A$ is not invertible.

**Part b**

We perform Gaussian elimination on $\\left\[ \\begin{array}{cccc|cccc} 1&&1&&1&&&\\\\ &1&1&&&1&&\\\\ 1&1&&1&&&1&\\\\ 1&1&1&&&&&1 \\end{array} \\right\]$, where a blank space denotes a 0.

Firstly, with $r\_3-r\_1$, $r\_4-r\_1$, $r\_3-r\_2$, and $r\_4-r\_2$, we have $$\\left\[ \\begin{array}{cccc|cccc} 1&&1&&1&&&\\\\ &1&1&&&1&&\\\\ &&-2&1&-1&-1&1&\\\\ &&-1&&-1&-1&&1 \\end{array} \\right\].$$

Then with $r\_1+r\_4$, $r\_2+r\_4$, and $r\_3-2r\_4$, we have $$\\left\[ \\begin{array}{cccc|cccc} 1&&&&&-1&&1\\\\ &1&&&-1&&&1\\\\ &&&1&1&1&1&-2\\\\ &&-1&&-1&-1&&1 \\end{array} \\right\].$$

Finally, swapping $r\_3$ and $r\_4$, then multiplying $r\_3$ by $-1$, we have $$\\left\[ \\begin{array}{cccc|cccc} 1&&&&&-1&&1\\\\ &1&&&-1&&&1\\\\ &&1&&1&1&&-1\\\\ &&&1&1&1&1&-2 \\end{array} \\right\].$$

The matrix to the right of the vertical line is the inverse of $A$.

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>