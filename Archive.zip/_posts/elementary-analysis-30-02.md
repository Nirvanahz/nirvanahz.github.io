---
title:  Compute limits using L’Hospital’s Rule II
categories: [Solution,Elementary Analysis]
tags: [Limit,L’Hospital’s Rule,Derivative]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 30 Exercises 30.2
{% endnote %}

<!--more-->

Solution: 

### Part a

We can apply L’Hospital’s Rule repeatedly to get the answer. Please check the conditions for applying L’Hospital’s Rule carefully for every step. We have
\\begin{align\*}
\lim_{x\to 0}\frac{x^3}{\sin x-x}
=&\ \lim_{x\to 0}\frac{3x^2}{\cos x-1}\\\\
=&\ \lim_{x\to 0}\frac{6x}{-\sin x}\\\\
=&\ \lim_{x\to 0}\frac{6}{-\cos x}\\\\
=&\ \frac{6}{-1}=-6.
\\end{align\*}

---

### Part b

We shall use the following limit from Example 1, that is
$$
\lim_{x\to 0}\frac{\sin x}{x}=1.
$$ This also implies that
\\begin{equation}\label{eq:30-2}
\lim_{x\to 0}\frac{\tan x}{x}=\lim_{x\to 0}\frac{\sin x}{x}\lim_{x\to 0}\frac{1}{\cos x}=1.
\\end{equation} Therefore, we have
\\begin{align\*}
\lim_{x\to 0}\frac{\tan x-x}{x^3}
=&\ \lim_{x\to 0}\frac{\sec^2 x-1}{3x^2}\\\\
=&\ \lim_{x\to 0}\frac{\tan^2 x}{3x^2}\\\\
=&\ \frac{1}{3}\lim_{x\to 0}\Big(\frac{\tan x}{x}\Big)^2\\\\
=&\ \frac{1}{3}\Big(\lim_{x\to 0}\frac{\tan x}{x}\Big)^2\\\\
\text{ Use \eqref{eq:30-2} }=&\ \frac{1}{3}\cdot 1=\frac{1}{3}.
\\end{align\*}

---

### Part c

We can apply L’Hospital’s Rule repeatedly to get the answer. Please check the conditions for applying L’Hospital’s Rule carefully for every step. We have
\\begin{align\*}
\lim_{x\to 0}\left(\frac{1}{\sin x}-\frac{1}{x}\right)
=&\ \lim_{x\to 0}\frac{x-\sin x}{x\sin x}\\\\
=&\ \lim_{x\to 0}\frac{1-\cos x}{\sin x+x\cos x}\\\\
=&\ \lim_{x\to 0}\frac{\sin x}{\cos x+\cos x-x\sin x}\\\\
=&\ \frac{0}{1+1-0}=0.
\\end{align\*}

---

### Part d

We have 
$$
\ln(\cos x)^{1/x^2}=\frac{1}{x^2}\ln(\cos x).
$$ Instead of computing $\lim_{x\to 0} (\cos x)^{1/x^2}$ directly, we compute $\lim_{x\to 0}\dfrac{1}{x^2}\ln(\cos x)$ first. We can apply L’Hospital’s Rule and obtain that
\\begin{align\*}
\lim_{x\to 0}\frac{1}{x^2}\ln(\cos x)
=&\ \lim_{x\to 0}\frac{\ln(\cos x)}{x^2}\\\\
=&\ \lim_{x\to 0}\frac{ \frac{-\sin x}{\cos x} }{2x}\\\\
=&\ -\frac{1}{2}\lim_{x\to 0}\frac{\tan x}{x}\\\\
\text{ Use \eqref{eq:30-2} }=&\ -\frac{1}{2}.
\\end{align\*} Therefore, by Theorem 20.5, we have
$$
\lim_{x\to 0}\ln(\cos x)^{1/x^2}=e^{-1/2}=\frac{1}{\sqrt e}.
$$

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>