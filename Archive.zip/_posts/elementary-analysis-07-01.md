---
title:  Find limits of sequences I
categories: [Solution,Elementary Analysis]
tags: [Sequence,Limit]
mathjax: true

---

{% note info %}
[Solution to Elementary Analysis: The Theory of Calculus Second Edition](/elementary-analysis-toc.html) Section 7 Exercises 7.1 & 7.2
{% endnote %}

<!--more-->

### Exercise 7.1

Solution: 

(a) $s_1=1/4$, $s_2=1/7$, $s_3=1/10$, $s_4=1/13$, $s_5=1/16$.

(b) $b_1=4/3$, $b_2=1$, $b_3=10/11$, $b_4=13/15$, $b_5=16/19$.

(c) $c_1=1/3$, $c_2=2/9$, $c_3=1/9$, $c_4=4/81$, $c_5=5/243$.

(d) $\sqrt 2/2$, $1$, $\sqrt 2/2$, $0$, $-\sqrt 2/2$.

### Exercise 7.2

Solution:

(a) Converges. Limits is 0.

(b) Converges. Limits is $3/4$. See Example 2,
$$
\frac{3n+1}{4n-1}=\frac{3+\frac{1}{n}}{4-\frac{1}{n}}.
$$

(c) Converges. Limits is 0.

(d) Diverges. (Indeed, it is periodic.)

<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_ad_mode = "manual";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "My recommendations on Calculus and Analysis";
amzn_assoc_linkid = "cfda343bc63399373d473026228d47e1";
amzn_assoc_asins = "1493927116,1461462703,0471000051,0471000078,1259064786,1077254547,366248790X,1285741552";
</script>
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>