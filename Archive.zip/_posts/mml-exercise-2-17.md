---
title: Computations involving a linear mapping
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Linear Map]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.17**
{% endnote %}

<!--more-->

Solution:

**Part a**

From the coefficients on the right, we have $A\_\\Phi = \\begin{bmatrix} 3&2&1\\\\ 1&1&1\\\\ 1&-3&0\\\\ 2&3&1 \\end{bmatrix}$.

**Part b**

Using Gaussian elimination, we can compute that $\mathsf{rank}(A\_\\Phi) = 3$. 

**Part c**

From this we deduce that the kernel is trivial (i.e. only $(0,0,0)$), and clearly $$\mathsf{Im}(\\Phi)= \\{ (3x\_1+2x\_2+x\_1,x\_1+x\_2+x\_3,x\_1-3x\_2,2x\_1+3x\_2+x\_3)^{\\mathsf{T}} : x\_1, x\_2, x\_3 \\in \\mathbb{R} \\}.$$ We have $\\dim(\\ker(\\Phi))=0$, and $\\dim(\mathsf{Im}(\\Phi))=\mathsf{rank}(A\_\\Phi)=3$.


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>