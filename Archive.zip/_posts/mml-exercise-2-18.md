---
title: Properties of automorphisms of vector space
categories: [Machine Learning,Linear Algebra]
tags: [Vector Space,Linear Map,Automorphism]
mathjax: true

---

{% note info %}
**[Solution to Mathematics for Machine learning](/mml-solution-manual.html) Chapter 2 Exercise 2.18**
{% endnote %}

<!--more-->

Solution:

We have two automorphisms, which means they map linearly and bijectively from the space, $E$, to itself. The maps therefore both have kernel $\\{0\\}$ (by injectivity) and image $E$ (by surjectivity). From this, we immediately deduce that $\\ker(f)\\cap \mathsf{Im}(g) = \\{0\\}$, indeed. Similarly, we deduce that $g\\circ f$ also has kernel $\\{0\\}$ and image $E$, as required. Note that we didn't need the condition that $f\\circ g = \mathsf{id}\_E$.


<script type="text/javascript">
amzn_assoc_placement = "adunit0";
amzn_assoc_search_bar = "true";
amzn_assoc_tracking_id = "linearalgeb0e-20";
amzn_assoc_search_bar_position = "bottom";
amzn_assoc_ad_mode = "search";
amzn_assoc_ad_type = "smart";
amzn_assoc_marketplace = "amazon";
amzn_assoc_region = "US";
amzn_assoc_title = "Shop Related Products";
amzn_assoc_default_search_phrase = "Linear Algebra";
amzn_assoc_default_category = "All";
amzn_assoc_linkid = "5d941cdffc23d9a550f0004271073955";
</script><br />
<script src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US"></script>